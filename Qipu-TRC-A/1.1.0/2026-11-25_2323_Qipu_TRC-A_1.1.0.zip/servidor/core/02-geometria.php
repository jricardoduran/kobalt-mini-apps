<?php
declare(strict_types=1);
/* Geometría A. */
trait TRCGeometry {
 private function countAxis(int $s,int $a):int{TRC::need(isset($this->scopes[$s]['counts'][$a]),'Eje inexistente');return $this->scopes[$s]['counts'][$a];}
 private function alloc(int $s):int{return $this->scopes[$s]['seq']++;}
 private function axis(int $s):int{$a=$this->alloc($s);$this->scopes[$s]['counts'][$a]=0;return $a;}
 private function node(int $s,string $kind,int $axis,?int $rows=null):array{$n=['kind'=>$kind,'id'=>$this->alloc($s),'axis'=>$axis];if($rows!==null)$n['rows']=$rows;return $n;}
 private function table(int $s):array{$a=$this->axis($s);$b=$this->axis($s);return $this->node($s,'table',$a,$b);}
 private function vector(int $s):array{return $this->node($s,'vector',$this->axis($s));}
 private function introduce(int $s,int $a,mixed $name):int{
  TRC::need(TRC::name($name),'Nombre inválido');$key='n:'.$name;if(isset($this->scopes[$s]['pos'][$a][$key]))return $this->scopes[$s]['pos'][$a][$key];
  $i=$this->countAxis($s,$a);TRC::need($i<65536,'Capacidad de eje');$this->scopes[$s]['names'][$a][$i]=$name;$this->scopes[$s]['pos'][$a][$key]=$i;$this->scopes[$s]['counts'][$a]=$i+1;return $i;
 }
 private function slot(int $s,int $id,int $i):?array{return $this->scopes[$s]['slots'][$id][$i]??null;}
 private function put(int $s,array $parent,int $i,array $n):void{$this->scopes[$s]['slots'][$parent['id']][$i]=$n;}
 private function locate(int $s,array $r):array{
  $n=$this->scopes[$s]['root'];$parent=null;$i=null;
  foreach(TRC::route($r) as $p){TRC::need($n!==null&&!in_array($n['kind'],['value','trajectory'],true),'Contenido terminal, ausente o frontera');TRC::need($p<$this->countAxis($s,$n['axis']),'Posición inexistente');$parent=$n;$i=$p;$n=$this->slot($s,$parent['id'],$p);}
  return [$n,$parent,$i];
 }
 private function cell(?array $parent):bool{return $parent!==null&&in_array($parent['kind'],['column','vector'],true);}
 private function local(int $s,array $e):void{
  [$op,$r,$x]=TRC::ar($e,3);[$n,$parent,$i]=$this->locate($s,$r);$kind=$n['kind']??null;
  switch($op){
   case 'TABLE':TRC::need($kind==='root','TABLE exige raíz');$j=$this->introduce($s,$n['axis'],$x);if($this->slot($s,$n['id'],$j)===null)$this->put($s,$n,$j,$this->table($s));return;
   case 'COL':TRC::need($kind==='table','COL exige tabla');$j=$this->introduce($s,$n['axis'],$x);if($this->slot($s,$n['id'],$j)===null)$this->put($s,$n,$j,$this->node($s,'column',$n['rows']));return;
   case 'ID':TRC::need($kind==='table','ID exige tabla');$this->introduce($s,$n['rows'],$x);return;
   case 'ITEM':TRC::need($kind==='vector','ITEM exige vector');$this->introduce($s,$n['axis'],$x);return;
   case 'OPEN':TRC::need($this->cell($parent)&&in_array($x,['table','vector'],true),'OPEN exige celda y clase');TRC::need($n===null||$kind===$x,'Clase incompatible');if($n===null)$this->put($s,$parent,$i,$x==='table'?$this->table($s):$this->vector($s));return;
   case 'SET':TRC::need($this->cell($parent)&&($n===null||$kind==='value'),'SET exige celda terminal');$this->put($s,$parent,$i,['kind'=>'value','value'=>$x]);return;
   case 'ADD':case 'SUB':TRC::need($this->cell($parent)&&$kind==='value'&&TRC::nat($n['value'])&&TRC::nat($x),'Diferencial requiere natural existente');$v=$n['value']+($op==='ADD'?$x:-$x);TRC::need(TRC::nat($v),'Natural fuera de dominio');$this->put($s,$parent,$i,['kind'=>'value','value'=>$v]);return;
   default:throw new RuntimeException('Tratamiento inválido');
  }
 }
}
