QipuTRC.php carga los módulos core/01 a 03. TRCStore.php persiste; api.php adapta HTTP. index.html no carga motor JS. Consultar documentacion.html y README superior.
