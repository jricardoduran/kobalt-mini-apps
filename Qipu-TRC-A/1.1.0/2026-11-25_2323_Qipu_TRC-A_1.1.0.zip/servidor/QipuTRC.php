<?php
declare(strict_types=1);
require_once __DIR__.'/core/01-binario-dominio.php';
require_once __DIR__.'/core/02-geometria.php';
require_once __DIR__.'/core/03-recorrido.php';
/* Continuidad, admisión, historia y API. */
final class TRCWorld {
 private array $scopes=[], $receipts=[];
 private int $next=1;
 function __construct(){$this->init(0);}
 private function init(int $id):void{$this->scopes[$id]=['seq'=>1,'counts'=>[0=>0],'names'=>[],'pos'=>[],'slots'=>[],'records'=>[],'cuts'=>[],'root'=>['kind'=>'root','id'=>0,'axis'=>0]];}
 use TRCGeometry;
 private function effect(int $s,array $e,int $cut,bool $allowTx=false,?string $raw=null):void{
  [$op,$r,$x]=TRC::ar($e,3);
  if($op==='TX'){
   TRC::need($allowTx&&$s===0&&$r===[],'TX solo raíz');[$origin,$checks,$events]=TRC::ar($x,3);
   TRC::need(TRC::name($origin)&&is_array($checks)&&is_array($events)&&count($events)>0,'TX inválida');$key='o:'.$origin;TRC::need(!isset($this->receipts[$key]),'Origen ya reconocido');
   foreach($checks as $c){[$p,$expected]=TRC::ar($c,2);TRC::need(TRC::eq($this->read($p)['data'],$expected),'PRECONDICION_NO_CUMPLIDA');}
   foreach($events as $q)$this->effect($s,$q,$cut);
   $this->receipts[$key]=['cut'=>$cut,'raw'=>$raw];return;
  }
  if($op==='MOUNT'){[$p,$hex]=TRC::ar($x,2);TRC::need($p==='A','TRC utiliza perfil A');[$n,$parent,$i]=$this->locate($s,$r);TRC::need($n===null&&$this->cell($parent),'Montaje exige celda ausente');$child=$this->next++;$this->put($s,$parent,$i,['kind'=>'trajectory','id'=>$child,'profile'=>'A']);$this->init($child);$this->fold($child,TRC::unhex($hex),$cut);return;}
  if($op==='APPEND'){[$n]=$this->locate($s,$r);TRC::need(($n['kind']??null)==='trajectory','APPEND exige trayectoria');$b=TRC::unhex($x);TRC::need($b!=='','Sufijo vacío');$this->fold($n['id'],$b,$cut);return;}
  $this->local($s,$e);
 }
 private function fold(int $s,string $bytes,int $cut,bool $allowTx=false):void{
  for($o=0;$o<strlen($bytes);$o=$end){[$e,$end,$raw]=TRC::frame($bytes,$o);$this->effect($s,$e,$cut,$allowTx,$raw);$this->scopes[$s]['records'][]=$raw;$this->scopes[$s]['cuts'][]=$cut;}
 }
 function append(string $bytes,bool $strict=false):mixed{
  [$e,$end]=TRC::frame($bytes);TRC::need($end===strlen($bytes),'Un acontecimiento exterior por append');TRC::verify($e);
  if($e[0]==='TX'){[,,$x]=$e;[$origin]=TRC::ar($x,3);TRC::need(TRC::name($origin),'Origen inválido');$key='o:'.$origin;if(isset($this->receipts[$key])){$old=$this->receipts[$key];TRC::need(!$strict,'Origen repetido físicamente en replay');TRC::need(hash_equals($old['raw'],$bytes),'CONFLICTO_ORIGEN');return ['cut'=>$old['cut'],'replayed'=>true];}}
  $v=clone $this;$cut=$this->cut()+1;$v->fold(0,$bytes,$cut,true);$this->scopes=$v->scopes;$this->receipts=$v->receipts;$this->next=$v->next;return $e[0]==='TX'?['cut'=>$cut,'replayed'=>false]:$cut;
 }
 function submit(array $e):mixed{TRC::check($e);return $this->append(TRC::encode($e));}
 use TRCRoute;
 function recognized(mixed $origin,array $checks,string $op,array $r,mixed $x):mixed{
  TRC::need(in_array($op,['TABLE','COL','ID','ITEM','OPEN','SET','ADD','SUB','MOUNT'],true),'Tratamiento inválido');[$s,,$path,$bounds]=$this->navigate($r,$op!=='MOUNT');
  $e=[$op,$path,$x];TRC::verify($e,false);$raw=TRC::encode($e);for($i=count($bounds)-1;$i>=0;$i--){$e=['APPEND',$bounds[$i]['path'],bin2hex($raw)];$raw=TRC::encode($e);}return $this->submit(['TX',[],[$origin,$checks,[$e]]]);
 }
 function cut(int $s=0):int{TRC::need(isset($this->scopes[$s]),'Trayectoria desconocida');return count($this->scopes[$s]['records']);}
 function export(int $s=0,?int $end=null):string{$n=$this->cut($s);$end??=$n;TRC::need(TRC::nat($end)&&$end<=$n,'Corte fuera de rango');return implode('',array_slice($this->scopes[$s]['records'],0,$end));}
 private function scope(array $r):int{if($r===[])return 0;[, $n]=$this->navigate($r,false);TRC::need(($n['kind']??null)==='trajectory','Ruta no constituye trayectoria');return $n['id'];}
 function history(array $r=[],int $from=0,?int $to=null):array{$id=$this->scope($r);$n=$this->cut($id);$to??=$n;TRC::need($from>=0&&$from<=$to&&$to<=$n,'Rango histórico inválido');$records=[];for($i=$from;$i<$to;$i++){$raw=$this->scopes[$id]['records'][$i];[$e]=TRC::frame($raw);$records[]=['position'=>$i,'rootCut'=>$this->scopes[$id]['cuts'][$i],'event'=>$e,'hex'=>bin2hex($raw)];}return ['scope'=>$id,'profile'=>'A','cut'=>$n,'rootCut'=>$this->cut(),'from'=>$from,'to'=>$to,'records'=>$records];}
 static function replay(string $raw):self{$w=new self;for($o=0;$o<strlen($raw);$o=$end){[,$end,$b]=TRC::frame($raw,$o);$w->append($b,true);}return $w;}
 function execute(stdClass $q):mixed{
  TRC::check($q);$r=TRC::route($q->route??[]);$op=$q->op??'';if(in_array($op,['read','history','export'],true)&&isset($q->cut)){TRC::need(TRC::nat($q->cut),'Corte inválido');$w=self::replay($this->export(0,$q->cut));$qq=clone $q;unset($qq->cut);return $w->execute($qq);}
  return match($op){
   'write'=>$this->recognized($q->origin??null,$q->checks??[],$q->treatment??'',$r,property_exists($q,'content')?$q->content:throw new RuntimeException('Contenido requerido')),
   'submit'=>$this->submit($q->event??[]),
   'transaction'=>$this->submit(['TX',[],[$q->origin??null,$q->checks??[],$q->events??[]]]),
   'read'=>$this->read($r,($q->enterFinal??true)!==false),
   'history'=>$this->history($r,$q->from??0,$q->to??null),
   'export'=>['hex'=>bin2hex($this->export($this->scope($r),$q->end??null)),'cut'=>$this->cut($this->scope($r))],
   'cut'=>['cut'=>$this->cut()],
   default=>throw new RuntimeException('Operación desconocida')
  };
 }
 static function plan(string $raw,stdClass $q):array{$w=self::replay($raw);$before=$w->cut();$result=$w->execute($q);$all=$w->export();TRC::need($w->cut()===$before||$w->cut()===$before+1,'Un marco raíz por solicitud');TRC::need(str_starts_with($all,$raw),'Prefijo alterado');return ['result'=>$result,'cut'=>$w->cut(),'suffix'=>substr($all,strlen($raw))];}
}
