'use strict';
require('./core/01-binario.js');
require('./core/02-dominio.js');
require('./core/03-geometria.js');
require('./core/04-trayectoria.js');
require('./core/05-api.js');
module.exports=globalThis.QipuTRC;
