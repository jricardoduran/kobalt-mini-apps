Motor: local/core/01 a 05, cargados en orden por index.html. node.cjs es la entrada de pruebas Node. Adaptador IndexedDB independiente. Consultar documentacion.html y README superior.
