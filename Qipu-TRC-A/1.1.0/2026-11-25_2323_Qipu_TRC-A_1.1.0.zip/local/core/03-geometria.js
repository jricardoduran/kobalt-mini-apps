/* 03. GEOMETRÍA A: tabla, columna y celda recursiva. */
'use strict';
Qipu.TRCInternal.geometry=(()=>{
 const U=Qipu.TRCInternal.domain;
 const {need,cp,eq,nat,ar,route,transform}=U;
 const key=(...x)=>JSON.stringify(x);
 function zero(profile){need(profile==='A','Perfil');const s=new Map();
 const put=(x,...k)=>s.set(key(...k),x);
 put(1,'seq');put(0,'count',0);put({kind:'root',id:0,axis:0},'root');
 return s}
 function view(base){const delta=new Map(),seen=new Set();
  function get(...k){let p=key(...k);if(delta.has(p))return delta.get(p);seen.add(p);return base.get(p)}
  function put(x,...k){let p=key(...k);if(!eq(get(...k),x))delta.set(p,x)}
  return {get,put,delta,seen}}
 function engine(profile){
  function count(v,a){const n=v.get('count',a);need(nat(n),'Eje inexistente');return n}
  function alloc(v){let id=v.get('seq');v.put(id+1,'seq');return id}
  function newAxis(v){let id=alloc(v);v.put(0,'count',id);return id}
  function introduce(v,a,n){need(U.name(n),'Nombre inválido');let i=v.get('pos',a,n);if(i!==undefined)return i;i=count(v,a);need(i<65536,'Capacidad');v.put(n,'name',a,i);v.put(i,'pos',a,n);v.put(i+1,'count',a);return i}
  function node(v,kind,axis,rows){return {kind,id:alloc(v),axis,...(rows===undefined?{}:{rows})}}
  function table(v){return node(v,'table',newAxis(v),newAxis(v))}
  function vector(v){return node(v,'vector',newAxis(v))}
  function resolve(v,r){route(r);let n=v.get('root'),parent=null,i;
   for(const p of r){need(n&&n.kind!=='value'&&n.kind!=='trajectory','Contenido terminal, ausente o frontera de trayectoria');need(p<count(v,n.axis),'Posición inexistente');parent=n;i=p;n=v.get('slot',n.id,p)}
   return {n,parent,i}}
  function bound(v,c,x){need(c.parent,'Se requiere posición');v.put(x,'slot',c.parent.id,c.i)}
  function one(v,e){const [op,r,x]=ar(e,3);
   const c=resolve(v,r),n=c.n;
   if(op==='MOUNT_LOCAL'){need(c.parent&&(['column','vector'].includes(c.parent.kind))&&!n,'Montaje exige celda ausente');const [id,p]=ar(x,2);need(nat(id)&&p==='A','Descriptor inválido');bound(v,c,{kind:'trajectory',id,profile:p});return}
   {
    if(op==='TABLE'){need(n?.kind==='root','TABLE exige raíz');let i=introduce(v,n.axis,x);if(v.get('slot',n.id,i)===undefined)v.put(table(v),'slot',n.id,i);return}
    if(op==='COL'){need(n?.kind==='table','COL exige tabla');let i=introduce(v,n.axis,x);if(v.get('slot',n.id,i)===undefined)v.put(node(v,'column',n.rows),'slot',n.id,i);return}
    if(op==='ID'){need(n?.kind==='table','ID exige tabla');introduce(v,n.rows,x);return}
    if(op==='ITEM'){need(n?.kind==='vector','ITEM exige vector');introduce(v,n.axis,x);return}
    if(op==='OPEN'){need(c.parent&&['column','vector'].includes(c.parent.kind)&&['table','vector'].includes(x),'OPEN exige celda y clase');need(!n||n.kind===x,'Clase incompatible');if(!n)bound(v,c,x==='table'?table(v):vector(v));return}
   }
   need(['SET','ADD','SUB'].includes(op),'Tratamiento desconocido');need(c.parent&&(['column','vector'].includes(c.parent.kind)),'Se requiere celda');bound(v,c,transform(n,op,x))
  }
  function plan(base,e){const v=view(base);one(v,e);return {delta:v.delta,reads:v.seen.size,writes:v.delta.size}}
  return {zero:()=>zero(profile),plan,locate:(s,r)=>resolve(view(s),r)}
 }
 return {A:engine('A')}
})();
