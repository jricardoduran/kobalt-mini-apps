'use strict';
/* 02. DOMINIO. Criterio único de admisión JSON y diferenciales naturales. */
Qipu.TRCInternal.domain=(()=>{
 const MAX=64, need=(ok,msg)=>{if(!ok)throw Error(msg)};
 const cp=x=>JSON.parse(JSON.stringify(x)),eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const nat=x=>Number.isSafeInteger(x)&&x>=0,name=x=>typeof x==='string'&&x.length>0&&x.length<=200;
 const ar=(x,n)=>{need(Array.isArray(x)&&x.length===n,'Aridad inválida');return x};
 function route(r){need(Array.isArray(r),'Ruta inválida');for(let i=0;i<r.length;i++)need(Object.hasOwn(r,i)&&nat(r[i]),'Ruta inválida');return r}
 const enc=new TextEncoder(),dec=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 function value(x,d=0){
  need(d<=MAX,'Contenido demasiado profundo');
  if(typeof x==='string'){need(dec.decode(enc.encode(x))===x,'Unicode inválido');return}
  if(x===null||typeof x==='boolean'||Number.isSafeInteger(x))return;
  if(Array.isArray(x)){for(let i=0;i<x.length;i++){need(Object.hasOwn(x,i),'Lista dispersa inválida');value(x[i],d+1)}return}
  need(x&&Object.getPrototypeOf(x)===Object.prototype,'JSON inválido');
  for(const k of Object.keys(x)){value(k,d+1);value(x[k],d+1)}
 }
 function transform(old,op,x){
  value(x);
  if(op==='SET'){need(!old||old.kind==='value','No sustituir geometría constituida');return {kind:'value',value:cp(x)}}
  need(['ADD','SUB'].includes(op)&&old?.kind==='value'&&nat(old.value)&&nat(x),'Diferencial requiere natural existente');
  const y=old.value+(op==='ADD'?x:-x);
  need(nat(y),'Natural fuera de dominio');
  return {kind:'value',value:y}
 }
 return {need,cp,eq,nat,name,ar,route,value,transform}
})();
