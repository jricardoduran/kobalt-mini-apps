<?php
declare(strict_types=1);
// Metacontrato QIPU-META-1. No eval, código de usuario ni conocimiento comercial.
final class Motor {
 static function zero():array{return ['types'=>[],'fields'=>[],'actions'=>[],'tables'=>[],'history'=>[]];}
 static function ok(bool $b,string $m='Contrato inválido'):void{if(!$b)throw new StorageError(422,$m);}
 static function keys(array $x,array $k):void{$a=array_keys($x);sort($a);sort($k);self::ok($a===$k,'Campos inválidos');}
 static function name(mixed $x):string{self::ok(is_string($x)&&preg_match('/\A[A-Za-z][A-Za-z0-9_-]{0,63}\z/',$x)===1,'Nombre contractual inválido');return $x;}
 static function text(mixed $x):string{self::ok(is_string($x)&&strlen($x)>0&&strlen($x)<=200&&preg_match('//u',$x)===1&&!str_starts_with($x,"\xEF\xBB\xBF"),'Texto inválido');return $x;}
 static function listOf(mixed $x,int $min=0,int $max=256):array{self::ok(is_array($x)&&array_is_list($x)&&count($x)>=$min&&count($x)<=$max,'Lista inválida');return $x;}
 static function nat(mixed $x):int{self::ok(is_int($x)&&$x>=0&&$x<=1000000000,'Natural fuera de perfil');return $x;}
 static function domain(mixed $x):void{self::ok(in_array($x,['text','natural','boolean'],true),'Dominio inválido');}
 static function value(string $d,mixed $x):void{match($d){'text'=>self::text($x),'natural'=>self::nat($x),'boolean'=>self::ok(is_bool($x),'Booleano requerido'),default=>throw new StorageError(422,'Dominio desconocido')};}
 static function find(array $a,string $name,?string $table=null):?int{foreach($a as $i=>$x)if($x['name']===$name&&($table===null||$x['table']===$table))return $i;return null;}
 static function field(array $d,string $t,string $p):array{$i=self::find($d['fields'],$p,$t);self::ok($i!==null,'Parámetro no admitido');return $d['fields'][$i];}
 static function type(array $d,string $t):void{self::ok(in_array($t,$d['types'],true),'Tipo no admitido');}
 static function operation(mixed $x):void{self::ok(in_array($x,['SET','ADD','SUB'],true),'Tratamiento no admitido');}
 static function scalar(mixed $x):void{self::ok(is_bool($x)||is_string($x)||is_int($x),'Escalar requerido');if(is_string($x))self::text($x);if(is_int($x))self::nat($x);}
 // Structural validation independent of current contracts, so offline requests can be published unchanged.
 static function request(array $e):array{
  switch($e['op']??null){
   case 'contract': self::keys($e,['op','types','fields','actions']);foreach(self::listOf($e['types']) as $t)self::name($t);
    foreach(self::listOf($e['fields']) as $f){self::ok(is_array($f));self::keys($f,['table','name','domain','allow','constitutive']);self::name($f['table']);self::name($f['name']);self::domain($f['domain']);self::ok(is_bool($f['constitutive']));$a=self::listOf($f['allow'],1,3);foreach($a as $op){self::operation($op);self::ok($op==='SET'||$f['domain']==='natural','Diferencial solo natural');}self::ok(count(array_unique($a))===count($a),'Operaciones repetidas');self::ok(!$f['constitutive']||in_array('SET',$a,true),'Constitución exige SET');}
    foreach(self::listOf($e['actions']) as $a){self::ok(is_array($a));self::keys($a,['name','table','inputs','effects','measure']);self::name($a['name']);self::name($a['table']);$names=[];foreach(self::listOf($a['inputs'],1,32) as $f){self::ok(is_array($f));self::keys($f,['name','domain','positive']);self::name($f['name']);self::domain($f['domain']);self::ok(is_bool($f['positive'])&&(!$f['positive']||$f['domain']==='natural'),'Positivo solo natural');self::ok(!in_array($f['name'],$names,true),'Entrada repetida');$names[]=$f['name'];}foreach(self::listOf($a['effects'],1,32) as $f){self::ok(is_array($f));self::keys($f,['parameter','operation','input']);self::name($f['parameter']);self::operation($f['operation']);self::name($f['input']);self::ok(in_array($f['input'],$names,true),'Entrada desconocida');}$m=self::listOf($a['measure'],0,2);self::ok(count($m)===0||count($m)===2,'Medida: dos entradas o ninguna');foreach($m as $x){self::name($x);self::ok(in_array($x,$names,true),'Medida desconocida');}}
    self::ok(count($e['types'])+count($e['fields'])+count($e['actions'])>0,'Contrato vacío');break;
   case 'identity':self::keys($e,['op','table','identity']);self::name($e['table']);self::text($e['identity']);break;
   case 'assert':self::keys($e,['op','table','identity','parameter','operation','value']);self::name($e['table']);self::text($e['identity']);self::name($e['parameter']);self::operation($e['operation']);self::scalar($e['value']);break;
   case 'action':self::keys($e,['op','name','rows']);self::name($e['name']);foreach(self::listOf($e['rows'],1,1000) as $r){self::ok(is_array($r));self::keys($r,['identity','values']);self::text($r['identity']);foreach(self::listOf($r['values'],1,32) as $v)self::scalar($v);}break;
   default: self::ok(false,'Operación desconocida');
  }return $e;
 }
 static function addDefinition(array &$list,array $x,?string $table=null):void{$i=self::find($list,$x['name'],$table);if($i!==null){self::ok($list[$i]==$x,'Definición inmutable: use otra identidad/version');return;}$list[]=$x;}
 static function contract(array &$d,array $e):void{
  foreach($e['types'] as $t)if(!in_array($t,$d['types'],true))$d['types'][]=$t;
  foreach($e['fields'] as $f){self::type($d,$f['table']);self::addDefinition($d['fields'],$f,$f['table']);}
  foreach($e['actions'] as $a){self::type($d,$a['table']);foreach($a['effects'] as $ef){$f=self::field($d,$a['table'],$ef['parameter']);$inp=$a['inputs'][self::find($a['inputs'],$ef['input'])];self::ok($inp['domain']===$f['domain']&&in_array($ef['operation'],$f['allow'],true),'Efecto incompatible con campo');}foreach($a['measure'] as $n)self::ok($a['inputs'][self::find($a['inputs'],$n)]['domain']==='natural','Medida exige naturales');self::addDefinition($d['actions'],$a);}
 }
 // CPA: identity and field definitions alone do not materialize vectors.
 static function identity(array &$d,string $t,string $id,bool $constitutive):array{self::type($d,$t);$ti=self::find($d['tables'],$t);if($ti===null){self::ok($constitutive,'Tabla no constituida');$ti=count($d['tables']);self::ok($ti<65536,'Capacidad tabla');$d['tables'][]=['name'=>$t,'entities'=>[],'vectors'=>[]];}$i=array_search($id,$d['tables'][$ti]['entities'],true);if($i===false){self::ok($constitutive,'Identidad no constituida');$i=count($d['tables'][$ti]['entities']);self::ok($i<65536,'Capacidad entidad');$d['tables'][$ti]['entities'][]=$id;}return [$ti,$i];}
 static function change(array &$d,string $t,string $id,string $p,string $op,mixed $x,bool $allowCreate):void{
  $f=self::field($d,$t,$p);self::ok(in_array($op,$f['allow'],true),'Operación no permitida');self::value($f['domain'],$x);[$ti,$i]=self::identity($d,$t,$id,$allowCreate&&$f['constitutive']&&$op==='SET');$vs=&$d['tables'][$ti]['vectors'];$vi=self::find($vs,$p);if($vi===null){self::ok($op==='SET','Vector no constituido');$vi=count($vs);self::ok($vi<65536,'Capacidad vector');$vs[]=['name'=>$p,'domain'=>$f['domain'],'values'=>[]];}if($op!=='SET'){self::ok(array_key_exists($i,$vs[$vi]['values']),'Valor aún ausente');$x=$vs[$vi]['values'][$i]+($op==='ADD'?$x:-$x);self::nat($x);}$vs[$vi]['values'][$i]=$x;
 }
 // PHP copy-on-write candidate: no partial mutation escapes on rejection.
 static function apply(array $d,array $e):array{self::request($e);switch($e['op']){case 'contract':self::contract($d,$e);break;case 'identity':self::identity($d,$e['table'],$e['identity'],true);break;case 'assert':self::change($d,$e['table'],$e['identity'],$e['parameter'],$e['operation'],$e['value'],true);break;case 'action':$i=self::find($d['actions'],$e['name']);self::ok($i!==null,'Contrato de acción desconocido');$a=$d['actions'][$i];$sum=0;foreach($e['rows'] as $r){self::ok(count($r['values'])===count($a['inputs']),'Aridad incorrecta');self::identity($d,$a['table'],$r['identity'],false);foreach($a['inputs'] as $j=>$f){$x=$r['values'][$j];self::value($f['domain'],$x);self::ok(!$f['positive']||$x>0,'Entrada positiva requerida');}foreach($a['effects'] as $ef)self::change($d,$a['table'],$r['identity'],$ef['parameter'],$ef['operation'],$r['values'][self::find($a['inputs'],$ef['input'])],false);if($a['measure']){$sum+=$r['values'][self::find($a['inputs'],$a['measure'][0])]*$r['values'][self::find($a['inputs'],$a['measure'][1])];self::ok(is_int($sum)&&$sum<=9007199254740991,'Medida fuera de entero seguro');}}$d['history'][]=['name'=>$e['name'],'rows'=>$e['rows'],'measure'=>$a['measure']?$sum:null];break;}return $d;}
 static function view(array $d):array{foreach($d['tables'] as &$t)foreach($t['vectors'] as &$v)$v['values']=(object)$v['values'];unset($t,$v);return $d;}
}
