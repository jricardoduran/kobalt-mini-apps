# Qipu — Motor de Contratos 0.1.0 (experimental)

La gramática QIPU-META-1 distingue posibilidades contractuales de datos constituidos. Comercio es una plantilla, no un caso especial del motor. PHP y JS independientes interpretan los mismos hechos. PAO 1.1.0 permanece byte a byte intacto.

## Arranque

PHP 8.1+ de 64 bits, filesystem local POSIX con flock/fsync. Desde la raíz del proyecto: `php -S 127.0.0.1:8080 -t public`. Abrir http://127.0.0.1:8080/. El directorio privado data-motor-v01 se crea al primer acceso; QIPU_ROOT permite elegir otro directorio NUEVO, fuera de public. Usar localhost o HTTPS para Web Crypto. Sin OAuth, CDN, frameworks ni service worker. No exponer a internet: la API experimental carece de autenticación/roles.

1. Abrir A. Desactivar red. Preparar plantilla Comercio y constituir borrador en L como solicitud.
2. En afirmación: Producto / SKU-A / Nombre / SET / Camisa. Luego Stock / SET / 20 y Precio / SET / 35000. Crear una venta de 5 × 35000 en la acción Venta-v1.
3. Activar red, publicar Q, examinar pendientes. Aceptar en orden. Adquirir R y C por separado. Stock 15, una venta por 175000.
4. Abrir B, adquirir C. Definir un campo Peso natural SET desde UI; constituir solicitud, reconocer, adquirir C. Afirmar Peso=250. La posición de SKU-A no cambia.
5. Definir Entrada-v1 desde el editor de acciones (cantidad natural positiva, Stock ADD, sin medida). Probar sus formularios generados. Una acción SET con múltiples líneas sirve de editor masivo. "Cargar identidades" llena las filas, no constituye hechos.

## Formato y límites

K5B: T16 | W8 | L(k bytes big-endian mínimos) | cuerpo | SHA-256(domain+encabezado+cuerpo). Cuerpo JSON UTF-8 compacto de este perfil; T100 nota local, T101 solicitud, T102 hecho privado, T112 localidad, T120 canónico. T120={origin,event}; génesis origin=null, event={op:"genesis",profile:"QIPU-META-1"}. Origen (node,index) se conserva; eventos originales se interpretan en el orden canónico. No se almacenan sus efectos por separado. K2P queda incluido como mecanismo de base, no se usa aún para compactar los campos T120. No es compatible con T111 de Qipu 2.1.0. N, C, Qj, Rj: 2n+2 archivos. M3E1 (bit decisión y posición módulo 128).

Contratos aditivos e inmutables: nuevos nombres/versiones, no redefinir. Campos con dominios text/natural/boolean, SET/ADD/SUB (solo natural para diferenciales), constitutive permite que SET constituya identidad. Acción referencia identidades existentes; inputs ordenados, efectos ordenados, medida opcional suma de producto de dos entradas naturales. Sin eval, código arbitrario, APPEND/UNSET general ni nulos. Una afirmación de identidad es opcional, no una instrucción CREATE necesaria. ∅ es ausencia. Perfiles de demo: natural hasta 10^9, totales seguros, nombres ASCII contractuales, identidades UTF-8 de hasta 200 bytes, 4 MiB por flujo. Los índices posicionales y tablas emergen; la resolución de nombres todavía utiliza búsquedas lineales y el registro canónico conserva nombres. IndexedDB conserva blobs por flujo con compare-and-append transaccional. El servidor reconstruye historia, la transferencia HTTP de extensiones es incremental. No hay migración automática, registro autenticado, compromisos de prefijo eficientes, ni esquema de divulgación pública.

## Pruebas reproducibles

`bash tests/run.sh` (PHP + Node, 45 comprobaciones HTTP/JS y 6 recuperación), `php tests/pao/run.php` (15 originales), `python tests/browser.py` (Playwright + Chromium, opcional). Suite HTTP también ejecutada con Apache 2.4/mod_php 8.4 (45/45). 111 comprobaciones ejecutadas, no 111 propiedades independientes. Comparación de 22 cortes binarios por ejecución. Chromium bloqueó localhost por política administrativa, salida 77: no se ha comprobado el funcionamiento real de IndexedDB ni del frontend en navegador. El ZIP de ejecución no incluye las herramientas de prueba. El README HTML es autónomo y contiene un laboratorio que usa el intérprete real; su navegación visual tampoco se verificó.
