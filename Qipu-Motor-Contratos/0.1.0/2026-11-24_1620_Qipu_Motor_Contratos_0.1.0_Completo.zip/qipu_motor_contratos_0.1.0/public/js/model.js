'use strict';
// Qipu transport: local/remote histories, canonical provenance, M3E1, independent acquisition.
const Model=(()=>{
 const {cat,equal,hash}=Qipu.K4B,need=Qipu.K2P.need,enc=new TextEncoder(),dec=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const NOTE=100,REQUEST=101,LOCAL_FACT=102,CANON=120,CAP=4194304;
 const empty=()=>new Uint8Array(),hex=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
 const validNode=x=>typeof x==='string'&&/^[A-Za-z][A-Za-z0-9_-]{0,31}$/.test(x)&&!/[\r\n]/.test(x);
 const keys=(x,k)=>need(x!==null&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===k.length&&k.every(n=>Object.hasOwn(x,n)),'Campos inválidos');
 const frame=(t,x)=>Qipu.K5B.seal(t,enc.encode(JSON.stringify(x)));
 async function scan(b){let a=[];for(let p=0;p<b.length;){let r=await Qipu.K5B.read(b,p);let text=dec.decode(r.body),x=JSON.parse(text);need(JSON.stringify(x)===text,'JSON compacto canónico requerido');a.push({t:r.t,x,raw:b.slice(p,r.end),offset:p,end:r.end});p=r.end;}return a;}
 const zero=()=>({state:Motor.zero(),origins:new Set(),count:0});
 const originKey=(node,i)=>node+':'+i;
 async function extend(prev,b){let state=structuredClone(prev.state),origins=new Set(prev.origins),count=prev.count;for(let r of await scan(b)){need(r.t===CANON,'Tipo canónico inválido');keys(r.x,['origin','event']);let {origin,event}=r.x;if(count===0){need(origin===null&&Motor.eq(event,{op:'genesis',profile:'QIPU-META-1'}),'Génesis incompatible');}else{keys(origin,['node','index']);need(validNode(origin.node)&&Number.isSafeInteger(origin.index)&&origin.index>=0&&origin.index<=1e9,'Origen inválido');let k=originKey(origin.node,origin.index);need(!origins.has(k),'Origen duplicado');state=Motor.apply(state,event);origins.add(k);}count++;}return {state,origins,count};}
 function decisions(b){return Array.from(b,(x,i)=>{need(x%128===i%128,'Marca M3E1 inválida');return x>>7;});}
 const localZero=()=>({q:[],history:[],privateState:Motor.zero()});
 async function extendLocal(prev,b){let q=prev.q.slice(),history=prev.history.slice(),privateState=structuredClone(prev.privateState);for(let r of await scan(b)){if(r.t===NOTE){keys(r.x,['text']);Motor.text(r.x.text);history.push({kind:'local',text:r.x.text});}else if(r.t===LOCAL_FACT){privateState=Motor.apply(privateState,r.x);history.push({kind:'localFact',fact:r.x});}else if(r.t===REQUEST){Motor.request(r.x);history.push({kind:'request',index:q.length,request:r.x});q.push(r);}else throw Error('Tipo local inválido');}return {q,history,privateState};}
 const local=b=>extendLocal(localZero(),b);
 function overlay(c,l,r,node){let bits=decisions(r),state=structuredClone(c.state),status=[];need(bits.length<=l.q.length,'R excede solicitudes locales');for(let i=0;i<l.q.length;i++){let included=c.origins.has(originKey(node,i)),bit=bits[i];need(!(included&&bit===0),'Contradicción C/R');if(included){status.push('incorporada');continue;}if(bit===0){status.push('rechazada');continue;}try{state=Motor.apply(state,l.q[i].x);status.push(bit===1?'aceptada; falta C':'provisional');}catch(e){status.push((bit===1?'aceptada; falta C':'pendiente')+' · conflicto: '+e.message);}}return {state,status};}
 return {NOTE,REQUEST,LOCAL_FACT,CANON,CAP,cat,equal,hash,hex,empty,validNode,frame,scan,zero,extend,decisions,local,extendLocal,localZero,overlay,request:Motor.request,txt:Motor.text};
})();
