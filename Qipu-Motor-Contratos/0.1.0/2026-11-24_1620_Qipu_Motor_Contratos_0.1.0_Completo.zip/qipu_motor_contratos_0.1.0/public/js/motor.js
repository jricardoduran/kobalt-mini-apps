'use strict';
// Identical bounded declarative grammar; no eval or application-specific handlers.
const Motor=(()=>{
 const need=Qipu.K2P.need,enc=new TextEncoder(),dec=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const zero=()=>({types:[],fields:[],actions:[],tables:[],history:[]});
 const obj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const keys=(x,k)=>need(obj(x)&&Object.keys(x).length===k.length&&k.every(n=>Object.hasOwn(x,n)),'Campos inválidos');
 const name=x=>need(typeof x==='string'&&/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(x)&&!/[\r\n]/.test(x),'Nombre contractual inválido');
 const text=x=>need(typeof x==='string'&&enc.encode(x).length>0&&enc.encode(x).length<=200&&!x.startsWith('\uFEFF')&&dec.decode(enc.encode(x))===x,'Texto inválido');
 const list=(x,min=0,max=256)=>{need(Array.isArray(x)&&x.length>=min&&x.length<=max,'Lista inválida');return x;};
 const nat=x=>need(Number.isSafeInteger(x)&&x>=0&&x<=1e9,'Natural fuera de perfil');
 const domain=x=>need(['text','natural','boolean'].includes(x),'Dominio inválido');
 const value=(d,x)=>d==='text'?text(x):d==='natural'?nat(x):need(d==='boolean'&&typeof x==='boolean','Booleano requerido');
 const operation=x=>need(['SET','ADD','SUB'].includes(x),'Tratamiento no admitido');
 const scalar=x=>typeof x==='string'?text(x):typeof x==='boolean'?undefined:nat(x);
 const find=(a,n,t=null)=>a.findIndex(x=>x.name===n&&(t===null||x.table===t));
 const type=(d,t)=>need(d.types.includes(t),'Tipo no admitido');
 const field=(d,t,p)=>{let i=find(d.fields,p,t);need(i>=0,'Parámetro no admitido');return d.fields[i];};
 function request(e){need(obj(e),'Objeto requerido');switch(e.op){
 case 'contract':keys(e,['op','types','fields','actions']);list(e.types).forEach(name);for(let f of list(e.fields)){keys(f,['table','name','domain','allow','constitutive']);name(f.table);name(f.name);domain(f.domain);need(typeof f.constitutive==='boolean','Constitutive inválido');let a=list(f.allow,1,3);for(let op of a){operation(op);need(op==='SET'||f.domain==='natural','Diferencial solo natural');}need(new Set(a).size===a.length,'Operaciones repetidas');need(!f.constitutive||a.includes('SET'),'Constitución exige SET');}
 for(let a of list(e.actions)){keys(a,['name','table','inputs','effects','measure']);name(a.name);name(a.table);let names=[];for(let f of list(a.inputs,1,32)){keys(f,['name','domain','positive']);name(f.name);domain(f.domain);need(typeof f.positive==='boolean'&&(!f.positive||f.domain==='natural'),'Positivo solo natural');need(!names.includes(f.name),'Entrada repetida');names.push(f.name);}for(let f of list(a.effects,1,32)){keys(f,['parameter','operation','input']);name(f.parameter);operation(f.operation);name(f.input);need(names.includes(f.input),'Entrada desconocida');}let m=list(a.measure,0,2);need(m.length===0||m.length===2,'Medida: dos entradas o ninguna');for(let n of m){name(n);need(names.includes(n),'Medida desconocida');}}need(e.types.length+e.fields.length+e.actions.length>0,'Contrato vacío');break;
 case 'identity':keys(e,['op','table','identity']);name(e.table);text(e.identity);break;
 case 'assert':keys(e,['op','table','identity','parameter','operation','value']);name(e.table);text(e.identity);name(e.parameter);operation(e.operation);scalar(e.value);break;
 case 'action':keys(e,['op','name','rows']);name(e.name);for(let r of list(e.rows,1,1000)){keys(r,['identity','values']);text(r.identity);list(r.values,1,32).forEach(scalar);}break;
 default:throw Error('Operación desconocida');}return e;}
 function eq(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;let k=Object.keys(a);return k.length===Object.keys(b).length&&k.every(x=>Object.hasOwn(b,x)&&eq(a[x],b[x]));}
 function add(a,x,t=null){let i=find(a,x.name,t);if(i>=0){need(eq(a[i],x),'Definición inmutable: use otra identidad/version');return;}a.push(structuredClone(x));}
 function contract(d,e){for(let t of e.types)if(!d.types.includes(t))d.types.push(t);for(let f of e.fields){type(d,f.table);add(d.fields,f,f.table);}for(let a of e.actions){type(d,a.table);for(let ef of a.effects){let f=field(d,a.table,ef.parameter),inp=a.inputs[find(a.inputs,ef.input)];need(inp.domain===f.domain&&f.allow.includes(ef.operation),'Efecto incompatible con campo');}for(let n of a.measure)need(a.inputs[find(a.inputs,n)].domain==='natural','Medida exige naturales');add(d.actions,a);}}
 function identity(d,t,id,create){type(d,t);let ti=find(d.tables,t);if(ti<0){need(create,'Tabla no constituida');ti=d.tables.length;need(ti<65536,'Capacidad tabla');d.tables.push({name:t,entities:[],vectors:[]});}let tab=d.tables[ti],i=tab.entities.indexOf(id);if(i<0){need(create,'Identidad no constituida');i=tab.entities.length;need(i<65536,'Capacidad entidad');tab.entities.push(id);}return [ti,i];}
 function change(d,t,id,p,op,x,create){let f=field(d,t,p);need(f.allow.includes(op),'Operación no permitida');value(f.domain,x);let [ti,i]=identity(d,t,id,create&&f.constitutive&&op==='SET'),vs=d.tables[ti].vectors,vi=find(vs,p);if(vi<0){need(op==='SET','Vector no constituido');vi=vs.length;need(vi<65536,'Capacidad vector');vs.push({name:p,domain:f.domain,values:{}});}let vals=vs[vi].values;if(op!=='SET'){need(Object.hasOwn(vals,i),'Valor aún ausente');x=vals[i]+(op==='ADD'?x:-x);nat(x);}vals[i]=x;}
 function apply(old,e){request(e);let d=structuredClone(old);switch(e.op){case 'contract':contract(d,e);break;case 'identity':identity(d,e.table,e.identity,true);break;case 'assert':change(d,e.table,e.identity,e.parameter,e.operation,e.value,true);break;case 'action':{let i=find(d.actions,e.name);need(i>=0,'Contrato de acción desconocido');let a=d.actions[i],sum=0;for(let r of e.rows){need(r.values.length===a.inputs.length,'Aridad incorrecta');identity(d,a.table,r.identity,false);a.inputs.forEach((f,j)=>{let x=r.values[j];value(f.domain,x);need(!f.positive||x>0,'Entrada positiva requerida');});for(let ef of a.effects)change(d,a.table,r.identity,ef.parameter,ef.operation,r.values[find(a.inputs,ef.input)],false);if(a.measure.length){sum+=r.values[find(a.inputs,a.measure[0])]*r.values[find(a.inputs,a.measure[1])];need(Number.isSafeInteger(sum),'Medida fuera de entero seguro');}}d.history.push({name:e.name,rows:structuredClone(e.rows),measure:a.measure.length?sum:null});break;}}return d;}
 function project(d,t,i){let tab=d.tables[t];need(tab&&tab.entities[i]!==undefined,'Posición inexistente');return {identity:tab.entities[i],parameters:Object.fromEntries(tab.vectors.filter(v=>Object.hasOwn(v.values,i)).map(v=>[v.name,v.values[i]]))};}
 return {zero,request,apply,project,eq,name,text,domain,operation,value};
})();
