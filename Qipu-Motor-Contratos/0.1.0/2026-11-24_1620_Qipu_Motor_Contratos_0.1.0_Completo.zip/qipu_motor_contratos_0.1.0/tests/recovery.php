<?php
declare(strict_types=1);
require __DIR__.'/../src/Qipu.php';
$root=sys_get_temp_dir().'/qipu-meta-'.bin2hex(random_bytes(8));mkdir($root,0700);$q=new QipuDemo($root);$n=0;
function check(bool $b,string $m):void{global $n;if(!$b)throw new RuntimeException($m);echo 'PASS '.(++$n).' · '.$m.PHP_EOL;}
try{
 $q->locked(function()use($q){try{$q->register('A',true);}catch(RuntimeException $e){if($e->getMessage()!=='Simulated interruption before N')throw $e;}});
 $q->locked(function()use($q){check($q->nodes()===[],'Preparación Q/R no da visibilidad antes de N');$a=$q->register('A');check($a['index']===0&&!$a['replayed'],'Recuperación de registro N');});
 $e=['op'=>'contract','types'=>['Producto'],'fields'=>[['table'=>'Producto','name'=>'Stock','domain'=>'natural','allow'=>['SET','SUB'],'constitutive'=>true]],'actions'=>[]];$raw=QipuDemo::frame(101,QipuDemo::json($e));
 $q->locked(function()use($q,$raw){$q->submit('A',0,0,$raw);try{$q->decide('A',0,1,true);}catch(RuntimeException $e){if($e->getMessage()!=='Simulated interruption after C')throw $e;}});
 $q->locked(function()use($q){check($q->cut('RA')['end']===0,'C constituida antes de R');$before=$q->cut('C');$p=$q->pending();check($p['nodes']['A']['responses']===1&&$q->read('RA',0,1)['bytes']==="\x80",'Recuperación exacta R=1');$q->decide('A',0,1);check($q->cut('C')===$before,'Reintento no duplica contrato');check($p['canonical']['types']===['Producto']&&$p['canonical']['tables']===[],'Contrato recuperado sin materializar datos');});
 echo "TOTAL $n/$n\n";
}finally{foreach(glob($root.'/*')?:[] as $x)unlink($x);rmdir($root);}
