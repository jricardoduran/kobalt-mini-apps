"""UI real y persistencia IndexedDB. Salida 77 si Chromium bloquea el entorno."""
import os,sys,pathlib,tempfile,subprocess,socket,time,urllib.request,signal
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='qipu-meta-browser-') as tmp:
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 base=f'http://127.0.0.1:{port}';log=open(pathlib.Path(tmp)/'server.log','w');server=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root/'public')],env={**os.environ,'QIPU_ROOT':tmp},stdout=log,stderr=log,start_new_session=True)
 count=0
 def check(b,msg):
  global count
  assert b,msg;count+=1;print(f'PASS {count} · {msg}',flush=True)
 try:
  for _ in range(100):
   try:
    with urllib.request.urlopen(base+'/api.php?op=nodes',timeout=1) as r:r.read()
    break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('PHP no inicia')
  with sync_playwright() as p:
   b=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox']);ctx=b.new_context();pg=ctx.new_page()
   try:pg.goto(base+'/',timeout=7000)
   except Exception as e:
    if 'ERR_BLOCKED_BY_ADMINISTRATOR' not in str(e):raise
    print('BLOQUEADO: '+str(e).splitlines()[0]);b.close();sys.exit(77)
   def ready(page):page.wait_for_function("document.querySelector('#message').textContent.includes('Listo')")
   def click(page,id):page.locator('#'+id).click();page.wait_for_function('!busy');assert 'bad' not in (page.locator('#message').get_attribute('class') or ''),page.locator('#message').inner_text()
   def pick(page,n):page.fill('#node',n);click(page,'openNode')
   def decide(page,n):click(page,'pending');page.locator('#queue .record').filter(has_text='Nodo '+n+':').get_by_role('button',name='Aceptar',exact=True).click();page.wait_for_function('!busy');assert 'bad' not in page.locator('#message').get_attribute('class')
   def save(page):return page.evaluate('async()=>{let s=await load(node);return Array.from(s.L)}')
   ready(pg);check(pg.evaluate('isSecureContext && !!indexedDB && !!crypto.subtle'),'Contexto seguro e IndexedDB nativo');pick(pg,'Tienda');pg.uncheck('#online');click(pg,'template');click(pg,'recordDraft');check(pg.evaluate('working.state.types.includes("Producto") && working.state.tables.length===0'),'Contrato no materializa tabla');pg.fill('#factId','SKU-A');pg.select_option('#factTable','Producto');pg.select_option('#factField','Nombre');pg.fill('#factValue input','Camisa');click(pg,'recordFact');pg.select_option('#factField','Stock');pg.fill('#factValue input','20');click(pg,'recordFact');check(pg.evaluate('working.state.tables[0].vectors.find(v=>v.name==="Stock").values[0]===20'),'Formulario generado y stock offline');pg.select_option('#actionName','Venta-v1');pg.locator('#actionRows .line>input').fill('SKU-A');pg.locator('#actionRows input[type=number]').nth(0).fill('5');pg.locator('#actionRows input[type=number]').nth(1).fill('35000');click(pg,'recordAction');check(pg.evaluate('working.state.history[0].measure===175000 && working.state.tables[0].vectors.find(v=>v.name==="Stock").values[0]===15'),'Acción compuesta generada');before=save(pg);pg.reload();ready(pg);pick(pg,'Tienda');check(save(pg)==before,'Recarga conserva L');click(pg,'publish');check(save(pg)==before,'Publicación no cambia L');
   for _ in range(4):decide(pg,'Tienda')
   click(pg,'readR');click(pg,'readC');check(pg.evaluate('working.state.tables[0].vectors.find(v=>v.name==="Stock").values[0]===15 && canonical.state.history.length===1'),'R/C no duplica venta');q=b.new_context().new_page();q.goto(base+'/');ready(q);pick(q,'Otra');click(q,'readC');check(q.evaluate('JSON.stringify(canonical.state)')==pg.evaluate('JSON.stringify(canonical.state)'),'Otra localidad converge');tab=ctx.new_page();tab.goto(base+'/');ready(tab);pick(tab,'Tienda');pg.uncheck('#online');tab.uncheck('#online');click(pg,'note');tab.locator('#note').click();tab.wait_for_function('!busy');check('Otro escritor' in tab.locator('#message').inner_text(),'Compare-and-append rechaza pestaña obsoleta');click(tab,'rebuild');click(tab,'note');check(tab.evaluate('local.history.length===6'),'Recorrido y extensión posterior');b.close()
  print(f'TOTAL {count}/{count}')
 finally:os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=10);log.close()
