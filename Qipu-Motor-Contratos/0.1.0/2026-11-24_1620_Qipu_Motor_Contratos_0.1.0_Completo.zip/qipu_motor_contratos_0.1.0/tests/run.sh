#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=$(mktemp -d)
PORT=${QIPU_PORT:-18942}
QIPU_ROOT="$D" PHP_CLI_SERVER_WORKERS=4 php -S "127.0.0.1:$PORT" -t public >"$D/server.log" 2>&1 &
PID=$!
trap 'pkill -P "$PID" 2>/dev/null || true; kill "$PID" 2>/dev/null || true; rm -rf "$D"' EXIT
sleep .5
QIPU_URL="http://127.0.0.1:$PORT/api.php" node tests/motor.cjs
php tests/recovery.php
