<?php
require __DIR__.'/../src/Qipu.php';
$r=QipuDemo::replay(stream_get_contents(STDIN));echo QipuDemo::json(QipuDemo::view($r['state']));
