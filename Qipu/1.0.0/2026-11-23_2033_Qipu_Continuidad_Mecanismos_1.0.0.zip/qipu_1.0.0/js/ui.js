/* UI = consultas a demanda. No interpreta stock ni modifica directamente celdas.
 El único camino para constituir hechos es Continuidad.append/replace.
 Las futuras vistas bulk se limitan a leer un vector y emitir contratos. */
'use strict';
(async()=>{
 const $=id=>document.getElementById(id),C=Qipu.Continuidad,S=Qipu.Storage,E=Qipu.Ejemplos;
 const el=(tag,text,cls)=>{const x=document.createElement(tag);if(text!==undefined)x.textContent=text;if(cls)x.className=cls;return x;};
 let db;const status=(s,bad=false)=>{$('status').textContent=s;$('status').className='status'+(bad?' error':'');};
 const select=(node,items,label,value)=>{const old=node.value;node.replaceChildren(...items.map(i=>{const o=el('option',label(i));o.value=value(i);return o;}));if([...node.options].some(o=>o.value===old))node.value=old;};
 const table=(node,headers,rows)=>{const t=el('table'),head=el('thead'),hr=el('tr');headers.forEach(h=>hr.append(el('th',h)));head.append(hr);t.append(head);const body=el('tbody');for(const row of rows){const r=el('tr');for(const cell of row)r.append(el('td',String(cell)));body.append(r);}t.append(body);node.replaceChildren(t);};
 async function refresh(){const m=await C.getMeta(db),ts=await C.tables(db);$('metrics').replaceChildren(...[['Registros',m.seq],['Bytes',m.offset],['Tablas',ts.length],['Vectores',ts.reduce((n,t)=>n+t.vectors,0)]].map(([l,v])=>{const b=el('div',undefined,'metric');b.append(el('small',l),el('strong',v));return b;}));for(const id of ['table','pTable'])select($(id),ts,t=>`${t.id} · ${t.name}`,t=>t.id);await changeTable();await changePTable();$('vectorView').textContent='Consulta un vector para mostrar sus posiciones.';$('json').textContent='Selecciona una entidad.';$('logView').replaceChildren();$('salesView').replaceChildren();}
 async function changeTable(){const t=$('table').value;select($('vector'),t===''?[]:await C.vectors(db,+t),v=>`${v.id} · ${v.name} (${Qipu.Contratos.kinds[v.kind]})`,v=>v.id);}
 async function changePTable(){const t=$('pTable').value;select($('entity'),t===''?[]:await C.identities(db,+t),i=>`${i.id} · ${i.identity}`,i=>i.id);}
 function bind(id,fn){$(id).addEventListener('click',async()=>{const b=$(id);b.disabled=true;try{await fn();}catch(e){status(e.message,true);}finally{b.disabled=false;}});}
 try{db=await S.open();await refresh();status('IndexedDB abierto. Carga un ejemplo o importa una trayectoria.');}catch(e){status(e.message,true);return;}
 const load=async(list)=>{if(!confirm('¿Reemplazar la continuidad local por este ejemplo?'))return;const m=await C.replace(db,await E.binary(list));await refresh();status(`Continuidad constituida: ${m.seq} registros, ${m.offset} bytes.`);};
 bind('load',()=>load(E.events));bind('base',()=>load([...E.base,...E.ops]));bind('rebuild',async()=>{const m=await C.rebuild(db);await refresh();status(`Derivados reconstruidos desde ${m.seq} registros, sin alterar el log.`);});
 bind('download',async()=>{const b=await C.exportBytes(db),url=URL.createObjectURL(new Blob([b],{type:'application/octet-stream'})),a=el('a');a.href=url;a.download='continuidad.qipu';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
 bind('import',async()=>$('file').click());$('file').onchange=async()=>{try{const f=$('file').files[0];if(f&&confirm('¿Reemplazar la trayectoria local con este archivo?')){const m=await C.replace(db,new Uint8Array(await f.arrayBuffer()));await refresh();status(`Importación validada: ${m.seq} registros.`);}}catch(e){status(e.message,true);}finally{$('file').value='';}};
 $('table').onchange=()=>changeTable().catch(e=>status(e.message,true));$('pTable').onchange=()=>changePTable().catch(e=>status(e.message,true));
 bind('viewVector',async()=>{if($('vector').value==='')return;const t=+$('table').value,v=+$('vector').value,ids=await C.identities(db,t),r=await C.readVector(db,t,v);table($('vectorView'),['Posición i','Identidad (solo presentación)',r.vec.name],r.values.map((x,i)=>[i,ids[i]?.identity,x===undefined?'⊥ ausente':JSON.stringify(x)]));});
 bind('project',async()=>{if($('entity').value==='')return;$('json').textContent=JSON.stringify(await C.project(db,+$('pTable').value,+$('entity').value),null,2);});
 bind('readLog',async()=>{const log=await C.log(db),rows=[];let offset=0;for(let i=0;i<log.length;i++){const f=await Qipu.K5B.read(log[i]),e=Qipu.Contratos.decode(f.t,f.body);rows.push([i,offset,log[i].length,Qipu.Contratos.names[f.t],JSON.stringify(e.a),Array.from(f.hash.slice(0,6),x=>x.toString(16).padStart(2,'0')).join('')+'…']);offset+=log[i].length;}table($('logView'),['Secuencia','Offset','Bytes','Contrato','Argumentos','Hash (prefijo)'],rows);});
 bind('readSales',async()=>{table($('salesView'),['Registro','Tabla','Vector','Líneas (i,q,precio)','Total COP'],(await C.sales(db)).map(s=>[s.seq,s.table,s.vector,JSON.stringify(s.lines),s.total.toLocaleString('es-CO')]));});
 $('tabs').onclick=e=>{const tab=e.target.dataset.tab;if(!tab)return;for(const b of $('tabs').querySelectorAll('button'))b.classList.toggle('active',b===e.target);for(const section of document.querySelectorAll('[data-view]'))section.hidden=section.dataset.view!==tab;};
 bind('run',async()=>{const rows=[];$('results').textContent='Ejecutando…';const result=await Qipu.Pruebas.run(r=>{rows.push([r.prueba,r.estado,r.detalle,r.ms]);table($('results'),['Prueba','Estado','Detalle','ms'],rows);});window.QIPU_TEST_RESULT=result;status(result.ok?'Todas las pruebas pasaron.':'Hay pruebas fallidas.',!result.ok);});
 window.QIPU_LAB={db,refresh};
})();
