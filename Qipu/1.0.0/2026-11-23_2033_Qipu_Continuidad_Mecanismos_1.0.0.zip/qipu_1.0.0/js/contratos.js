/* Contratos de ejemplo, NO parte del mecanismo binario. Posiciones K2P-4;
 cantidades, precios, longitudes de texto K2P-6 (enteros JS seguros). */
'use strict';
Qipu.Contratos=(()=>{
 const {Writer,Reader,need}=Qipu.K2P;
 const names={1:'CONSTITUIR_TABLA',2:'CONSTITUIR_VECTOR',3:'CONSTITUIR_ENTIDAD',4:'SET_TEXTO',5:'STOCK_SET',6:'STOCK_ADD',7:'VENTA',8:'SET_NATURAL',9:'SET_NULO',10:'QUITAR_VALOR',11:'SET_BOOLEANO',12:'STOCK_SUB'};
 const kinds=['texto','natural','stock','booleano'];
 function fields(t,a){const w=new Writer(),p=n=>w.n(n),v=n=>w.n(n,6),s=x=>w.text(x);switch(t){case 1:s(a[0]);break;case 2:p(a[0]);s(a[1]);p(a[2]);break;case 3:p(a[0]);s(a[1]);break;case 4:p(a[0]);p(a[1]);p(a[2]);s(a[3]);break;case 5:case 6:case 8:case 12:p(a[0]);p(a[1]);p(a[2]);v(a[3]);break;case 7:p(a[0]);p(a[1]);p(a[2].length);for(const [i,q,price] of a[2]){p(i);v(q);v(price);}break;case 9:case 10:p(a[0]);p(a[1]);p(a[2]);break;case 11:p(a[0]);p(a[1]);p(a[2]);need(typeof a[3]==='boolean','Booleano requerido');p(+a[3]);break;default:throw Error('Contrato desconocido');}return w.bytes();}
 async function encode(t,...a){return Qipu.K5B.seal(t,fields(t,a));}
 function decode(t,b){const r=new Reader(b),p=()=>r.n(),v=()=>r.n(6),s=()=>r.text();let a;switch(t){case 1:a=[s()];break;case 2:a=[p(),s(),p()];break;case 3:a=[p(),s()];break;case 4:a=[p(),p(),p(),s()];break;case 5:case 6:case 8:case 12:a=[p(),p(),p(),v()];break;case 7:{const table=p(),vec=p(),n=p();need(n>0,'Venta vacía');const lines=[];for(let j=0;j<n;j++)lines.push([p(),v(),v()]);a=[table,vec,lines];break;}case 9:case 10:a=[p(),p(),p()];break;case 11:{a=[p(),p(),p()];let x=p();need(x<=1,'Booleano inválido');a.push(!!x);break;}default:throw Error('Contrato desconocido');}r.finish();return {t,a};}
 return {names,kinds,encode,decode};
})();
