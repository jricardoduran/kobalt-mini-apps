/* Pruebas reales en IndexedDB del navegador, siempre en una base aislada. */
'use strict';
Qipu.Pruebas=(()=>{
 const C=Qipu.Continuidad,S=Qipu.Storage,E=Qipu.Ejemplos,K=Qipu.K2P,B=Qipu.K4B;
 const assert=(ok,msg)=>{if(!ok)throw Error(msg||'Aserción fallida');};
 const eq=(a,b)=>assert(JSON.stringify(a)===JSON.stringify(b),`No coincide: ${JSON.stringify(a)} / ${JSON.stringify(b)}`);
 async function rejects(f){let bad=false;try{await f();}catch{bad=true;}assert(bad,'Debió rechazar');}
 async function run(onResult=()=>{}){
 const name='qipu-test-'+Date.now()+'-'+Math.random().toString(36).slice(2),results=[];let db=await S.open(name);
 const record=async(label,f)=>{const start=performance.now();try{const detail=await f();results.push({prueba:label,estado:'OK',detalle:detail,ms:Math.round(performance.now()-start)});}catch(e){results.push({prueba:label,estado:'ERROR',detalle:e.message,ms:Math.round(performance.now()-start)});}onResult(results.at(-1));};
 const append=(...a)=>Qipu.Contratos.encode(...a).then(b=>C.append(db,b));const stock=async()=> (await C.readVector(db,0,2)).values;
 try{
  const frames=await E.frames(), bytes=B.cat(...frames), baseline=await E.binary([...E.base,...E.ops]);
  await record('K2P-4 exhaustivo y K2P-6 extendido',()=>{for(let n=0;n<65536;n++){const w=new K.Writer();w.n(n);const r=new K.Reader(w.bytes());assert(r.n()===n);r.finish();}for(const n of [0,65536,120000,2**32,Number.MAX_SAFE_INTEGER]){const w=new K.Writer().n(n,6),r=new K.Reader(w.bytes());eq(r.n(6),n);r.finish();}return '65.536 naturales + 5 límites extendidos';});
  await record('K4B autónomo y K5B con tratamiento',async()=>{for(const n of [0,1,255,256,65535,65536]){const a=new Uint8Array(n).fill(71),f=await B.seal(a);const p=await B.read(f);assert(B.equal(a,p.body)&&p.end===f.length);}const f=frames[0].slice();f[0]^=1;await rejects(()=>Qipu.K5B.read(f));return '6 tamaños de frontera; T comprometido';});
  await record('Truncamientos de todos los registros',async()=>{let count=0;for(const f of frames){for(let i=0;i<f.length;i++){await rejects(()=>Qipu.K5B.read(f.slice(0,i)));count++;}}return `${count} prefijos incompletos rechazados`;});
  await record('Mutaciones de un bit en venta múltiple',async()=>{const f=frames[19];for(let i=0;i<f.length*8;i++){const g=f.slice();g[i>>3]^=1<<(i&7);await rejects(()=>Qipu.K5B.read(g));}return `${f.length*8} bits alterados, todos rechazados`;});
  await record('Reconstrucción base en IndexedDB',async()=>{await C.replace(db,baseline);eq(await stock(),[17,11,7]);eq((await C.sales(db)).map(s=>s.total),[130000,445000]);eq(await C.resolve(db,0,'B'),1);eq((await C.project(db,0,1)).parameters.stock,11);return '20 registros; stock 17/11/7; ventas $130.000 y $445.000';});
  await record('Rechazos comerciales sin cambios',async()=>{const before=await C.exportBytes(db),m=await C.getMeta(db);for(const e of [[5,0,2,3,1],[7,0,2,[[1,6,1],[1,6,1]]],[7,0,2,[[0,1,1],[2,99,1]]],[7,0,2,[[1,0,1]]],[4,0,2,1,'mal'],[3,0,'B'],[2,0,'stock',2],[6,0,2,1,0],[12,0,2,1,99]])await rejects(()=>append(...e));eq(await stock(),[17,11,7]);eq(await C.getMeta(db),m);assert(B.equal(await C.exportBytes(db),before));return '9 rechazos; log, cursor y stock intactos';});
  await record('Importación inválida revierte toda la transacción',async()=>{const before=await C.exportBytes(db);await rejects(()=>C.replace(db,B.cat(baseline,awaitableInvalid())));function awaitableInvalid(){return Uint8Array.of(0,1,2);}const invalid=await Qipu.Contratos.encode(5,0,2,99,1);await rejects(()=>C.replace(db,B.cat(baseline,invalid)));assert(B.equal(await C.exportBytes(db),before));eq(await stock(),[17,11,7]);return 'Truncamiento y referencia futura; base previa preservada';});
  await record('Recorrido extendido y posición compartida',async()=>{for(const f of frames.slice(20))await C.append(db,f);eq(await stock(),[17,8,9,6]);eq((await C.readVector(db,0,3)).values,[null,'Negro',undefined,undefined]);eq((await C.readVector(db,0,4)).values,[true,false,undefined,undefined]);eq((await C.project(db,1,0)).parameters.nombre,'Ropa');eq(await C.resolve(db,0,'D'),3);eq((await C.sales(db)).map(s=>s.total),[130000,445000,195000]);return '2 tablas, 5 vectores de productos, nulo/ausente, cuarta entidad y líneas repetidas';});
  await record('Replay completo = incremental',async()=>{const before=await C.project(db,0,1);assert(B.equal(await C.exportBytes(db),bytes));await C.replace(db,bytes);eq(await C.project(db,0,1),before);eq(await stock(),[17,8,9,6]);return `${frames.length} registros; mismo estado`});
  await record('Eliminar materializaciones y reconstruir desde log',async()=>{await S.tx(db,[...S.derived,'meta'],'readwrite',async x=>{for(const s of S.derived)await x.clear(s);await x.clear('meta');});eq(await C.tables(db),[]);assert(B.equal(await C.exportBytes(db),bytes));await C.rebuild(db);eq(await stock(),[17,8,9,6]);eq((await C.sales(db)).length,3);eq(await C.resolve(db,0,'B'),1);return 'Tablas, vectores, celdas, índices, ventas y cursor reconstruidos';});
  await record('Persistencia al cerrar y reabrir IndexedDB',async()=>{db.close();db=await S.open(name);eq(await stock(),[17,8,9,6]);eq((await C.getMeta(db)).seq,frames.length);return 'Estado y cursor conservados al reabrir conexión';});
  await record('Dos ventas concurrentes del último stock',async()=>{await append(5,0,2,1,1);const f=await Qipu.Contratos.encode(7,0,2,[[1,1,65000]]);const out=await Promise.allSettled([C.append(db,f),C.append(db,f)]);eq(out.filter(x=>x.status==='fulfilled').length,1);eq((await stock())[1],0);return 'Una aceptada, una rechazada; stock 0';});
  await record('Ventas iguales legítimas no se deduplican por hash',async()=>{await append(5,0,2,1,2);const f=await Qipu.Contratos.encode(7,0,2,[[1,1,65000]]);const n=(await C.sales(db)).length;await C.append(db,f);await C.append(db,f);eq((await stock())[1],0);eq((await C.sales(db)).length,n+2);return 'Dos hechos iguales en posiciones distintas';});
  return {version:'1.0.0',registros:frames.length,bytes:bytes.length,pruebas:results,ok:results.every(x=>x.estado==='OK')};
 }finally{db.close();await S.remove(name);}
 }
 return {run};
})();
