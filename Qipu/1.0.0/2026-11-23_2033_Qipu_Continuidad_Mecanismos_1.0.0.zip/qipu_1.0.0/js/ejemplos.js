'use strict';
Qipu.Ejemplos=(()=>{
 const base=[[1,'Productos'],[2,0,'nombre',0],[2,0,'precio',1],[2,0,'stock',2]];
 for(const [i,id,n,p,q] of [[0,'A','Camisa',35000,20],[1,'B','Pantalón',65000,15],[2,'C','Zapato',80000,8]])base.push([3,0,id],[4,0,0,i,n],[8,0,1,i,p],[5,0,2,i,q]);
 const ops=[[5,0,2,1,12],[6,0,2,1,5],[7,0,2,[[1,2,65000]]],[7,0,2,[[0,3,35000],[1,4,65000],[2,1,80000]]]];
 const extended=[[2,0,'color',0],[4,0,3,1,'Negro'],[2,0,'activo',3],[11,0,4,0,true],[11,0,4,1,false],[9,0,3,0],[1,'Categorías'],[2,1,'nombre',0],[3,1,'CAT-A'],[4,1,0,0,'Ropa'],[6,0,2,2,3],[12,0,2,2,1],[7,0,2,[[1,1,65000],[1,2,65000]]],[3,0,'D'],[4,0,0,3,'Abrigo'],[8,0,1,3,120000],[5,0,2,3,6]];
 const events=[...base,...ops,...extended];
 async function frames(list=events){return Promise.all(list.map(([t,...a])=>Qipu.Contratos.encode(t,...a)));}
 async function binary(list=events){return Qipu.K4B.cat(...await frames(list));}
 return {base,ops,extended,events,frames,binary};
})();
