/* El único intérprete constitutivo. UI no modifica derivados directamente. */
'use strict';
Qipu.Continuidad=(()=>{
 const {need}=Qipu.K2P,{stores,derived,tx,range}=Qipu.Storage;
 const zero=()=>({seq:0,offset:0,tables:0});
 const sum=(a,b)=>{let n=a+b;need(Number.isSafeInteger(n)&&n>=0,'Desbordamiento o stock negativo');return n;};
 const product=(a,b)=>{let n=a*b;need(Number.isSafeInteger(n)&&n>=0,'Total fuera de dominio');return n;};
 async function apply(x,e,m){const {t,a}=e;let [table,v,i,value]=a;
  if(t===1){need(a[0].length>0,'Nombre vacío');need(!await x.index('tables','name',a[0]),'Tabla duplicada');need(m.tables<65536,'Límite tablas');await x.put('tables',m.tables,{id:m.tables,name:a[0],entities:0,vectors:0});m.tables++;return;}
  const tab=await x.get('tables',table);need(tab,'Tabla no constituida');
  if(t===2){need(a[1].length>0&&Qipu.Contratos.kinds[a[2]],'Vector inválido');need(!await x.index('vectors','name',[table,a[1]]),'Vector duplicado');need(tab.vectors<65536,'Límite vectores');await x.put('vectors',[table,tab.vectors],{table,id:tab.vectors,name:a[1],kind:a[2]});tab.vectors++;await x.put('tables',table,tab);return;}
  if(t===3){need(a[1].length>0,'Identidad vacía');need(!await x.index('entities','identity',[table,a[1]]),'Identidad duplicada');need(tab.entities<65536,'Límite entidades');await x.put('entities',[table,tab.entities],{table,id:tab.entities,identity:a[1]});tab.entities++;await x.put('tables',table,tab);return;}
  const vec=await x.get('vectors',[table,v]);need(vec,'Vector no constituido');
  const key=i=>[table,v,i],valid=i=>need(Number.isInteger(i)&&i>=0&&i<tab.entities,'Posición no constituida');
  if(t===7){need(vec.kind===2,'Venta exige vector stock');const totals=new Map();let total=0;for(const [idx,q,price] of a[2]){valid(idx);need(q>0,'Cantidad debe ser positiva');totals.set(idx,sum(totals.get(idx)||0,q));total=sum(total,product(q,price));}const updates=[];for(const [idx,q] of totals){const old=await x.get('cells',key(idx));need(Number.isSafeInteger(old)&&old>=q,'Stock insuficiente o no asignado');updates.push([idx,old-q]);}for(const [idx,n] of updates)await x.put('cells',key(idx),n);await x.put('sales',m.seq,{seq:m.seq,table,vector:v,lines:a[2],total});return;}
  valid(i);const k=key(i);
  if(t===4){need(vec.kind===0,'Tipo texto requerido');await x.put('cells',k,value);}
  else if(t===8){need(vec.kind===1,'Tipo natural requerido');await x.put('cells',k,value);}
  else if(t===11){need(vec.kind===3,'Tipo booleano requerido');await x.put('cells',k,value);}
  else if(t===9){need(vec.kind!==2,'Stock no admite null');await x.put('cells',k,null);}
  else if(t===10){need(vec.kind!==2,'Stock no admite quitar valor');await x.del('cells',k);}
  else if([5,6,12].includes(t)){need(vec.kind===2,'Vector stock requerido');let n=value;if(t!==5){const old=await x.get('cells',k);need(Number.isSafeInteger(old)&&value>0,'Stock no asignado o diferencial inválido');n=sum(old,t===6?value:-value);}await x.put('cells',k,n);}
  else throw Error('Contrato desconocido');
 }
 async function parse(raw){const b=raw instanceof Uint8Array?raw:new Uint8Array(raw);const r=await Qipu.K5B.read(b);need(r.end===b.length,'Bytes adicionales en registro');return {raw:b,event:Qipu.Contratos.decode(r.t,r.body)};}
 async function scan(bytes){let p=0;const records=[];while(p<bytes.length){try{const r=await Qipu.K5B.read(bytes,p);const event=Qipu.Contratos.decode(r.t,r.body);records.push({raw:bytes.slice(p,r.end),event});p=r.end;}catch(e){return {records,offset:p,error:e.message};}}return {records,offset:p,error:null};}
 async function applyRecord(x,r,m,writeLog){await apply(x,r.event,m);if(writeLog)await x.put('log',m.seq,r.raw);m.seq++;m.offset+=r.raw.length;}
 async function append(db,raw){const r=await parse(raw);return tx(db,stores,'readwrite',async x=>{const m=await x.get('meta','cursor')||zero();await applyRecord(x,r,m,true);await x.put('meta','cursor',m);return m;});}
 async function replace(db,bytes){const parsed=await scan(bytes);need(!parsed.error,`Importación rechazada en byte ${parsed.offset}: ${parsed.error}`);return tx(db,stores,'readwrite',async x=>{for(const s of stores)await x.clear(s);const m=zero();for(const r of parsed.records)await applyRecord(x,r,m,true);await x.put('meta','cursor',m);return m;});}
 async function exportBytes(db){return tx(db,['log'],'readonly',async x=>Qipu.K4B.cat(...await x.all('log')));}
 async function rebuild(db){/* Snapshot consistente del log; detectar modificaciones concurrentes con igualdad de bytes. */
  const bytes=await exportBytes(db),parsed=await scan(bytes);need(!parsed.error,'Log inválido: '+parsed.error);
  return tx(db,stores,'readwrite',async x=>{const actual=Qipu.K4B.cat(...await x.all('log'));need(Qipu.K4B.equal(bytes,actual),'Log cambió durante reconstrucción; reintente');for(const s of derived)await x.clear(s);const m=zero();for(const r of parsed.records)await applyRecord(x,r,m,false);await x.put('meta','cursor',m);return m;});
 }
 const getMeta=db=>tx(db,['meta'],'readonly',async x=>await x.get('meta','cursor')||zero());
 const tables=db=>tx(db,['tables'],'readonly',x=>x.all('tables'));
 const vectors=(db,t)=>tx(db,['vectors'],'readonly',x=>x.all('vectors',range(t)));
 const identities=(db,t)=>tx(db,['entities'],'readonly',x=>x.all('entities',range(t)));
 const resolve=(db,t,identity)=>tx(db,['entities'],'readonly',async x=>(await x.index('entities','identity',[t,identity]))?.id);
 async function readVector(db,t,v){return tx(db,['tables','vectors','cells'],'readonly',async x=>{const tab=await x.get('tables',t),vec=await x.get('vectors',[t,v]);need(tab&&vec,'Vector inexistente');const vals=[];for(let i=0;i<tab.entities;i++)vals.push(await x.get('cells',[t,v,i]));return {vec,values:vals};});}
 async function project(db,t,i){return tx(db,['entities','vectors','cells'],'readonly',async x=>{const entity=await x.get('entities',[t,i]);need(entity,'Entidad inexistente');const params=Object.create(null);for(const v of await x.all('vectors',range(t))){const val=await x.get('cells',[t,v.id,i]);if(val!==undefined)params[v.name]=val;}return {identity:entity.identity,parameters:params};});}
 const sales=db=>tx(db,['sales'],'readonly',x=>x.all('sales'));
 const log=db=>tx(db,['log'],'readonly',x=>x.all('log'));
 return {append,replace,scan,exportBytes,rebuild,getMeta,tables,vectors,identities,resolve,readVector,project,sales,log};
})();
