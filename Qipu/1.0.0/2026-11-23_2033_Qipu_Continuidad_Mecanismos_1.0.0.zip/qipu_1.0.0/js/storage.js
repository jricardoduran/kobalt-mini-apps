/* IndexedDB: log autoritativo + materializaciones desechables. Sin service worker.
 Un append confirmado y sus efectos/cursor se publican en UNA transacción. */
'use strict';
Qipu.Storage=(()=>{
 const stores=['log','tables','vectors','entities','cells','sales','meta'];
 const derived=['tables','vectors','entities','cells','sales'];
 const req=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});
 function open(name='qipu-continuidad-1.0.0'){return new Promise((res,rej)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{const d=r.result;for(const s of stores){const o=d.createObjectStore(s);if(s==='entities')o.createIndex('identity',['table','identity'],{unique:true});if(s==='vectors')o.createIndex('name',['table','name'],{unique:true});if(s==='tables')o.createIndex('name','name',{unique:true});}};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);r.onblocked=()=>rej(Error('Base bloqueada'));});}
 async function tx(db,ss,mode,fn){const t=db.transaction(ss,mode);const done=new Promise((res,rej)=>{t.oncomplete=res;t.onabort=()=>rej(t.error||Error('Transacción abortada'));t.onerror=()=>{};});done.catch(()=>{});const api={get:(s,k)=>req(t.objectStore(s).get(k)),all:(s,range)=>req(t.objectStore(s).getAll(range)),keys:(s)=>req(t.objectStore(s).getAllKeys()),put:(s,k,v)=>req(t.objectStore(s).put(v,k)),del:(s,k)=>req(t.objectStore(s).delete(k)),clear:s=>req(t.objectStore(s).clear()),index:(s,i,k)=>req(t.objectStore(s).index(i).get(k))};try{const x=await fn(api);await done;return x;}catch(e){try{t.abort();}catch{}await done.catch(()=>{});throw e;}}
 const range=(...prefix)=>IDBKeyRange.bound(prefix,[...prefix,Infinity]);
 function remove(name){return new Promise((res,rej)=>{const r=indexedDB.deleteDatabase(name);r.onsuccess=res;r.onerror=()=>rej(r.error);r.onblocked=()=>rej(Error('Base bloqueada'));});}
 return {stores,derived,open,tx,range,remove};
})();
