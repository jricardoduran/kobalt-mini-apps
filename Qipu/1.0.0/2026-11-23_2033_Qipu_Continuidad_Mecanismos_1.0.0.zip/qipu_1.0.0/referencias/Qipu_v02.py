"""Qipu v0.2, experimental reference. Python 3 standard library only."""
import hashlib, copy, json
D=b'QIPU-K5B-v02\0'
def k2(n):
    if type(n)!=int or not 0<=n<65536: raise ValueError('K2P-4 range')
    k=max(1,n.bit_length()); return f'{k-1:04b}'+f'{n:0{k}b}'
class Reader:
    def __init__(self,b): self.b=b; self.p=0
    def take(self,k):
        if self.p+k>len(self.b): raise ValueError('truncated field')
        x=self.b[self.p:self.p+k]; self.p+=k; return x
    def n(self):
        k=int(self.take(4),2)+1; n=int(self.take(k),2)
        if max(1,n.bit_length())!=k: raise ValueError('noncanonical natural')
        return n
    def text(self): return bytes(int(self.take(8),2) for _ in range(self.n())).decode()
    def finish(self):
        if len(self.b)-self.p>=8 or '1' in self.b[self.p:]: raise ValueError('noncanonical padding')
def txt(s):
    b=s.encode(); return k2(len(b))+''.join(f'{x:08b}' for x in b)
def pack(bits): return bytes(int((bits+'0'*((-len(bits))%8))[i:i+8],2) for i in range(0,len(bits),8))
def frame(t,b):
    k=max(1,(len(b).bit_length()+7)//8); prefix=t.to_bytes(2,'big')+bytes([k-1])+len(b).to_bytes(k,'big')+b
    return prefix+hashlib.sha256(D+prefix).digest()
def parse(data,p):
    start=p
    if len(data)-p<3: raise ValueError('partial header')
    t=int.from_bytes(data[p:p+2],'big'); k=data[p+2]+1; p+=3
    if k>4 or len(data)-p<k: raise ValueError('length header')
    l=int.from_bytes(data[p:p+k],'big'); p+=k
    if k!=max(1,(l.bit_length()+7)//8) or l>1048576: raise ValueError('length')
    end=p+l; stop=end+32
    if stop>len(data) or hashlib.sha256(D+data[start:end]).digest()!=data[end:stop]: raise ValueError('integrity')
    return t,Reader(''.join(f'{x:08b}' for x in data[p:end])),stop
# T: 1 table, 2 vector, 3 entity, 4 text assignment, 5 stock assignment, 6 receipt, 7 sale, 8 numeric assignment

def event(t,*a):
    if t==1: bits=txt(a[0])
    elif t==2: bits=k2(a[0])+txt(a[1])+k2(a[2])
    elif t==3: bits=k2(a[0])+txt(a[1])
    elif t==4: bits=''.join(map(k2,a[:3]))+txt(a[3])
    elif t in (5,6,8): bits=''.join(map(k2,a))
    elif t==7:
        table,v,lines=a; bits=k2(table)+k2(v)+k2(len(lines))+''.join(k2(i)+k2(q)+k2(price) for i,q,price in lines)
    return frame(t,pack(bits))
def apply(state,t,r):
    s=copy.deepcopy(state) # reference only; implementation can stage just affected slots
    tables=s['tables']
    if t==1: tables.append({'name':r.text(),'ids':[],'vectors':[]})
    else:
        table=tables[r.n()]
        if t==2:
            name=r.text(); kind=r.n(); assert kind in (0,1,2)
            assert name not in [v['name'] for v in table['vectors']]
            table['vectors'].append({'name':name,'kind':kind,'values':[None]*len(table['ids'])})
        elif t==3:
            identity=r.text(); assert identity not in table['ids']; table['ids'].append(identity)
            for v in table['vectors']: v['values'].append(None)
        else:
            v=table['vectors'][r.n()]; values=v['values']
            if t==7:
                assert v['kind']==2; count=r.n(); assert count>0; lines=[]; totals={}
                for _ in range(count):
                    i,q,price=r.n(),r.n(),r.n(); assert q>0 and i<len(values) and values[i] is not None
                    totals[i]=totals.get(i,0)+q; lines.append([i,q,price])
                assert all(values[i]>=q for i,q in totals.items())
                for i,q in totals.items(): values[i]-=q
                s['sales'].append({'lines':lines,'total':sum(q*p for i,q,p in lines)})
            else:
                i=r.n(); assert i<len(values)
                if t==4: assert v['kind']==0; values[i]=r.text()
                elif t==8: assert v['kind']==1; values[i]=r.n()
                elif t==5: assert v['kind']==2; values[i]=r.n()
                elif t==6: assert v['kind']==2 and values[i] is not None; q=r.n(); assert q>0; values[i]+=q
                else: raise ValueError('unknown contract')
    r.finish(); return s
def empty(): return {'tables':[],'sales':[]}
def replay(data,state=None,p=0):
    s=empty() if state is None else state
    while p<len(data):
        try: t,r,end=parse(data,p); new=apply(s,t,r)
        except (ValueError,AssertionError,IndexError): break
        s,p=new,end
    return s,p
def project(s,i):
    t=s['tables'][0]; return {'sku':t['ids'][i],**{v['name']:v['values'][i] for v in t['vectors']}}
base=[event(1,'Productos'),event(2,0,'nombre',0),event(2,0,'precio',1),event(2,0,'stock',2)]
for i,(sku,n,p,q) in enumerate([('A','Camisa',35000,20),('B','Pantalon',65000,15),('C','Zapato',60000,8)]):
    base += [event(3,0,sku),event(4,0,0,i,n),event(8,0,1,i,p),event(5,0,2,i,q)]
ops=[event(5,0,2,1,12),event(6,0,2,1,5),event(7,0,2,[(1,2,65000)]),event(7,0,2,[(0,3,35000),(1,4,65000),(2,1,60000)])]
records=base+ops; data=b''.join(records); state,p=replay(data); assert p==len(data)
assert [project(state,i)['stock'] for i in range(3)]==[17,11,7]
assert [s['total'] for s in state['sales']]==[130000,425000]
checks=[]
for n in range(65536):
    r=Reader(k2(n)); assert r.n()==n and r.p==len(r.b)
checks.append(['K2P-4: todos los naturales',65536,'OK'])
for i in range(len(data)):
    s,q=replay(data[:i]); assert q==max([0]+[sum(map(len,records[:j])) for j in range(1,len(records)+1) if sum(map(len,records[:j]))<=i])
checks.append(['Truncamiento en cada offset',len(data),'OK'])
for j in range(len(ops[-1])*8):
    damaged=bytearray(ops[-1]); damaged[j//8]^=1<<(j%8); prefix=b''.join(records[:-1]); s,q=replay(prefix+damaged); assert q==len(prefix)
checks.append(['Mutación de cada bit de venta múltiple',len(ops[-1])*8,'OK'])
for j in range(len(records)+1):
    prefix=b''.join(records[:j]); s,q=replay(prefix); assert replay(data,s,q)==(state,p)
checks.append(['Replay incremental vs completo',len(records)+1,'OK'])
for bad in [event(5,0,2,3,1),event(7,0,2,[(1,6,1),(1,6,1)]),event(7,0,2,[(0,1,1),(2,99,1)])]:
    assert replay(data+bad)==(state,p)
checks.append(['Referencia futura / venta duplicada agregada / venta insuficiente',3,'OK'])
late=event(2,0,'color',0); s,q=replay(data+late); assert s['tables'][0]['vectors'][-1]['values']==[None]*3
checks.append(['Vector tardío alineado',1,'OK'])
print(json.dumps({'bytes':len(data),'records':len(records),'checks':checks,'products':[project(state,i) for i in range(3)],'sales':state['sales']},ensure_ascii=False,indent=2))
