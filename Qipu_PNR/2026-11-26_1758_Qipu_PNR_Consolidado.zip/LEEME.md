# Qipu PNR — edición consolidada de referencia (2026-11-26)

**Núcleo 0.2.0 + Autoridad PHP 0.1.0.** No cambia el protocolo, ni se presenta como una nueva versión criptográfica. Incluye las dos distribuciones del 25 de noviembre extraídas, con código, HTML y pruebas originales; `VERIFICACION_2026-11-26.txt` registra una nueva ejecución. No contiene registros de una autoridad instalada ni secretos reales.

## Entrada rápida
- `Qipu_PNR_0.2.0/PNR.html`: explicación matemática, calculadora y laboratorio Web Crypto local.
- `Qipu_PNR_0.2.0/README.md`: especificación exacta, formato, hipótesis, modelo de costos y referencias.
- `Qipu_PNR_Autoridad_0.1.0/public/guia.html`: explicación de la autoridad y ciclo de vida.
- Para probar la aplicación: `cd Qipu_PNR_Autoridad_0.1.0`; `php init.php`; `php -S 127.0.0.1:8080 -t public`; abrir http://127.0.0.1:8080/. Conservar el código de instalación y los dos secretos fuera de la app. Usar datos de ensayo. El servidor integrado es para desarrollo.

## Contrato e invariantes
PNR (Proyección Negativa y Reconocimiento) separa el descarte del reconocimiento. Con S aleatorio de 16 bytes, frame con longitud y etiquetas versionadas L (ver especificación exacta), K=SHA256(L||KEY\0||frame(B)); R=HMAC_K(L||ROOT\0||S||frame(A)); P=primer byte SHA256(L||FILTER\0||S||R); M=HKDF-SHA256(R,S,L||GENERATE,256 B); D=PBKDF2-HMAC-SHA256(M,S,600000,32 B); V=HMAC_R(L||VERIFY\0||S||D). Se persiste S||P||V (49 B); P no es autenticador, V debe coincidir. No se conservan A,B,K,R,M,D ni cifrados de esos materiales. Borrado de memoria solo de mejor esfuerzo, sin garantías sobre copias del runtime. No registrar cuerpos HTTP ni secretos. El sobre opcional AES-256-GCM suma 28 B (77 B) y exige clave externa separada, no activada en la demo.

## Matemática y seguridad
Si dos proyecciones difieren, sus raíces difieren con certeza; igualdad de proyecciones no implica igualdad de raíces. Bajo modelo pseudoaleatorio, probabilidad de supervivencia incorrecta 1/256; descarte 255/256 = 99.609375%. P tiene como máximo 8 bits de información adicional sobre la raíz, con ~2^248 raíces compatibles esperadas bajo modelo aleatorio; esto no equivale a seguridad de credenciales. El costo medio para falsos candidatos aleatorios es C0+C1/256; no es garantía bajo candidatos adaptativos. El filtro facilita intentos offline si se obtiene el registro, y tiempos pueden revelar supervivencia. Perfil experimental por defecto solo con al menos un secreto independiente de >=128 bits aleatorios, confidencial. Contraseñas humanas solas: preferir un verificador estándar sin filtro rápido. No se presume desconocimiento del algoritmo.

Cada candidato de credenciales cuesta 1 HMAC y 2 SHA explícitos (K se puede cachear); cada etapa profunda agrega 600010 HMAC lógicos (HKDF 9, PBKDF2 600000, final 1). Si N=2^h pares equiprobables, búsqueda sin repetición hasta el par original: E[Q]=(N+1)/2, E[D]=1+(N-1)/512, E[HMAC]=E[Q]+600010 E[D], ignorando falsas aceptaciones y colisiones. Con uno conocido, h corresponde al otro condicionado; con ambos conocidos basta una evaluación. Si R es uniforme en 256 bits, enumerar raíces hasta la original cuesta ~2^255 candidatos y ~2^247 evaluaciones profundas, o ~1.36×10^80 HMAC profundos. No es una cota contra todos los ataques, ni prueba de 256 bits de seguridad; buscar una raíz compatible no es lo mismo que conocer un par admitido. Para adivinar el procedimiento desconocido no existe costo universal; las fórmulas asumen código público. Las implementaciones paralelas y distribuciones no uniformes cambian los tiempos. No es MFA, prueba de conocimiento formal ni DCC.

## Autoridad y persistencia
JSON con versión, salt, negative y verifier en hex; nombre record-<SHA256 de bytes JSON>.json y ancla state.json. Registro exclusivo inicial con autorización CLI de un uso; luego sesión temporal; no hay reset HTTP. Falla cerrado ante ausencia o modificación del archivo referenciado. El hash detecta alteración respecto a un ancla confiable, no impide borrado o sustitución conjunta ni rollback. PAO, permisos y contratos externos al núcleo. No almacenar secretos reales en este ZIP. Usar TLS, límites de intentos y concurrencia, control de sesión y permisos; no auditado. PHP 8.1+ por diseño, pruebas PHP 8.4.24 y Node Web Crypto 22; navegador real y PHP 8.1 aún no comprobados.

## Procedencia
SHA-256 de los ZIP originales, antes de extraerlos:
- Núcleo: e91d17fc78bcf18919e49421cb0fbd8d557cb713f618fcf1ceb561086a1b6d53
- Autoridad: 0691572ff4d60a588a6b33620240037abfc287b19034a91efc9bd5720b2f2bda
