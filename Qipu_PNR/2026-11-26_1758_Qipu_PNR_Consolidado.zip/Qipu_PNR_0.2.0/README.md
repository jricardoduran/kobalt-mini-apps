# Qipu PNR 0.2.0 — perfil nativo multiplataforma

Mecanismo independiente de Kobalt para dos secretos. No modifica PAO ni el kernel. Perfil por defecto experimental para adaptadores con al menos un secreto independiente generado criptográficamente de 128 bits o más, mantenido confidencial. Para contraseñas humanas convencionales usar un verificador estándar sin filtro público. No auditado.

## Ejecución
- `PNR.html`: documentación autocontenida, calculadora y demostración local de Web Crypto con credenciales de prueba. No usa red ni persiste secretos. Si el navegador no ofrece `crypto.subtle` al abrir el archivo, servirlo en localhost o HTTPS.
- PHP >=8.1, extensión Hash (OpenSSL para el sobre opcional). Sodium opcional para limpieza de variables. `php tests/test.php`.
- JavaScript: `src/pnr.mjs` con Web Crypto nativo; sin Node, WASM, CDN o proveedor adicional en la aplicación. `node tests/interop.mjs` solo para pruebas cruzadas (Node 22 y PHP).

```php
require 'src/QipuPNR.php';
$r = QipuPNR::register($a, $b); // 49 bytes
$ok = QipuPNR::verify($a, $b, $r);
```
```js
import {createPNR} from './src/pnr.mjs';
const pnr = createPNR();
const r = await pnr.register(a,b);
const ok = await pnr.verify(a,b,r);
```

## Contrato 0.2.0
S=16 bytes aleatorios por registro, P=1 byte, V=32 bytes. Registro S||P||V, longitud 49 bytes; offsets 0,16,17. Guardar versión externamente. No es compatible con 0.1.0 (Argon2id y etiquetas distintas); migrar tras validar con la versión anterior y registrar con las credenciales introducidas, no convertir verificadores directamente. Texto de interfaz UTF-8 sin normalización implícita, o bytes. Entradas 1..4096 B. `frame(x)=u32be(len(x))||x`. `L=ASCII QIPU/PNR/0.2.0/`; `\0` es byte cero. HMAC y SHA retornan bytes crudos. HMAC(K,m) significa clave K, mensaje m.

1. K=SHA256(L||KEY\0||frame(B)).
2. R=HMAC-SHA256(K,L||ROOT\0||S||frame(A)).
3. P=primer byte SHA256(L||FILTER\0||S||R).
4. M=HKDF-SHA256(IKM=R,salt=S,info=L||GENERATE,L_salida=256 B).
5. D=PBKDF2-HMAC-SHA256(password=M,salt=S,c=600000,dkLen=32 B).
6. V=HMAC-SHA256(R,L||VERIFY\0||S||D).
7. Registro S||P||V. Al verificar, P discordante termina inmediatamente; P coincidente nunca autoriza; V debe coincidir.

No persistir A,B,K,R,M,D, ni sus versiones cifradas. El cifrado opcional protege únicamente el registro. La raíz R y la función son suficientes para calcular V; esto no permite presentar R como credencial al API. La generación no suma entropía a la raíz. No es MFA ni un mecanismo de cifrado de datos. PBKDF2 sustituye Argon2id para portabilidad, pero carece de su costo de memoria.

## Costo de búsqueda clásico: modelo explícito
Un intento preliminar desde A,B requiere 1 HMAC y 2 SHA256 explícitos (K puede cachearse para B fijo). La etapa profunda exige HKDF extract (1 HMAC), expand (8 HMAC), PBKDF2 (600000 HMAC para un bloque de 32 B) y HMAC final (1). Total profundo adicional: 600010 HMAC; intento completo: 600011 HMAC + 2 SHA explícitos. Son invocaciones lógicas, no compresiones SHA internas, ciclos, ni una cota demostrada contra todos los ataques. Las optimizaciones de implementación pueden reutilizar estados.

Para N=2^h pares equiprobables, orden de búsqueda sin repetición y posición uniforme del par original, E[Q]=(N+1)/2; E[F]=(N-1)/2 falsos antes del original. Si los filtros de raíces incorrectas son pseudoaleatorios independientes, E[profundas]=1+E[F]/256. E[HMAC]=E[Q]+600010*E[profundas]. Se ignoran colisiones de raíz y falsas aceptaciones despreciables bajo modelo ideal. Con secretos no uniformes usar distribución real y orden de probabilidad; no inferir h de longitud textual. Si A o B es conocido, h es la entropía del restante condicionado al conocimiento del atacante. Si ambos se conocen, basta una ejecución completa. P revela como máximo 8 bits adicionales de información, pero abarata hasta 256 veces las etapas profundas. Un atacante con registro completo y algoritmo puede ejecutar el mismo filtro. Con hardware paralelo la duración cambia; no hay predicción de seguridad temporal universal.

Buscar directamente R: si R es uniforme en 256 bits, búsqueda genérica de la raíz original por enumeración requiere en promedio ~2^255 candidatos y ~2^247 etapas profundas, bajo el mismo modelo y sin contar falsas aceptaciones. La proyección hash truncada tiene ~2^248 raíces compatibles esperadas (no exactas). Un R compatible con P no basta. Una raíz que reproduce P,V constituye evidencia offline, pero no un par admisible por el API; para obtener el par necesita buscar preimagen bajo la consolidación o poseer las entradas. No es necesario reconstruir R por separado para probar pares: se obtiene calculando HMAC. No existe un costo bien definido para adivinar un algoritmo desconocido; modelamos código público. Un atacante podría buscar otro par admitido, robar sesión, modificar el almacenamiento o capturar secretos durante el ingreso. Las cifras modelan búsqueda exhaustiva, no una demostración de optimalidad ni poscuanticidad. El tamaño de V no garantiza 256 bits de seguridad de contraseñas.

## Protección opcional del almacenamiento
AES-256-GCM: clave externa aleatoria de 32 B, nonce aleatorio 12 B, etiqueta 16 B; 77 B = nonce||cifrado de 49 B||tag. AAD = L||SEAL\0||u32be(len(id))||id. La clave debe permanecer separada del registro, puede derivarse por HKDF de una clave preexistente de alta entropía, no de datos públicos. Nunca repetir nonce con la misma clave; limitar volumen por clave según política GCM, rotar antes de volúmenes altos (como máximo 2^32 invocaciones por clave y preferiblemente mucho menos). Rotación y recuperación responsabilidad del adaptador. No usar una clave fija embebida en JS público. No compatible con sobres XChaCha anteriores. Sin secreto externo, registro en claro protegido por permisos. El sobre evita lectura y modificación por quien solo posee el archivo, no compromiso simultáneo de clave/proceso ni rollback.

## Integración
No guardar credenciales en URL, registros HTTP, trazas, dumps, IndexedDB o localStorage; controlar autocompletado y no utilizar secretos reales en tests. PHP/JS no garantizan borrado físico total de memoria. TLS, límites por identidad/origen y concurrencia, protección de sesiones, integridad de registro y autorización del alta, revocación, rollback y políticas de tiempo son externos. El tiempo de respuesta puede revelar coincidencia del filtro incluso sin robo de PAO; aplicar política de temporización externa según riesgo. Cualquier autenticación local puede ser alterada por quien controla el dispositivo; no sustituye autoridad remota. Si se requiere protección de datos locales, cifrarlos con mecanismo independiente. No exponer R como capacidad de ingreso. Para el perfil directo exigir secreto aleatorio de alta entropía, evitar reuso. Versionar todos los parámetros. Ver pruebas reales en tests/RESULTADOS.txt.

Referencias: https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/deriveBits ; https://www.php.net/manual/en/function.hash-pbkdf2.php ; https://www.rfc-editor.org/rfc/rfc5869 ; https://www.rfc-editor.org/rfc/rfc8018 ; https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html .
