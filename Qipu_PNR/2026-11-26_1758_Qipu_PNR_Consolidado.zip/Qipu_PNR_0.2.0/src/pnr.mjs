// Native Web Crypto only; PNR 0.2.0.
const enc = new TextEncoder();
const prefix = 'QIPU/PNR/0.2.0/';
const text = x => enc.encode(x);
function cat(...xs) { const a = new Uint8Array(xs.reduce((n,x)=>n+x.length,0)); let i=0; for(const x of xs){a.set(x,i); i+=x.length;} return a; }
function frame(s) { const b = typeof s==='string'?text(s):s; if(!(b instanceof Uint8Array)||b.length<1||b.length>4096) throw new Error('Credential length outside 1..4096 bytes'); const h=new Uint8Array(4); new DataView(h.buffer).setUint32(0,b.length); return cat(h,b); }
const tag = s => text(prefix+s);
const sha = async x => new Uint8Array(await crypto.subtle.digest('SHA-256',x));
async function mac(k,m){ const key=await crypto.subtle.importKey('raw',k,{name:'HMAC',hash:'SHA-256'},false,['sign']); return new Uint8Array(await crypto.subtle.sign('HMAC',key,m)); }
async function root(a,b,s){const fa=frame(a),fb=frame(b);let key;try{key=await sha(cat(tag('KEY\0'),fb));return await mac(key,cat(tag('ROOT\0'),s,fa));}finally{fa.fill(0);fb.fill(0);key?.fill(0);}}
async function projection(r,s){return (await sha(cat(tag('FILTER\0'),s,r)))[0];}
async function verifier(r,s){const key=await crypto.subtle.importKey('raw',r,'HKDF',false,['deriveBits']);const m=new Uint8Array(await crypto.subtle.deriveBits({name:'HKDF',hash:'SHA-256',salt:s,info:tag('GENERATE')},key,2048));let d;try{const pk=await crypto.subtle.importKey('raw',m,'PBKDF2',false,['deriveBits']);d=new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:s,iterations:600000},pk,256));return await mac(r,cat(tag('VERIFY\0'),s,d));}finally{m.fill(0);d?.fill(0);}}
function equal(a,b){if(a.length!==b.length)return false;let x=0;for(let i=0;i<a.length;i++)x|=a[i]^b[i];return x===0;} // JS engine makes no constant-time guarantee.
export function createPNR(){return Object.freeze({
 async register(a,b){const s=crypto.getRandomValues(new Uint8Array(16)),r=await root(a,b,s);try{return cat(s,Uint8Array.of(await projection(r,s)),await verifier(r,s));}finally{r.fill(0);}},
 async verify(a,b,record){if(!(record instanceof Uint8Array)||record.length!==49)return false;const s=record.slice(0,16),r=await root(a,b,s);try{if(await projection(r,s)!==record[16])return false;return equal(record.slice(17),await verifier(r,s));}finally{r.fill(0);}}
});}
// Optional envelope: nonce 12 B || ciphertext 49 B || tag 16 B.
function aad(id){const b=typeof id==='string'?text(id):id;if(!(b instanceof Uint8Array))throw Error('Invalid identity');const h=new Uint8Array(4);new DataView(h.buffer).setUint32(0,b.length);return cat(tag('SEAL\0'),h,b);}
async function sealKey(k,usage){if(!(k instanceof Uint8Array)||k.length!==32)throw Error('Expected 32-byte key');return crypto.subtle.importKey('raw',k,'AES-GCM',false,[usage]);}
export async function seal(record,key,id){if(!(record instanceof Uint8Array)||record.length!==49)throw Error('Invalid PNR record');const iv=crypto.getRandomValues(new Uint8Array(12));const c=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad(id),tagLength:128},await sealKey(key,'encrypt'),record);return cat(iv,new Uint8Array(c));}
export async function open(envelope,key,id){if(!(envelope instanceof Uint8Array)||envelope.length!==77)return false;const k=await sealKey(key,'decrypt');try{return new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:envelope.slice(0,12),additionalData:aad(id),tagLength:128},k,envelope.slice(12)));}catch{return false;}}
