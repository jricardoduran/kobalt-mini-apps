<?php
declare(strict_types=1);

/** Qipu PNR 0.2.0 — experimental; no HTTP, PAO or session adapter. */
final class QipuPNR
{
    public const VERSION = 'PNR/0.2.0';
    public const RECORD_BYTES = 49;
    private const PREFIX = "QIPU/PNR/0.2.0/";

    public const ITERATIONS = 600000;
    // Best effort only; PHP strings and runtime may retain copies.
    private static function wipe(string &$s): void {
        if (function_exists('sodium_memzero')) { sodium_memzero($s); } else { $s = ''; }
    }

    private static function frame(string $s): string
    {
        if (strlen($s) < 1 || strlen($s) > 4096) {
            throw new InvalidArgumentException('Credential length outside 1..4096 bytes');
        }
        return pack('N', strlen($s)) . $s;
    }

    private static function root(string $a, string $b, string $salt): string
    {
        $a = self::frame($a);
        $b = self::frame($b);
        $key = hash('sha256', self::PREFIX . "KEY\0" . $b, true);
        try {
            return hash_hmac('sha256', self::PREFIX . "ROOT\0" . $salt . $a, $key, true);
        } finally {
            self::wipe($a); self::wipe($b); self::wipe($key);
        }
    }

    private static function projection(string $root, string $salt): string
    {
        return substr(hash('sha256', self::PREFIX . "FILTER\0" . $salt . $root, true), 0, 1);
    }

    private static function verifier(string $root, string $salt): string
    {
        $material = hash_hkdf('sha256', $root, 256, self::PREFIX . 'GENERATE', $salt);
        try {
            $derived = hash_pbkdf2('sha256', $material, $salt, self::ITERATIONS, 32, true);
            try {
                return hash_hmac('sha256', self::PREFIX . "VERIFY\0" . $salt . $derived, $root, true);
            } finally { self::wipe($derived); }
        } finally { self::wipe($material); }
    }

    /** Returns salt (16 B) || projection (1 B) || verifier (32 B). */
    public static function register(string $a, string $b): string
    {
        $salt = random_bytes(16);
        $root = self::root($a, $b, $salt);
        try {
            return $salt . self::projection($root, $salt) . self::verifier($root, $salt);
        } finally { self::wipe($root); }
    }

    /** Only boolean result; caller must implement rate limits, timing policy and sessions. */
    public static function verify(string $a, string $b, string $record): bool
    {
        if (strlen($record) !== self::RECORD_BYTES) { return false; }
        $salt = substr($record, 0, 16);
        $root = self::root($a, $b, $salt);
        try {
            if (!hash_equals(substr($record, 16, 1), self::projection($root, $salt))) { return false; }
            return hash_equals(substr($record, 17, 32), self::verifier($root, $salt));
        } finally { self::wipe($root); }
    }
}
