<?php
declare(strict_types=1);
/** Optional AES-256-GCM envelope, requires OpenSSL. Key external to PNR. */
final class PNRSeal {
    public const BYTES = 77;
    private const DOMAIN = "QIPU/PNR/0.2.0/SEAL\0";
    private static function aad(string $id): string { return self::DOMAIN . pack('N',strlen($id)) . $id; }
    private static function checkKey(string $key): void { if(strlen($key)!==32) throw new InvalidArgumentException('Expected 32-byte key'); }
    public static function seal(string $record,string $key,string $id): string {
        self::checkKey($key);
        if(strlen($record)!==49) throw new InvalidArgumentException('Invalid PNR record');
        $iv=random_bytes(12); $tag='';
        $c=openssl_encrypt($record,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag,self::aad($id),16);
        if($c===false || strlen($tag)!==16) throw new RuntimeException('Encryption failed');
        return $iv.$c.$tag;
    }
    public static function open(string $envelope,string $key,string $id): string|false {
        self::checkKey($key); if(strlen($envelope)!==77) return false;
        return openssl_decrypt(substr($envelope,12,49),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($envelope,0,12),substr($envelope,61,16),self::aad($id));
    }
}
