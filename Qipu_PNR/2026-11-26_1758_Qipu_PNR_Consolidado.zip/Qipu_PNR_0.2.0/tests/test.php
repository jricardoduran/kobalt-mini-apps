<?php
declare(strict_types=1);
require __DIR__.'/../src/QipuPNR.php';
require __DIR__.'/../src/PNRSeal.php';
function check(string $name,bool $ok):void{echo ($ok?'PASS':'FAIL')." $name\n"; if(!$ok)exit(1);}
$a='demo-A-no-usar';$b='demo-B-no-usar';$r=QipuPNR::register($a,$b);
check('49-byte record',strlen($r)===49);
check('valid pair',QipuPNR::verify($a,$b,$r));
check('invalid A',!QipuPNR::verify($a.'x',$b,$r));
check('invalid B',!QipuPNR::verify($a,$b.'x',$r));
check('truncated record',!QipuPNR::verify($a,$b,substr($r,0,-1)));
$t=$r;$t[17]=chr(ord($t[17])^1);check('tampered verifier',!QipuPNR::verify($a,$b,$t));
check('random salt',substr(QipuPNR::register($a,$b),0,16)!==substr($r,0,16));
$key=random_bytes(32);$e=PNRSeal::seal($r,$key,'demo-id');
check('77-byte envelope',strlen($e)===77);
check('open envelope',PNRSeal::open($e,$key,'demo-id')===$r);
check('wrong identity',PNRSeal::open($e,$key,'other')===false);
check('wrong key',PNRSeal::open($e,random_bytes(32),'demo-id')===false);
$e[50]=chr(ord($e[50])^1);check('tampered envelope',PNRSeal::open($e,$key,'demo-id')===false);
$root=new ReflectionMethod(QipuPNR::class,'root');$proj=new ReflectionMethod(QipuPNR::class,'projection');
$salt=substr($r,0,16);$matches=0;$candidate=null;$N=65536;$start=hrtime(true);
for($i=0;$i<$N;$i++){ $guess='incorrect-'.$i; $x=$root->invoke(null,$guess,$b,$salt);if($proj->invoke(null,$x,$salt)===$r[16]){$matches++;$candidate??=$guess;} unset($x); }
$elapsed=(hrtime(true)-$start)/1e6;
check('false candidate passes filter but fails final', $candidate!==null && !QipuPNR::verify($candidate,$b,$r));
printf("N=%d matches=%d rejected=%d expected_matches=256 filter_scan_ms=%.3f\n",$N,$matches,$N-$matches,$elapsed);
$wrong='invalid-fast';while($proj->invoke(null,$root->invoke(null,$wrong,$b,$salt),$salt)===$r[16])$wrong.='x';
$start=hrtime(true);for($i=0;$i<10000;$i++)QipuPNR::verify($wrong,$b,$r);$fast=(hrtime(true)-$start)/1e10;
$times=[];for($i=0;$i<5;$i++){ $start=hrtime(true);QipuPNR::verify($a,$b,$r);$times[]=(hrtime(true)-$start)/1e6;}sort($times);$deep=$times[2];
printf("fast_mean_ms=%.6f full_median_ms=%.3f modeled_invalid_mean_ms=%.6f\n",$fast,$deep,$fast+($deep-$fast)/256);
