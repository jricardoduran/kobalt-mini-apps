import {execFileSync} from 'node:child_process';
import {createPNR,seal,open} from '../src/pnr.mjs';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const p=fileURLToPath(new URL('../src/',import.meta.url));const pnr=createPNR();
const a='Prueba ñ 🔑',b='secreto\0binario',id='id ñ';const key=crypto.getRandomValues(new Uint8Array(32));
const hex=x=>Buffer.from(x).toString('hex'), bytes=x=>new Uint8Array(Buffer.from(x,'hex'));
function php(code,...args){return execFileSync('php',['-r',`require $argv[1].'QipuPNR.php';require $argv[1].'PNRSeal.php';${code}`,p,...args],{encoding:'utf8'});}
function ok(n,v){assert.ok(v,n);console.log('PASS '+n);}
const r=bytes(php('echo bin2hex(QipuPNR::register(hex2bin($argv[2]),hex2bin($argv[3])));',hex(a),hex(b)));
ok('PHP -> JS',await pnr.verify(a,b,r));
const r2=await pnr.register(a,b);
ok('JS -> PHP',php('echo QipuPNR::verify(hex2bin($argv[2]),hex2bin($argv[3]),hex2bin($argv[4]))?"yes":"no";',hex(a),hex(b),hex(r2))==='yes');
ok('JS invalid credentials',!await pnr.verify(a+'x',b,r));
const e=bytes(php('echo bin2hex(PNRSeal::seal(hex2bin($argv[2]),hex2bin($argv[3]),hex2bin($argv[4])));',hex(r),hex(key),hex(id)));
ok('PHP seal -> JS open',hex(await open(e,key,id))===hex(r));
const e2=await seal(r2,key,id);
ok('JS seal -> PHP open',php('echo bin2hex(PNRSeal::open(hex2bin($argv[2]),hex2bin($argv[3]),hex2bin($argv[4])));',hex(e2),hex(key),hex(id))===hex(r2));
ok('JS rejects wrong AAD',await open(e,key,'other')===false);
e[30]^=1;ok('JS rejects modified ciphertext',await open(e,key,id)===false);
const start=performance.now();await pnr.verify(a,b,r);console.log('JS full_ms='+ (performance.now()-start).toFixed(3));
