import os, pathlib, tempfile, subprocess, urllib.request, urllib.parse, urllib.error, http.cookiejar, re, time, socket, hashlib, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as t:
    data=pathlib.Path(t)/'data'; env=dict(os.environ,PNR_DATA_DIR=str(data));
    with socket.socket() as s: s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
    server=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(ROOT/'public')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    url=f'http://127.0.0.1:{port}/'; a='test-A-unique'; b='test-B-unique-'+os.urandom(32).hex(); jar=http.cookiejar.CookieJar(); client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)); n=0
    def call(fields=None,path=''):
        try: r=client.open(url+path, None if fields is None else urllib.parse.urlencode(fields).encode(),timeout=10)
        except urllib.error.HTTPError as ex: r=ex
        return r.code,r.read().decode()
    def test(name,ok):
        global n
        assert ok,name; n+=1;print(f'OK {n:02d} {name}')
    def csrf(html):return re.search(r'name="csrf" value="([0-9a-f]+)"',html).group(1)
    try:
        for _ in range(30):
            try: code,h=call();break
            except OSError: time.sleep(.1)
        test('No se inicializa automáticamente sin CLI',code==503)
        proc=subprocess.run(['php',str(ROOT/'init.php')],env=env,capture_output=True,text=True,check=True); token=re.search(r'[0-9a-f]{64}',proc.stdout).group(0)
        code,h=call(); test('UI de registro inicial',code==200 and 'Constituir el acceso' in h)
        c=csrf(h); code,h=call(dict(action='register',csrf=c,a=a,b=b,setup='0'*64,ack='yes'));test('Código de instalación incorrecto rechazado',code==400 and 'incorrecto' in h)
        code,h=call(dict(action='register',csrf=c,a=a,b=b,setup=token,ack='yes'));test('Registro correcto inicia sesión',code==200 and 'Acceso autorizado' in h)
        state=json.loads((data/'state.json').read_bytes()); record=data/('record-'+state['sha256']+'.json'); original=record.read_bytes(); test('Nombre y ancla coinciden con SHA256',hashlib.sha256(original).hexdigest()==state['sha256'])
        v=json.loads(original);test('Registro exacto de 49 B y sin secretos',sum(len(v[k])//2 for k in ('salt','negative','verifier'))==49 and a.encode() not in original and b.encode() not in original and 'token_sha256' not in state)
        c=csrf(h);code,h=call(dict(action='probe',csrf=c));test('Operación privada sin credenciales',code==200 and 'No se volvieron' in h)
        code,h=call(dict(action='register',csrf=c,a='nuevo',b='nuevo',setup=token,ack='yes'));test('Segundo registro rechazado',code==400 and 'cerrado' in h and record.read_bytes()==original)
        code,h=call(dict(action='probe',csrf='0'*64));test('CSRF incorrecto rechazado',code==400)
        code,h=call(dict(action='logout',csrf=csrf(h)));test('Salir muestra ingreso y no inscripción',code==200 and 'Reconocer e ingresar' in h and 'Código de instalación' not in h)
        c=csrf(h);code,h=call(dict(action='probe',csrf=c));test('Operación privada sin sesión rechazada',code==400)
        code,h=call(dict(action='login',csrf=c,a=a,b='wrong'));test('Secreto incorrecto rechazado',code==400 and 'no reconocidas' in h)
        code,h=call(dict(action='login',csrf=c,a=a,b=b));test('Ingreso correcto y registro intacto',code==200 and 'Acceso autorizado' in h and record.read_bytes()==original)
        test('CLI no reinicializa almacenamiento',subprocess.run(['php',str(ROOT/'init.php')],env=env,capture_output=True).returncode!=0)
        test('Almacenamiento no accesible por HTTP',call(path='private-data/state.json')[0]==404)
        record.chmod(0o600);record.write_bytes(original+b' ');code,h=call();test('Alteración bloquea incluso sesión activa',code==503 and 'Autoridad bloqueada' in h)
        record.write_bytes(original);record.unlink();code,h=call();test('Eliminación no habilita inscripción',code==503 and 'Constituir el acceso' not in h)
        (data/'state.json').unlink();code,h=call();test('Ausencia de ancla también falla cerrado',code==503)
    finally:server.terminate();server.wait(timeout=5)
