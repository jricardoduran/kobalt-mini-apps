<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/Store.php';
if (!empty($_SERVER['PATH_INFO'])) { http_response_code(404); exit('Ruta no disponible.'); }
ini_set('display_errors','0'); ini_set('session.use_strict_mode','1'); ini_set('session.use_only_cookies','1'); ini_set('session.use_trans_sid','0');
$https=isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off' && $_SERVER['HTTPS']!=='';
$local=in_array($_SERVER['REMOTE_ADDR']??'', ['127.0.0.1','::1'],true);
header('Cache-Control: no-store'); header('Referrer-Policy: no-referrer'); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: default-src 'none'; style-src 'self'; script-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
if(!$https&&!$local){http_response_code(403);exit('HTTPS requerido.');}
session_name('QIPUPNR'); session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Strict']); session_start();
$_SESSION['csrf']??=bin2hex(random_bytes(32));
function e(string $s): string {return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function input(string $name,int $max=4096): string { $v=$_POST[$name]??null; if(!is_string($v)||strlen($v)<1||strlen($v)>$max) throw new DomainException('Entradas inválidas.');return $v; }
function auth(array $s): bool {return $s['state']==='registered' && isset($_SESSION['id'],$_SESSION['last'],$_SESSION['start']) && hash_equals($s['sha256'],$_SESSION['id']) && time()-$_SESSION['last']<=1800 && time()-$_SESSION['start']<=28800;}
function startAuth(string $id): void {session_regenerate_id(true); $_SESSION=['id'=>$id,'last'=>time(),'start'=>time(),'csrf'=>bin2hex(random_bytes(32))];}
function redirect(): never {header('Location: ./',true,303);exit;}
$error=''; $notice=''; $s=['state'=>'blocked']; $active=false;
try {
    $s=Store::locked(fn()=>Store::state()); $active=auth($s); if(!$active){unset($_SESSION['id'],$_SESSION['last'],$_SESSION['start']);}
    if($_SERVER['REQUEST_METHOD']==='POST') {
        try {
            if(!hash_equals($_SESSION['csrf'],input('csrf',64))) throw new DomainException('Solicitud inválida. Recarga la página.');
            $action=input('action',20);
            if($action==='logout') {$_SESSION=[];session_regenerate_id(true);redirect();}
            if($action==='register') {
                if($s['state']!=='pending') throw new DomainException('El registro ya está cerrado.');
                $a=input('a');$b=input('b');$token=input('setup',64);
                // Requiere confirmar que se ha conservado un secreto aleatorio. No es una prueba de entropía.
                if(($_POST['ack']??null)!=='yes') throw new DomainException('Confirma que conservaste los secretos y que uno es aleatorio.');
                $id=Store::locked(fn()=>Store::register($token,$a,$b)); startAuth($id); $_SESSION['flash']='Registro constituido. Sesión iniciada.'; redirect();
            }
            if($action==='login') {
                $a=input('a');$b=input('b');
                $id=Store::locked(function()use($a,$b){$current=Store::state();return Store::login($current,$a,$b)?$current['sha256']:null;});
                if($id===null) throw new DomainException('Credenciales no reconocidas.'); startAuth($id);$_SESSION['flash']='Credenciales reconocidas.';redirect();
            }
            if($action==='probe') {
                if(!$active) throw new DomainException('Sesión no autorizada.'); $_SESSION['last']=time(); $_SESSION['flash']='Operación privada admitida por la sesión. No se volvieron a derivar los secretos.';redirect();
            }
            throw new DomainException('Operación no admitida.');
        } catch(DomainException|InvalidArgumentException $ex) {$error=$ex->getMessage(); http_response_code(400);}
        finally {unset($_POST['a'],$_POST['b'],$_POST['setup'],$a,$b,$token);}
    }
    if($active) $_SESSION['last']=time();
    $notice=$_SESSION['flash']??'';unset($_SESSION['flash']);
} catch(Throwable $ex) {$s=['state'=>'blocked'];$active=false;unset($_SESSION['id'],$_SESSION['last'],$_SESSION['start']);http_response_code(503);$error='Almacenamiento no disponible o inconsistente. No se permite crear otro registro. Revisión administrativa requerida.';}
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Qipu PNR · Autoridad</title><link rel="stylesheet" href="style.css"><script src="app.js" defer></script></head><body><main><header><div class="eyebrow">KOBALT / QIPU · PNR 0.2.0</div><h1>Autoridad de acceso</h1><p class="lead">Dos secretos. Una evidencia persistente. Una sesión temporal.</p><nav><a href="guia.html">Guía del mecanismo</a></nav></header>
<?php if($error!==''):?><p class="message error" role="alert"><?=e($error)?></p><?php endif;?>
<?php if($notice!==''):?><p class="message" role="status"><?=e($notice)?></p><?php endif;?>
<?php if($s['state']==='blocked'):?><section><h2>Autoridad bloqueada</h2><p>La ausencia o alteración del registro no habilita un nuevo registro. Consulta la guía para instalar o recuperar.</p></section>
<?php elseif($active):?><section><span class="status">Sesión reconocida</span><h2>Acceso autorizado</h2><p>La UI no necesita conservar ni volver a pedir las credenciales durante la sesión.</p><dl><dt>Identidad exacta del registro · SHA-256</dt><dd><code><?=e($s['sha256'])?></code></dd><dt>Estado de inscripción</dt><dd>Cerrado · sin edición ni eliminación por HTTP</dd><dt>Evidencia PNR</dt><dd>49 bytes binarios · JSON hexadecimal en disco</dd></dl><form method="post"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><button name="action" value="probe">Probar operación privada</button><button class="secondary" name="action" value="logout">Cerrar sesión</button></form></section>
<?php else: $pending=$s['state']==='pending';?><section><span class="status"><?=$pending?'Instalación pendiente':'Registro cerrado'?></span><h2><?=$pending?'Constituir el acceso':'Ingresar'?></h2><p><?=$pending?'La primera inscripción constituye un registro único. Guarda ambos secretos fuera de la aplicación.':'Introduce los dos secretos originales para iniciar una nueva sesión.'?></p><form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><input type="hidden" name="action" value="<?=$pending?'register':'login'?>">
<?php if($pending):?><label for="setup">Código de instalación de un solo uso</label><input type="password" id="setup" name="setup" required maxlength="64" autocomplete="off"><small>Lo entrega el comando de instalación. No forma parte de PNR.</small><?php endif;?>
<label for="a">Secreto A</label><div class="field"><input id="a" name="a" type="password" required maxlength="4096" autocomplete="<?=$pending?'new-password':'current-password'?>" autocapitalize="none" spellcheck="false"><button class="secondary toggle" type="button" data-target="a" aria-pressed="false">Ver</button></div>
<label for="b">Secreto B</label><div class="field"><input id="b" name="b" type="password" required maxlength="4096" autocomplete="<?=$pending?'new-password':'current-password'?>" autocapitalize="none" spellcheck="false"><button class="secondary toggle" type="button" data-target="b" aria-pressed="false">Ver</button></div>
<?php if($pending):?><button type="button" id="generate" class="secondary">Generar B aleatorio · 256 bits</button><p class="small" id="generator-status" aria-live="polite">Recomendado: un secreto independiente de al menos 128 bits aleatorios.</p><label class="check"><input type="checkbox" name="ack" value="yes" required> He conservado los dos secretos y al menos uno se generó aleatoriamente con suficiente entropía.</label><?php endif;?><button type="submit"><?=$pending?'Constituir registro e ingresar':'Reconocer e ingresar'?></button></form></section><?php endif;?>
<footer>Prototipo independiente · Sin recuperación de credenciales · Sin almacenamiento de A o B por la aplicación.</footer></main></body></html>
