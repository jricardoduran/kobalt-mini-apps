# Qipu PNR — Autoridad de demostración 0.1.0
Núcleo PNR 0.2.0 original, sin cambios. PHP 8.1+ por diseño, Hash; OpenSSL solo para módulo de sobre opcional (no activado). Sin Composer ni bases de datos. Aplicación de una sola autoridad.

## Ejecutar
Desde la carpeta del ZIP:
```
php init.php
php -S 127.0.0.1:8080 -t public
```
Abrir http://127.0.0.1:8080/ e introducir código de instalación de un solo uso, A y B. Guardar ambos secretos fuera de la aplicación; generar B desde la UI (256 bits aleatorios). Registrar inicia sesión. Después solo se solicitan los secretos al iniciar una nueva sesión. No hay reset por HTTP.

El código de instalación no forma parte del contrato PNR; evita que el primer visitante se apropie de la autoridad. El CLI conserva temporalmente su hash hasta el registro. El directorio private-data se crea con permisos restrictivos y debe estar fuera de public. `PNR_DATA_DIR` permite seleccionar un directorio absoluto nuevo; usar el mismo entorno en CLI y servidor. No reusar un directorio existente ni usar uno dentro del document root. Para hosting, usar HTTPS, document root public, y una cuenta de servicio con permisos adecuados; no exponer la carpeta raíz del ZIP. No confiar en HTTP detrás de un proxy local; configurar HTTPS correctamente. El servidor PHP integrado es exclusivamente para desarrollo.

## Documentación
- public/guia.html: explicación de la aplicación, flujo, propiedades, simulador y prueba.
- public/criptografia.html: documentación criptográfica de PNR 0.2.0 y demo Web Crypto original.
- src/QipuPNR.php: núcleo original.
- src/PNRSeal.php: AES-GCM opcional, no integrado en esta UI.
- src/Store.php: persistencia JSON direccionada por contenido, referencia fija, bloqueo, límites.
- tests/http_test.py: integración real HTTP; requiere Python 3 estándar y PHP CLI.

## Invariantes y límites
Solo el CLI prepara el primer registro; el código se consume al consolidar. El estado registrado no vuelve a pendiente mediante la UI. Si el JSON referenciado falta o no coincide con SHA-256, falla cerrado. No protege contra un administrador que modifica simultáneamente estado y registro, ni contra restauración completa del almacenamiento; el hash no impide borrado. Es un prototipo no auditado, no protege secretos capturados durante ingreso, no implementa PAO ni recovery. Se usa al menos un secreto aleatorio independiente de >=128 bits. El filtro rápido es aprovechable offline y por temporización. La sesión usa almacenamiento PHP separado con metadatos y CSRF, no secretos A/B. La escritura exclusiva y rename se ejecutan bajo flock en filesystem local; no se promete durabilidad ante pérdida eléctrica de directorios ni seguridad en filesystem distribuido. La UI no guarda A/B, pero navegador, gestor de contraseñas, logs externos, memoria o infraestructura pueden hacerlo si se configuran de ese modo. No activar logging de cuerpo HTTP.
