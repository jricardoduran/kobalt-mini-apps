<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli') {http_response_code(404);exit;}
require __DIR__.'/src/Store.php';
try { $token=Store::init(); echo "Instalación preparada. Código de un solo uso:\n$token\nAbre la UI y registra A y B. No guardes el código en un archivo.\n"; } catch(Throwable $e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}
