<?php
declare(strict_types=1);
require_once __DIR__.'/QipuPNR.php';
final class Store {
    public static function dir(): string { $d=getenv('PNR_DATA_DIR'); return $d!==false && $d!=='' ? $d : dirname(__DIR__).'/private-data'; }
    public static function init(): string {
        $d=self::dir(); umask(0077);
        if (!@mkdir($d,0700)) throw new RuntimeException('El directorio ya existe o no se puede crear. No se reinicializa.');
        $token=bin2hex(random_bytes(32));
        self::writeNew($d.'/state.json',self::json(['state'=>'pending','token_sha256'=>hash('sha256',$token)]));
        self::writeNew($d.'/lock','');
        return $token;
    }
    private static function json(array $v): string { return json_encode($v,JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR); }
    private static function writeNew(string $p,string $bytes): void {
        $f=@fopen($p,'xb'); if(!$f) throw new RuntimeException('No se pudo constituir el archivo exclusivo.');
        try { if (fwrite($f,$bytes)!==strlen($bytes)||!fflush($f)||!fsync($f)) throw new RuntimeException('Escritura incompleta.'); } finally {fclose($f);}
        @chmod($p,0600);
    }
    private static function replace(string $p,string $bytes): void {
        $tmp=$p.'.tmp-'.bin2hex(random_bytes(8)); self::writeNew($tmp,$bytes);
        if(!rename($tmp,$p)) { @unlink($tmp); throw new RuntimeException('No se pudo consolidar el estado.'); }
    }
    public static function locked(callable $fn): mixed {
        $d=self::dir(); if(!is_dir($d)||!is_file($d.'/lock')) throw new RuntimeException('Almacenamiento no inicializado o incompleto.');
        $f=@fopen($d.'/lock','r+'); if(!$f) throw new RuntimeException('Bloqueo no disponible.');
        try {if(!flock($f,LOCK_EX)) throw new RuntimeException('Bloqueo no disponible.'); return $fn();} finally {flock($f,LOCK_UN);fclose($f);}
    }
    private static function read(string $path): string {
        if(!is_file($path)||is_link($path)||filesize($path)>8192) throw new RuntimeException('Archivo ausente o inválido.');
        $r=file_get_contents($path); if($r===false) throw new RuntimeException('Lectura imposible.');return $r;
    }
    public static function state(): array {
        $d=self::dir(); $s=json_decode(self::read($d.'/state.json'),true,512,JSON_THROW_ON_ERROR);
        if(!is_array($s)) throw new RuntimeException('Estado inválido.');
        if(($s['state']??null)==='pending' && is_string($s['token_sha256']??null) && preg_match('/\A[0-9a-f]{64}\z/',$s['token_sha256'])) {
            if(glob($d.'/record-*.json')!==[]) throw new RuntimeException('Registro huérfano: recuperación manual requerida.');
            return $s;
        }
        if(($s['state']??null)!=='registered'||!is_string($s['sha256']??null)||!preg_match('/\A[0-9a-f]{64}\z/',$s['sha256'])) throw new RuntimeException('Estado inválido.');
        $raw=self::read($d.'/record-'.$s['sha256'].'.json');
        if(!hash_equals($s['sha256'],hash('sha256',$raw))) throw new RuntimeException('Integridad incorrecta.');
        $v=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
        if(!is_array($v)||($v['version']??null)!==QipuPNR::VERSION) throw new RuntimeException('Versión incorrecta.');
        foreach(['salt'=>32,'negative'=>2,'verifier'=>64] as $k=>$n) if(!is_string($v[$k]??null)||strlen($v[$k])!==$n||!ctype_xdigit($v[$k])) throw new RuntimeException('Registro inválido.');
        $s['record']=hex2bin($v['salt'].$v['negative'].$v['verifier']); return $s;
    }
    public static function register(string $token,string $a,string $b): string {
        $s=self::state(); if($s['state']!=='pending') throw new RuntimeException('Registro cerrado.');
        if(!hash_equals($s['token_sha256'],hash('sha256',$token))) throw new DomainException('Código de instalación incorrecto.');
        $r=QipuPNR::register($a,$b);
        $json=self::json(['version'=>QipuPNR::VERSION,'salt'=>bin2hex(substr($r,0,16)),'negative'=>bin2hex(substr($r,16,1)),'verifier'=>bin2hex(substr($r,17))]);
        $id=hash('sha256',$json); $d=self::dir(); $p=$d.'/record-'.$id.'.json'; self::writeNew($p,$json); @chmod($p,0400);
        self::replace($d.'/state.json',self::json(['state'=>'registered','sha256'=>$id])); return $id;
    }
    public static function login(array $s,string $a,string $b): bool {
        if($s['state']!=='registered') return false;
        $p=self::dir().'/rate.json'; $now=time(); $times=[];
        if(file_exists($p)) { $v=json_decode(self::read($p),true,512,JSON_THROW_ON_ERROR); if(!is_array($v)) throw new RuntimeException('Control de intentos inválido.'); $times=array_values(array_filter($v,fn($t)=>is_int($t)&&$t>$now-60)); }
        if(count($times)>=5) throw new DomainException('Demasiados intentos. Espera un minuto.');
        $times[]=$now; self::replace($p,self::json($times));
        $ok=QipuPNR::verify($a,$b,$s['record']); if($ok) self::replace($p,'[]'); return $ok;
    }
}
