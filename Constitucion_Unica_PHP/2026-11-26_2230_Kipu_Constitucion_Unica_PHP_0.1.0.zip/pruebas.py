#!/usr/bin/env python3
"""Pruebas locales sin dependencias Python externas; requiere PHP >= 8.1."""
import concurrent.futures, json, pathlib, shutil, subprocess, tempfile
SRC = pathlib.Path(__file__).resolve().parent
N = 0
def ok(c, msg):
    global N
    if not c: raise AssertionError(msg)
    N += 1; print(f'OK {N:02d} {msg}')
def setup(root, name):
    p = root / name; p.mkdir();
    for f in ('constitucion_unica.php', 'ejemplo.php'): shutil.copyfile(SRC/f,p/f)
    return p
def run(p, mode='bloquear', file='ejemplo.php'):
    return subprocess.run(['php',str(p/file),mode],capture_output=True,text=True,timeout=15)
def result(r):
    assert r.returncode == 0, r.stderr
    return json.loads(r.stdout)
with tempfile.TemporaryDirectory() as d:
    root = pathlib.Path(d)
    p=setup(root,'block'); r=result(run(p)); ok(r['ejecutada'] and r['estado']=='constituida','Bloqueo: primera ejecución')
    ok((p/'ejemplo.php').exists(),'El ejecutable permanece')
    before=(p/'material.txt').read_bytes(); ok(not result(run(p))['ejecutada'],'Segunda ejecución bloqueada')
    ok((p/'material.txt').read_bytes()==before,'Material intacto')
    ok((p/'constitucion.estado').read_bytes()==b'INICIADA\nCONSTITUIDA\n','Estado confirmado persistente')
    for mode,expected in [('eliminar','eliminada'),('vaciar','vaciada')]:
        p=setup(root,mode); r=result(run(p,mode)); ok(r['retirada']==expected,mode+': retirada confirmada')
        ok(not (p/'ejemplo.php').exists() if mode=='eliminar' else (p/'ejemplo.php').stat().st_size==0,mode+': materialidad del ejecutable')
        ok((p/'material.txt').read_bytes()==before,mode+': conserva material')
        shutil.copyfile(SRC/'ejemplo.php',p/'ejemplo.php'); ok(not result(run(p,mode))['ejecutada'],mode+': reinstalar el script no reconstituye')
    p=setup(root,'race');
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as ex: rs=list(ex.map(lambda _:result(run(p)),range(12)))
    ok(sum(r['ejecutada'] for r in rs)==1,'12 procesos concurrentes: uno solo ejecuta')
    ok(all(r['estado']=='constituida' for r in rs),'Los demás reconocen estado confirmado')
    p=setup(root,'failed'); (p/'material.txt').write_text('preexistente'); ok(run(p).returncode!=0,'Error de acción se propaga')
    ok((p/'constitucion.estado').read_bytes()==b'INICIADA\n','Fallo conserva marca de intención')
    ok(result(run(p))['estado']=='incierta','Fallo bloquea reintento automático')
    p=setup(root,'crash'); (p/'crash.php').write_text('''<?php require __DIR__.'/constitucion_unica.php'; constitucionUnica(__DIR__.'/constitucion.estado', function(){file_put_contents(__DIR__.'/material.txt','parcial'); exit(19);});''')
    ok(run(p,file='crash.php').returncode==19,'Interrupción dentro de la acción')
    ok(result(run(p))['estado']=='incierta','Tras interrupción no repite acción')
    ok((p/'material.txt').read_text()=='parcial','Material parcial no se sobrescribe')
    p=setup(root,'corrupt'); (p/'constitucion.estado').write_bytes(b'INIC'); ok(result(run(p))['estado']=='incierta','Marca parcial bloquea')
    p=setup(root,'cleanup'); (p/'fail.php').write_text('''<?php require __DIR__.'/constitucion_unica.php'; echo json_encode(constitucionUnica(__DIR__.'/constitucion.estado',function(){rename(__FILE__,__FILE__.'.old');file_put_contents(__DIR__.'/material.txt','ok');},'eliminar',__FILE__));''')
    r=result(run(p,file='fail.php')); ok(r['estado']=='constituida' and r['retirada']=='fallida','Fallo al retirar no revierte constitución')
    ok(not result(run(p))['ejecutada'],'Fallo de retirada no permite repetir')
    p=setup(root,'invalid'); ok(run(p,'otro').returncode!=0 and not (p/'constitucion.estado').exists(),'Modo inválido no inicia')
    (p/'bad.php').write_text('''<?php require __DIR__.'/constitucion_unica.php'; constitucionUnica(__DIR__.'/constitucion.estado',fn()=>null,'eliminar',__DIR__.'/ejemplo.php');''')
    ok(run(p,file='bad.php').returncode!=0 and (p/'ejemplo.php').exists(),'No permite eliminar otro script')
    ok(not (p/'constitucion.estado').exists(),'Destino inválido no inicia')
print(f'{N}/{N} comprobaciones superadas')
