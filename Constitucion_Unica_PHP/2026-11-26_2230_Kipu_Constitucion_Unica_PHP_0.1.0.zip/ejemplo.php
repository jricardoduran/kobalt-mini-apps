<?php
declare(strict_types=1);
// Demostración deliberadamente CLI: no constituye nada por una visita HTTP.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require __DIR__ . '/constitucion_unica.php';
$modo = $argv[1] ?? 'bloquear';
try {
    $r = constitucionUnica(__DIR__ . '/constitucion.estado', static function (): void {
        $contenido = "Universo inicial\n";
        $h = fopen(__DIR__ . '/material.txt', 'xb');
        if ($h === false) throw new RuntimeException('Material preexistente');
        try {
            if (fwrite($h, $contenido) !== strlen($contenido) || !fflush($h) || !fsync($h)) {
                throw new RuntimeException('Escritura incompleta');
            }
        } finally { fclose($h); }
        if (file_get_contents(__DIR__ . '/material.txt') !== $contenido) throw new RuntimeException('Verificación fallida');
    }, $modo, __FILE__);
    echo json_encode($r, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $e) { fwrite(STDERR, $e->getMessage() . PHP_EOL); exit(1); }
