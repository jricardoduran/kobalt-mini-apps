<?php
declare(strict_types=1);

/**
 * Constitución Única 0.1.0 — PHP >= 8.1, filesystem local confiable.
 * Una acción comienza como máximo una vez por archivo de estado conservado.
 * Un retorno normal de $accion significa éxito verificado por el llamador.
 * El estado nunca se elimina; la retirada del ejecutable es opcional.
 */
function constitucionUnica(string $estado, callable $accion, string $modo = 'bloquear', ?string $entrada = null): array
{
    if (!in_array($modo, ['bloquear', 'eliminar', 'vaciar'], true)) {
        throw new InvalidArgumentException('Modo desconocido');
    }
    // El único candidato a retirada es el script de entrada real, no un archivo arbitrario.
    $dir = realpath(dirname($estado));
    if ($dir === false || !is_dir($dir) || in_array(basename($estado), ['.', '..', ''], true)) {
        throw new InvalidArgumentException('Directorio de estado inexistente');
    }
    $estado = $dir . DIRECTORY_SEPARATOR . basename($estado);
    if (is_link($estado) || (file_exists($estado) && !is_file($estado))) {
        throw new InvalidArgumentException('Estado no regular');
    }
    if ($modo !== 'bloquear') {
        $principal = realpath($_SERVER['SCRIPT_FILENAME'] ?? '');
        $real = $entrada === null ? false : realpath($entrada);
        if ($real === false || $real !== $principal || $real === __FILE__ || $real === $estado ||
            !is_file($real) || is_link($entrada) || (file_exists($estado) && fileinode($estado) === fileinode($real) && stat($estado)['dev'] === stat($real)['dev'])) {
            throw new InvalidArgumentException('Solo se puede retirar el propio script de entrada');
        }
        $entrada = $real;
        $original = stat($entrada);
    }
    $h = @fopen($estado, 'c+b');
    if ($h === false) throw new RuntimeException('No se pudo abrir el estado');
    try {
        if (!flock($h, LOCK_EX)) throw new RuntimeException('No se pudo bloquear');
        rewind($h);
        $previo = stream_get_contents($h, 128);
        if ($previo === false) throw new RuntimeException('No se pudo leer el estado');
        if ($previo !== '') {
            return ['estado' => $previo === "INICIADA\nCONSTITUIDA\n" ? 'constituida' : 'incierta', 'ejecutada' => false, 'retirada' => 'no_aplica'];
        }
        // Persistir la intención antes de invocar cualquier efecto externo.
        $persistir = static function (string $texto) use ($h): void {
            if (fwrite($h, $texto) !== strlen($texto) || !fflush($h) || !fsync($h)) {
                throw new RuntimeException('Estado no confirmado; no reintentar automáticamente');
            }
        };
        $persistir("INICIADA\n");
        $accion(); // Si lanza una excepción, la marca impide una repetición ambigua.
        $persistir("CONSTITUIDA\n");
        $retirada = 'no_aplica';
        if ($modo !== 'bloquear') {
            clearstatcache(true, $entrada);
            $actual = @stat($entrada);
            if ($actual === false || is_link($entrada) || $actual['ino'] !== $original['ino'] || $actual['dev'] !== $original['dev']) {
                return ['estado' => 'constituida', 'ejecutada' => true, 'retirada' => 'fallida'];
            }
        }
        if ($modo === 'eliminar') {
            $retirada = @unlink($entrada) ? 'eliminada' : 'fallida';
        } elseif ($modo === 'vaciar') {
            // Sustitución atómica por un archivo vacío en el mismo filesystem.
            $tmp = @tempnam(dirname($entrada), '.cu-');
            $retirada = 'fallida';
            if ($tmp !== false) {
                if (dirname($tmp) === dirname($entrada) && @chmod($tmp, fileperms($entrada) & 0777) && @rename($tmp, $entrada)) {
                    $retirada = 'vaciada';
                } else {
                    @unlink($tmp);
                }
            }
        }
        if (in_array($retirada, ['eliminada', 'vaciada'], true) && function_exists('opcache_invalidate')) {
            @opcache_invalidate($entrada, true);
        }
        return ['estado' => 'constituida', 'ejecutada' => true, 'retirada' => $retirada];
    } finally {
        fclose($h); // El cierre libera el lock; la marca persistente permanece.
    }
}
