<?php
declare(strict_types=1);
require_once __DIR__.'/../src/Storage.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function fail(int $s,string $code): never { http_response_code($s); echo json_encode(['ok'=>false,'code'=>$code]); exit; }
function name32(mixed $v): bool { return is_string($v)&&preg_match('/\A[0-9a-f]{64}\z/D',$v)===1; }
function num(mixed $v): bool { return is_int($v)&&$v>=0&&$v<=9007199254740991; }
function outside(string $p): string { $r=realpath($p); $web=realpath(__DIR__); if($r===false||$r===$web||str_starts_with($r,$web.DIRECTORY_SEPARATOR)) throw new RuntimeException('private paths required'); return $r; }
try {
 if($_SERVER['REQUEST_METHOD']!=='POST') fail(405,'METHOD');
 $raw=file_get_contents('php://input',false,null,0,1500000); if($raw===false||strlen($raw)>=1500000) fail(413,'LIMIT');
 try {$q=json_decode($raw,true,16,JSON_THROW_ON_ERROR);} catch(JsonException){fail(400,'INVALID');}
 if(!is_array($q)||!is_string($q['op']??null)) fail(400,'INVALID');
 $cfg=json_decode(file_get_contents(outside((string)getenv('PCTL_REGISTRY'))),true,16,JSON_THROW_ON_ERROR);
 if(!is_array($cfg)||!is_array($cfg['nodes']??null)||!is_bool($cfg['public_read']??null)) throw new RuntimeException('registry');
 foreach($cfg['nodes'] as $n=>$u) if(!name32($n)||!name32($u)) throw new RuntimeException('registry entry');
 $op=$q['op']; if(!in_array($op,['nodes','head','read','append'],true)) fail(400,'INVALID');
 $n=$q['target']??null; if($op!=='nodes'&&(!name32($n)||!isset($cfg['nodes'][$n]))) fail(404,'UNKNOWN_NODE');
 if($op==='append'||!$cfg['public_read']){
  $u=$q['u']??null;$a=$q['actor']??null;$h=$_SERVER['HTTP_AUTHORIZATION']??'';
  if(!name32($u)||!name32($a)||!preg_match('/\ABearer ([0-9a-f]{64})\z/D',$h,$m)) fail(401,'IDENTITY_INVALID');
  require_once outside((string)getenv('PCTL_UNT_LIB'));
  $unt=new KipuRecognition(outside((string)getenv('PCTL_UNT_DIR')));
  if($unt->resolve($u,$a,$m[1])===null) fail(401,'IDENTITY_INVALID');
  if(($cfg['nodes'][$a]??null)!==$u||($op==='append'&&$a!==$n)) fail(403,'FORBIDDEN');
 }
 $store=new Storage(outside((string)getenv('PCTL_DATA')));
 if($op==='nodes') $r=['nodes'=>array_keys($cfg['nodes'])];
 elseif($op==='head') $r=$store->head($n);
 elseif($op==='read'){
  if(!num($q['offset']??null)||!num($q['length']??null)||$q['length']>1048576) fail(400,'INVALID');
  $r=$store->read($n,$q['offset'],$q['length']);$r['base64']=base64_encode($r['bytes']);unset($r['bytes']);
 }else{
  if(!num($q['offset']??null)||!is_string($q['base64']??null)) fail(400,'INVALID');
  $b=base64_decode($q['base64'],true);if($b===false||$b===''||strlen($b)>1048576||base64_encode($b)!==$q['base64']) fail(400,'INVALID');
  $r=$store->append($n,$q['offset'],$b);
 }
 echo json_encode(['ok'=>true]+$r,JSON_THROW_ON_ERROR);
}catch(StorageError $e){fail($e->status,match($e->status){409=>'CONFLICT',404=>'UNKNOWN_STREAM',416=>'RANGE',400=>'INVALID',default=>'STORAGE_UNCERTAIN'});}catch(Throwable $e){error_log('PCTL operational failure: '.get_class($e));fail(503,'UNKNOWN');}
