// PCTL/1: byte-prefix synchronization; no domain decisions, no queue.
const chunk=65536;
const same=(a,b)=>a.length===b.length&&a.every((v,i)=>v===b[i]);
const join=(parts,n)=>{const b=new Uint8Array(n);let i=0;for(const p of parts){b.set(p,i);i+=p.length;}return b;};
export class Conflict extends Error{constructor(message){super(message);this.name='Conflict';}}
const checkEnd=n=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid cut');return n;};
async function readExact(t,n,offset,length){const r=await t.read(n,offset,length);if(!(r.bytes instanceof Uint8Array)||r.bytes.length!==length||checkEnd(r.end)<offset+length)throw new Error('Incomplete cut');return r.bytes;}
// Snapshot local bytes before calling. Never download remote bytes into writer automatically.
export async function publish(local,n,t){
 if(!(local instanceof Uint8Array))throw new TypeError('bytes');local=local.slice();
 const end=checkEnd((await t.head(n)).end);
 if(end>local.length)throw new Conflict('Remote ahead of local');
 // Full prefix comparison: intentionally simple; later optimize with verified checkpoint.
 for(let i=0;i<end;i+=chunk){const k=Math.min(chunk,end-i);if(!same(local.subarray(i,i+k),await readExact(t,n,i,k)))throw new Conflict('Divergent prefix');}
 for(let i=end;i<local.length;i+=chunk){const b=local.subarray(i,Math.min(i+chunk,local.length));const r=await t.append(n,i,b);if(r.offset!==i||r.length!==b.length||checkEnd(r.end)<i+b.length)throw new Error('Uncertain receipt');}
 // No second writer with different bytes is expected, but detect an advance beyond snapshot.
 const final=checkEnd((await t.head(n)).end);if(final!==local.length)throw new Conflict('Remote cut changed during publication');
 // Receipt from PAO confirms exact bytes at each offset; previous verified prefix immutable under PAO assumptions.
 return {end:final};
}
// Keep previously acquired prefix; a failed read never replaces it. Returns immutable-by-convention copy.
export async function acquire(n,t,previous=new Uint8Array()){
 previous=previous.slice();const end=checkEnd((await t.head(n)).end);if(end<previous.length)throw new Conflict('Remote truncated');
 for(let i=0;i<previous.length;i+=chunk){const k=Math.min(chunk,previous.length-i);if(!same(previous.subarray(i,i+k),await readExact(t,n,i,k)))throw new Conflict('Remote diverged');}
 const parts=[previous];for(let i=previous.length;i<end;i+=chunk)parts.push(await readExact(t,n,i,Math.min(chunk,end-i)));
 return join(parts,end);
}
// A coproduct is tagged, not concatenated or sorted. Partial acquisition must be explicit.
export async function observe(t,cache=new Map()){
 const ns=await t.nodes();if(!Array.isArray(ns)||new Set(ns).size!==ns.length||ns.some(n=>typeof n!=='string'||!/^[0-9a-f]{64}$/.test(n)))throw new Error('Invalid directory');
 const fibers=new Map(),errors=new Map();for(const n of ns){try{fibers.set(n,{bytes:await acquire(n,t,cache.get(n)),fresh:true});}catch(e){errors.set(n,String(e));if(cache.has(n))fibers.set(n,{bytes:cache.get(n).slice(),fresh:false});}}
 return {fibers,errors,complete:errors.size===0,cuts:new Map([...fibers].map(([n,v])=>[n,v.bytes.length]))};
}
const b64=b=>{let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode(...b.subarray(i,i+8192));return btoa(s);};
const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
export function httpTransport(url,identity=async()=>null){
 const u=new URL(url,globalThis.location?.href);if(u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)))throw new Error('HTTPS required');
 async function call(q){const a=await identity();const headers={'Content-Type':'application/json'};if(a){q={...q,u:a.u,actor:a.n};headers.Authorization='Bearer '+a.t;}
 const r=await fetch(u,{method:'POST',headers,body:JSON.stringify(q),credentials:'omit',redirect:'error',signal:AbortSignal.timeout(15000)});const j=await r.json();if(!r.ok||j.ok!==true){const e=new Error(j.code||'UNKNOWN');e.status=r.status;throw e;}return j;}
 return {nodes:async()=> (await call({op:'nodes'})).nodes,head:n=>call({op:'head',target:n}),read:async(n,offset,length)=>{const r=await call({op:'read',target:n,offset,length});return {end:r.end,bytes:unb64(r.base64)};},append:(n,offset,b)=>call({op:'append',target:n,offset,base64:b64(b)})};
}
