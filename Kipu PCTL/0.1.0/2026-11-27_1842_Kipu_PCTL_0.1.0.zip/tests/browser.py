"""Optional real Chromium test of the standalone conceptual HTML (not HTTP integration)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import os
p=Path(__file__).resolve().parents[1]/'public'/'index.html'
with sync_playwright() as w:
    browser=w.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1280,'height':900})
    page.set_content(p.read_text(),wait_until='load')
    assert page.title().startswith('Kipu')
    for i in range(3): page.get_by_role('button',name='Constituir',exact=True).nth(i).click()
    assert page.locator('#visible').inner_text()=='0'
    for i in range(3): page.get_by_role('button',name='Publicar',exact=True).nth(i).click()
    page.get_by_role('button',name='Adquirir las tres réplicas').click()
    assert page.locator('#visible').inner_text()=='3'
    page.get_by_role('button',name='Aprobar',exact=True).nth(1).click()
    assert page.locator('#stock').inner_text()=='0'
    page.get_by_role('button',name='Aprobar',exact=True).nth(0).click()
    assert page.locator('#pending').inner_text()=='2'
    page.get_by_role('button',name='Rechazar',exact=True).nth(0).click()
    assert page.locator('#pending').inner_text()=='1'
    page.set_viewport_size({'width':390,'height':844})
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    browser.close()
    print('PASS HTML: interacción real (set_content), tres solicitudes, una aprobación, conflicto, rechazo, viewport móvil sin overflow global.')
