<?php
// CLI only. First provisioning; never overwrites an existing registry or stream.
if(PHP_SAPI!=='cli'||$argc!==4){fwrite(STDERR,"usage: php provision.php DATA REGISTRY_JSON INPUT_JSON\n");exit(1);}
require __DIR__.'/Storage.php';
[$script,$dir,$path,$input]=$argv;
$c=json_decode(file_get_contents($input),true,16,JSON_THROW_ON_ERROR);
if(!is_bool($c['public_read']??null)||!is_array($c['nodes']??null)||!$c['nodes']||file_exists($path))throw new RuntimeException('Invalid registry or already provisioned');
foreach($c['nodes'] as $n=>$u)if(!preg_match('/\A[0-9a-f]{64}\z/D',$n)||!is_string($u)||!preg_match('/\A[0-9a-f]{64}\z/D',$u))throw new RuntimeException('Invalid coordinates');
$s=new Storage($dir);foreach($c['nodes'] as $n=>$u)$s->create($n);
// Operator publishes the registry after all streams exist. This is initial provisioning, not a dynamic registrar.
$f=fopen($path,'xb');if(!$f)throw new RuntimeException('Registry');$b=json_encode($c,JSON_THROW_ON_ERROR);if(fwrite($f,$b)!==strlen($b)||!fflush($f)||!fsync($f))throw new RuntimeException('Registry uncertain');fclose($f);chmod($path,0600);
