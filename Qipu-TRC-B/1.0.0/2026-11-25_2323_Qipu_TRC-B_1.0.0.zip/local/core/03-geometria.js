'use strict';
/* 03. GEOMETRÍA B. Identidades compartidas, manifestaciones independientes. */
Qipu.TRCInternal.geometry=(()=>{
 const U=Qipu.TRCInternal.domain,{need,eq,nat,ar,route,transform}=U;
 const key=(...x)=>JSON.stringify(x);
 function zero(){
  const s=new Map(),put=(x,...k)=>s.set(key(...k),x);
  put(1,'seq');put(0,'count',0);put({kind:'context',id:0,axis:0},'root');
  put(1,'axisCount');put(0,'axisIndex',0);put(0,'axisName','root');
  return s
 }
 function view(base){
  const delta=new Map(),seen=new Set();
  function get(...k){const p=key(...k);if(delta.has(p))return delta.get(p);seen.add(p);return base.get(p)}
  function put(x,...k){const p=key(...k);if(!eq(get(...k),x))delta.set(p,x)}
  return {get,put,delta,seen}
 }
 function count(v,a){const n=v.get('count',a);need(nat(n),'Eje inexistente');return n}
 function alloc(v){const id=v.get('seq');v.put(id+1,'seq');return id}
 function newAxis(v){const id=alloc(v);v.put(0,'count',id);return id}
 function axis(v,a){const k=typeof a==='string'?v.get('axisName',a):nat(a)?v.get('axisIndex',a):undefined;need(k!==undefined,'Eje inexistente');return k}
 function introduce(v,a,n){
  need(U.name(n),'Nombre inválido');let i=v.get('pos',a,n);
  if(i!==undefined)return i;
  i=count(v,a);need(i<65536,'Capacidad');
  v.put(n,'name',a,i);v.put(i,'pos',a,n);v.put(i+1,'count',a);return i
 }
 function context(v,a){return {kind:'context',id:alloc(v),axis:a}}
 function resolve(v,r){
  route(r);let n=v.get('root'),parent=null,i;
  for(const p of r){need(n&&n.kind!=='value'&&n.kind!=='trajectory','Contenido terminal, ausente o frontera');need(p<count(v,n.axis),'Posición inexistente');parent=n;i=p;n=v.get('slot',n.id,p)}
  return {n,parent,i}
 }
 function bound(v,c,x){need(c.parent,'Se requiere posición');v.put(x,'slot',c.parent.id,c.i)}
 function one(v,e){
  const [op,r,x]=ar(e,3);route(r);
  if(op==='AXIS'){
   need(r.length===0&&U.name(x),'AXIS exige nombre');
   if(v.get('axisName',x)===undefined){const j=v.get('axisCount');need(j<65536,'Capacidad');const a=newAxis(v);v.put(a,'axisName',x);v.put(a,'axisIndex',j);v.put(j+1,'axisCount')}
   return
  }
  if(op==='GROW'){ar(r,1);introduce(v,axis(v,r[0]),x);return}
  const c=resolve(v,r),n=c.n;
  if(op==='MOUNT_LOCAL'){need(c.parent&&!n,'Montaje exige posición ausente');const [id,p]=ar(x,2);need(nat(id)&&p==='B','Descriptor inválido');bound(v,c,{kind:'trajectory',id,profile:p});return}
  if(op==='INTRO'){
   need(n?.kind==='context','INTRO exige contexto');const [nm,ref]=ar(x,2),i=introduce(v,n.axis,nm);
   if(ref!==null){const a=axis(v,ref),old=v.get('slot',n.id,i);need(!old||(old.kind==='context'&&old.axis===a),'Eje incompatible');if(!old)v.put(context(v,a),'slot',n.id,i)}
   return
  }
  if(op==='BIND'){need(c.parent,'BIND exige posición');const a=axis(v,x);need(!n||(n.kind==='context'&&n.axis===a),'Eje incompatible');if(!n)bound(v,c,context(v,a));return}
  need(['SET','ADD','SUB'].includes(op)&&c.parent,'Tratamiento desconocido o posición inválida');
  bound(v,c,transform(n,op,x))
 }
 function plan(base,e){
  const v=view(base);
  if(e?.[0]==='BATCH'){ar(e,2);need(Array.isArray(e[1])&&e[1].length>0&&e[1].length<=256,'Lote inválido');for(const q of e[1]){need(Array.isArray(q)&&['AXIS','GROW','INTRO','BIND','SET','ADD','SUB'].includes(q[0]),'Lote contiene tratamiento de frontera');one(v,q)}}else one(v,e);
  return {delta:v.delta,reads:v.seen.size,writes:v.delta.size}
 }
 return {B:{zero,plan,locate:(s,r)=>resolve(view(s),r)}}
})();
