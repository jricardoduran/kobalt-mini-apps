/* 05. API: planificación pura, preguntas y reconocimiento. */
globalThis.QipuTRC=(()=>{
 const {World,encode,hex,unhex}=Qipu.TRCInternal.world,Q=globalThis.Qipu,{need,value:check,ar,route}=Qipu.TRCInternal.domain;
 function allowed(e){need(Array.isArray(e),'Acontecimiento requerido');if(e[0]==='BATCH'){ar(e,2);need(Array.isArray(e[1])&&e[1].length>0&&e[1].length<=256,'Lote inválido');return}const [op,r,x]=ar(e,3);route(r);need(['AXIS','GROW','INTRO','BIND','SET','ADD','SUB','MOUNT','APPEND','TX'].includes(op),'Tratamiento fuera de TRC-B');if(op==='MOUNT'){ar(x,2);need(x[0]==='B','TRC utiliza perfil B')}}
 async function validate(raw,root=true){let o=0;while(o<raw.length){const f=await Q.K5B.read(raw,o);need(f.t===65521,'TRC-B requiere tratamiento 65521');const str=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(f.body),e=JSON.parse(str);check(e);need(JSON.stringify(e)===str,'JSON de marco no canónico');await verifyEvent(e,root);o=f.end}}
 async function verifyEvent(e,root=true){check(e);allowed(e);if(e[0]==='BATCH'){for(const q of e[1]){need(Array.isArray(q)&&['AXIS','GROW','INTRO','BIND','SET','ADD','SUB'].includes(q[0]),'Lote contiene tratamiento de frontera');await verifyEvent(q,false)}return}if(e[0]==='MOUNT')await validate(unhex(e[2][1]),false);if(e[0]==='APPEND')await validate(unhex(e[2]),false);if(e[0]==='TX'){need(root,'TX solo raíz');need(Array.isArray(e[2]?.[2]),'TX inválida');for(const q of e[2][2])await verifyEvent(q,false)}}
 async function open(raw=new Uint8Array()){await validate(raw);return World.replay('B',raw)}
 function cat(a,b){return Q.K4B.cat(a,b)}
 async function execute(w,q){check(q);need(q&&typeof q==='object'&&!Array.isArray(q),'Solicitud requerida');const r=route(q.route??[]);
  switch(q.op){
   case 'write':need(['AXIS','GROW','INTRO','BIND','SET','ADD','SUB','MOUNT'].includes(q.treatment),'Tratamiento inválido');if(q.treatment==='MOUNT'){need(q.content?.[0]==='B','TRC utiliza perfil B');await validate(unhex(q.content[1]),false)}return w.recognized(q.origin,q.checks??[],q.treatment,r,q.content);
   case 'submit':await verifyEvent(q.event);return w.submit(q.event);
   case 'transaction':await verifyEvent(['TX',[],[q.origin,q.checks??[],q.events]]);return w.transaction(q.origin,q.checks??[],q.events);
   case 'read':{const v=q.cut==null?w:await w.at(q.cut);return v.read(r,{enterFinal:q.enterFinal!==false})}
   case 'history':{const v=q.cut==null?w:await w.at(q.cut);return v.history(r,{from:q.from??0,to:q.to??undefined})}
   case 'export':{const v=q.cut==null?w:await w.at(q.cut);let scope=0;if(r.length){const h=await v.history(r,{from:0,to:0});scope=h.scope}return {hex:hex(await v.export(scope,q.end??undefined)),cut:await v.cut(scope)}}
   case 'cut':return {cut:await w.cut()};
   default:throw Error('Operación desconocida')
  }
 }
 async function plan(raw,q){const w=await open(raw),before=await w.cut(),result=await execute(w,q),after=await w.cut(),all=await w.export();need(after===before||after===before+1,'Un marco raíz por solicitud');need(Q.K4B.equal(all.slice(0,raw.length),raw),'Prefijo alterado');return {result,cut:after,suffix:all.slice(raw.length)}}
 return {version:'1.0.0',profile:'B',open,execute,plan,encode:async e=>{check(e);await verifyEvent(e);return encode('B',e)},hex,unhex,cat,check,validate}
})();
