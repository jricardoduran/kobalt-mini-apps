'use strict';
/* Ejemplos B: contextos con ejes compartidos y trayectorias anidadas. */
globalThis.TRCExamples=(()=>{
 const events=[],add=(treatment,route,content)=>events.push({op:'write',origin:'demo-'+String(events.length+1).padStart(3,'0'),treatment,route,content});
 const A=(r,n)=>add('AXIS',r,n),G=(r,a,n)=>add('GROW',[...r,a],n),I=(r,n,a)=>add('INTRO',r,[n,a]),S=(r,x)=>add('SET',r,x),M=r=>add('MOUNT',r,['B','']);
 A([],'productos');G([],1,'SKU-A');G([],1,'SKU-B');
 I([],'Stock Norte',1);I([],'Stock Sur',1);S([0,0],10);S([1,0],7);S([0,1],5);S([1,1],2);
 A([],'clientes');G([],2,'Ana');G([],2,'Luis');I([],'Conversaciones',2);
 const ana=[2,0],luis=[2,1];M(ana);M(luis);
 A(ana,'interacciones');G(ana,1,'M1');I(ana,'Mensajes',1);S([...ana,0,0],'Consulta precio');I(ana,'Seguimiento',1);
 const follow=[...ana,1,0];M(follow);I(follow,'Estado',null);S([...follow,0],'pendiente');
 I(luis,'Mensaje',null);S([...luis,0],'Consulta horario');
 A([],'ventas');G([],3,'V1');I([],'Ventas',3);const sale=[3,0];M(sale);I(sale,'Estado',null);S([...sale,0],'solicitada');I(sale,'Entrega',null);const delivery=[...sale,1];M(delivery);I(delivery,'Estado',null);S([...delivery,0],'esperando');
 A([],'materiales');G([],4,'Revision');G([],4,'Adjunto');I([],'Documentos',4);const rev=[4,0];M(rev);I(rev,'Numero',null);S([...rev,0],1);S([4,1],['archivo','borrador']);
 const routes=[['Raíz',[]],['Stock Norte',[0]],['Stock Sur',[1]],['Norte SKU-A',[0,0]],['Sur SKU-A',[1,0]],['Conversación Ana',ana],['Mensaje Ana',[...ana,0,0]],['Seguimiento',follow],['Estado seguimiento',[...follow,0]],['Conversación Luis',luis],['Venta',sale],['Estado venta',[...sale,0]],['Entrega',delivery],['Estado entrega',[...delivery,0]],['Materiales',[4]],['Revisiones',rev],['Número revisión',[...rev,0]],['Adjunto terminal',[4,1]]];
 const actions=[['Incrementar Norte','ADD',[0,0],1],['Responder a Ana','SET',[...ana,0,0],'Precio 35000'],['Seguimiento','SET',[...follow,0],'contactada'],['Pago informado','SET',[...sale,0],'pagada'],['Despachar','SET',[...delivery,0],'despachado'],['Revisar','ADD',[...rev,0],1]];
 return {events,routes,actions}
})();
