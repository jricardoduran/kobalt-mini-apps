<?php
declare(strict_types=1);
/* Navegación y preguntas. */
trait TRCRoute {
 private function navigate(array $r,bool $enterFinal=true):array{
  TRC::route($r);$s=0;$n=$this->scopes[$s]['root'];$path=[];$bounds=[];$seen=[];$steps=0;
  $access=function(array $key)use(&$seen,&$steps){$seen[TRC::json($key)]=true;$steps++;};$access([$s,'root']);
  $enter=function()use(&$s,&$n,&$path,&$bounds,$access){while(($n['kind']??null)==='trajectory'){$bounds[]=['scope'=>$s,'path'=>$path,'child'=>$n['id'],'profile'=>'B'];$s=$n['id'];$path=[];$access([$s,'root']);$n=$this->scopes[$s]['root'];}};
  foreach($r as $p){$enter();TRC::need($n!==null&&$n['kind']!=='value','Ruta terminal o ausente');$access([$s,'count',$n['axis']]);TRC::need($p<$this->countAxis($s,$n['axis']),'Posición inexistente');$access([$s,'slot',$n['id'],$p]);$n=$this->slot($s,$n['id'],$p);$path[]=$p;}
  if($enterFinal)$enter();return [$s,$n,$path,$bounds,$seen,$steps];
 }
 function read(array $r=[],bool $enterFinal=true):array{
  [$s,$n,$path,$bounds,$seen,$steps]=$this->navigate($r,$enterFinal);
  if($n===null)$data=['absent'];elseif($n['kind']==='value')$data=['value',$n['value']];elseif($n['kind']==='trajectory')$data=['trajectory','B',$n['id']];else{$a=$n['axis'];$seen[TRC::json([$s,'count',$a])]=true;$steps++;$xs=[];for($i=0;$i<$this->countAxis($s,$a);$i++){$seen[TRC::json([$s,'name',$a,$i])]=true;$steps++;$xs[]=[$i,$this->scopes[$s]['names'][$a][$i]];}$data=['context',$xs];}
  return ['data'=>$data,'scope'=>$s,'localPath'=>$path,'boundaries'=>$bounds,'reads'=>count($seen),'steps'=>$steps,'cut'=>$this->cut()];
 }
}
