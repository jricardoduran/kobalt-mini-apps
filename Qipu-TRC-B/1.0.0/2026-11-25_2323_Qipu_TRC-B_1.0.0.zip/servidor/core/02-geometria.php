<?php
declare(strict_types=1);
/* Geometría B. */
trait TRCGeometry {
 private function countAxis(int $s,int $a):int{TRC::need(isset($this->scopes[$s]['counts'][$a]),'Eje inexistente');return $this->scopes[$s]['counts'][$a];}
 private function alloc(int $s):int{return $this->scopes[$s]['seq']++;}
 private function axis(int $s):int{$a=$this->alloc($s);$this->scopes[$s]['counts'][$a]=0;return $a;}
 private function node(int $s,string $kind,int $axis,?int $rows=null):array{$n=['kind'=>$kind,'id'=>$this->alloc($s),'axis'=>$axis];if($rows!==null)$n['rows']=$rows;return $n;}
 private function introduce(int $s,int $a,mixed $name):int{
  TRC::need(TRC::name($name),'Nombre inválido');$key='n:'.$name;if(isset($this->scopes[$s]['pos'][$a][$key]))return $this->scopes[$s]['pos'][$a][$key];
  $i=$this->countAxis($s,$a);TRC::need($i<65536,'Capacidad de eje');$this->scopes[$s]['names'][$a][$i]=$name;$this->scopes[$s]['pos'][$a][$key]=$i;$this->scopes[$s]['counts'][$a]=$i+1;return $i;
 }
 private function slot(int $s,int $id,int $i):?array{return $this->scopes[$s]['slots'][$id][$i]??null;}
 private function put(int $s,array $parent,int $i,array $n):void{$this->scopes[$s]['slots'][$parent['id']][$i]=$n;}
 private function locate(int $s,array $r):array{
  $n=$this->scopes[$s]['root'];$parent=null;$i=null;
  foreach(TRC::route($r) as $p){TRC::need($n!==null&&!in_array($n['kind'],['value','trajectory'],true),'Contenido terminal, ausente o frontera');TRC::need($p<$this->countAxis($s,$n['axis']),'Posición inexistente');$parent=$n;$i=$p;$n=$this->slot($s,$parent['id'],$p);}
  return [$n,$parent,$i];
 }
 private function cell(?array $parent):bool{return $parent!==null;}
 private function axisRef(int $s,mixed $x):int{
  $a=is_string($x)?($this->scopes[$s]['axisNames']['n:'.$x]??null):(TRC::nat($x)?($this->scopes[$s]['axes'][$x]??null):null);
  TRC::need($a!==null,'Eje inexistente');return $a;
 }
 private function local(int $s,array $e):void{
  if(($e[0]??null)==='BATCH'){TRC::ar($e,2);$events=$e[1];TRC::need(is_array($events)&&count($events)>0&&count($events)<=256,'Lote inválido');foreach($events as $q){TRC::need(is_array($q)&&in_array($q[0]??null,['AXIS','GROW','INTRO','BIND','SET','ADD','SUB'],true),'Lote contiene tratamiento de frontera');$this->local($s,$q);}return;}
  [$op,$r,$x]=TRC::ar($e,3);TRC::route($r);
  if($op==='AXIS'){TRC::need($r===[]&&TRC::name($x),'AXIS exige nombre');$k='n:'.$x;if(!isset($this->scopes[$s]['axisNames'][$k])){TRC::need(count($this->scopes[$s]['axes'])<65536,'Capacidad');$a=$this->axis($s);$this->scopes[$s]['axisNames'][$k]=$a;$this->scopes[$s]['axes'][]=$a;}return;}
  if($op==='GROW'){TRC::ar($r,1);$this->introduce($s,$this->axisRef($s,$r[0]),$x);return;}
  [$n,$parent,$i]=$this->locate($s,$r);$kind=$n['kind']??null;
  switch($op){
   case 'INTRO':
    TRC::need($kind==='context','INTRO exige contexto');[$name,$ref]=TRC::ar($x,2);$j=$this->introduce($s,$n['axis'],$name);
    if($ref!==null){$a=$this->axisRef($s,$ref);$old=$this->slot($s,$n['id'],$j);TRC::need($old===null||($old['kind']==='context'&&$old['axis']===$a),'Eje incompatible');if($old===null)$this->put($s,$n,$j,$this->node($s,'context',$a));}return;
   case 'BIND':
    TRC::need($parent!==null,'BIND exige posición');$a=$this->axisRef($s,$x);TRC::need($n===null||($kind==='context'&&$n['axis']===$a),'Eje incompatible');if($n===null)$this->put($s,$parent,$i,$this->node($s,'context',$a));return;
   case 'SET':TRC::need($parent!==null&&($n===null||$kind==='value'),'SET exige celda terminal');$this->put($s,$parent,$i,['kind'=>'value','value'=>$x]);return;
   case 'ADD':case 'SUB':TRC::need($parent!==null&&$kind==='value'&&TRC::nat($n['value'])&&TRC::nat($x),'Diferencial requiere natural existente');$v=$n['value']+($op==='ADD'?$x:-$x);TRC::need(TRC::nat($v),'Natural fuera de dominio');$this->put($s,$parent,$i,['kind'=>'value','value'=>$v]);return;
   default:throw new RuntimeException('Tratamiento inválido');
  }
 }
}
