<?php
declare(strict_types=1);
/* Qipu TRC 1.0.0 — perfil estructural A, K5B sin cambios. PHP >= 8.1, 64 bits. */
final class TRC {
 const MAX=9007199254740991, BODY=1048576, TYPE=65521;
 static function need(bool $ok,string $m='Solicitud inválida'):void{if(!$ok)throw new RuntimeException($m);}
 static function nat(mixed $x):bool{return is_int($x)&&$x>=0&&$x<=self::MAX;}
 static function ar(mixed $x,int $n):array{self::need(is_array($x)&&array_is_list($x)&&count($x)===$n,'Aridad inválida');return $x;}
 static function route(mixed $r):array{self::need(is_array($r)&&array_is_list($r),'Ruta inválida');foreach($r as $p)self::need(self::nat($p),'Ruta inválida');return $r;}
 static function check(mixed $x,int $d=0):void{
  self::need($d<=64,'Contenido demasiado profundo');
  if($x===null||is_bool($x)||is_int($x)&&$x>=-self::MAX&&$x<=self::MAX)return;
  if(is_string($x)){self::need(preg_match('//u',$x)===1,'Unicode inválido');return;}
  if(is_array($x)){self::need(array_is_list($x),'Lista inválida');foreach($x as $v)self::check($v,$d+1);return;}
  self::need($x instanceof stdClass,'JSON inválido');foreach($x as $k=>$v){self::check((string)$k,$d+1);self::check($v,$d+1);}
 }
 static function name(mixed $x):bool{if(!is_string($x)||$x===''||preg_match('//u',$x)!==1)return false;return preg_match_all('/./us',$x)+preg_match_all('/[\x{10000}-\x{10FFFF}]/u',$x)<=200;}
 static function jsOrder(mixed $x):mixed{
  if(is_array($x))return array_map([self::class,'jsOrder'],$x);
  if(!($x instanceof stdClass))return $x;
  $num=[];$rest=[];foreach($x as $k=>$v){$k=(string)$k;if(preg_match('/^(0|[1-9][0-9]{0,9})$/D',$k)&&strlen($k)<=10&&(float)$k<4294967295)$num[$k]=$v;else $rest[$k]=$v;}
  ksort($num,SORT_NUMERIC);$o=new stdClass;foreach([$num,$rest] as $a)foreach($a as $k=>$v)$o->{(string)$k}=self::jsOrder($v);return $o;
 }
 static function json(mixed $x):string{return json_encode(self::jsOrder($x),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_LINE_TERMINATORS);}
 static function normalize(mixed $x):mixed{if(is_float($x)&&is_finite($x)&&floor($x)===$x&&abs($x)<=self::MAX)return (int)$x;if(is_array($x))return array_map([self::class,'normalize'],$x);if($x instanceof stdClass){foreach($x as $k=>$v)$x->{$k}=self::normalize($v);}return $x;}
 static function parse(string $s):mixed{$x=self::normalize(json_decode($s,false,512,JSON_THROW_ON_ERROR));self::check($x);return $x;}
 static function eq(mixed $a,mixed $b):bool{return self::json($a)===self::json($b);}
 static function unhex(mixed $x):string{self::need(is_string($x)&&strlen($x)%2===0&&preg_match('/^[0-9a-f]*$/D',$x)===1,'Hex canónico requerido');return hex2bin($x);}
 static function encode(array $e):string{
  self::check($e);$b=self::json($e);$n=strlen($b);self::need($n<=self::BODY,'Longitud fuera de límite');$k=$n<=255?1:($n<=65535?2:3);
  $p=pack('nC',self::TYPE,$k-1).substr(pack('N',$n),4-$k).$b;return $p.hash('sha256',"QIPU-K5B-1\0".$p,true);
 }
 static function frame(string $raw,int $o=0):array{
  self::need($o>=0&&$o+4<=strlen($raw),'Encabezado truncado');$type=unpack('n',substr($raw,$o,2))[1];self::need($type===self::TYPE,'TRC-B requiere tratamiento 65521');$k=ord($raw[$o+2])+1;
  self::need($k<=3&&$o+3+$k<=strlen($raw),'Longitud inválida');$n=0;for($j=0;$j<$k;$j++)$n=($n<<8)|ord($raw[$o+3+$j]);self::need($n<=self::BODY&&$k===($n<=255?1:($n<=65535?2:3)),'Longitud no canónica');$p=$o+3+$k;$end=$p+$n+32;self::need($end<=strlen($raw),'Registro truncado');
  self::need(hash_equals(hash('sha256',"QIPU-K5B-1\0".substr($raw,$o,$end-$o-32),true),substr($raw,$end-32,32)),'Hash no coincide');$body=substr($raw,$p,$n);$e=self::parse($body);self::need(self::json($e)===$body,'JSON de marco no canónico');return [$e,$end,substr($raw,$o,$end-$o)];
 }
 static function verify(mixed $e,bool $root=true):void{
  if(is_array($e)&&($e[0]??null)==='BATCH'){self::ar($e,2);self::need(is_array($e[1])&&count($e[1])>0&&count($e[1])<=256,'Lote inválido');foreach($e[1] as $q){self::need(is_array($q)&&in_array($q[0]??null,['AXIS','GROW','INTRO','BIND','SET','ADD','SUB'],true),'Lote contiene tratamiento de frontera');self::verify($q,false);}return;}
  [$op,$r,$x]=self::ar($e,3);self::route($r);self::need(in_array($op,['AXIS','GROW','INTRO','BIND','SET','ADD','SUB','MOUNT','APPEND','TX'],true),'Tratamiento fuera de TRC-B');
  if($op==='MOUNT'){[$p,$h]=self::ar($x,2);self::need($p==='B','TRC utiliza perfil B');self::validate(self::unhex($h),false);}
  if($op==='APPEND')self::validate(self::unhex($x),false);
  if($op==='TX'){self::need($root,'TX solo raíz');[,,$events]=self::ar($x,3);self::need(is_array($events),'TX inválida');foreach($events as $q)self::verify($q,false);}
 }
 static function validate(string $raw,bool $root=true):void{for($o=0;$o<strlen($raw);$o=$end){[$e,$end]=self::frame($raw,$o);self::verify($e,$root);}}
}
