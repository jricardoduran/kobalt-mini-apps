# Qipu TRC-B 1.0.0
Perfil general B: contextos y ejes compartidos, manifestaciones dispersas y trayectorias interiores. Ver local/documentacion.html o servidor/documentacion.html. K5B 65521, raíz con eje 0; TX, BATCH, historia, exportación, cola y persistencia. Los ejes pertenecen a cada trayectoria. No mezcla perfiles ni contiene DEPEND/CAUSE.

## Uso
Desde el ZIP descomprimido: `python3 -m http.server 8080 -d local` o `QIPU_TRC_DATA="$HOME/qipu-trc-b-lab" php -S 127.0.0.1:8081 -t servidor`. PHP >=8.1, 64 bits, Linux, datos fuera del directorio público. Pruebas: `node pruebas/paridad.cjs` y `node pruebas/browser-run.cjs` (requiere Chrome/Chromium). API POST JSON en localhost; token opcional. No desplegar sin autorización propia. Sin dependencias externas de ejecución. Los adaptadores reconstruyen el prefijo completo por solicitud; no se optimiza representación ni se prueba apagón.

## Organización
Cinco módulos JS de local/core en orden: binario K4B/K5B, dominio, geometría B, trayectoria (recorrido, composición, admisión e historia), API. node.cjs es entrada Node. PHP separa binario/dominio, geometría y recorrido, continuidad/API en QipuTRC.php. Persistencia, UI y ejemplos separados. BATCH local no contiene fronteras. TX solo raíz. AXIS/GROW en write requieren la ruta a la raíz de la trayectoria, más índice del eje para GROW. INTRO/BIND admiten nombre o índice local. No hay reutilización de coordenadas entre ámbitos. Las pruebas comparan bytes y respuestas; no constituyen demostración universal. Publicación exclusivamente ZIP.
