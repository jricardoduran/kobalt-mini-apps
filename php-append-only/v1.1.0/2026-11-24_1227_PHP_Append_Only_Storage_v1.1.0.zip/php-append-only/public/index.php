<?php
declare(strict_types=1);
require __DIR__.'/../src/Storage.php';
// Deploy public/ as document root, storage directory outside it. HTTPS mandatory in production.
function respond(int $status,array $data): never { http_response_code($status); header('Content-Type: application/json'); echo json_encode($data,JSON_UNESCAPED_SLASHES); exit; }
function number(string $key): int { $v=$_GET[$key]??null; if (!is_string($v)||!preg_match('/\A(?:0|[1-9][0-9]{0,18})\z/',$v)||filter_var($v,FILTER_VALIDATE_INT,['options'=>['min_range'=>0]])===false) throw new StorageError(400,'Invalid '.$key); return (int)$v; }
try {
    $root=getenv('PAO_ROOT'); $verifier=getenv('PAO_TOKEN_SHA256');
    if (!$root||!$verifier||!preg_match('/\A[0-9a-f]{64}\z/',$verifier)) throw new StorageError(503,'Not configured');
    $auth=$_SERVER['HTTP_AUTHORIZATION']??'';
    if (!str_starts_with($auth,'Bearer ')||!hash_equals($verifier,hash('sha256',substr($auth,7)))) throw new StorageError(401,'Unauthorized');
    $id=$_GET['id']??''; $op=$_GET['op']??''; if(!is_string($id)||!is_string($op)) throw new StorageError(400,'Invalid request');
    $s=new Storage($root); $method=$_SERVER['REQUEST_METHOD'];
    if ($op==='create'&&$method==='POST') respond(201,$s->create($id));
    if ($op==='head'&&$method==='GET') respond(200,$s->head($id));
    if ($op==='append'&&$method==='POST') { $b=file_get_contents('php://input',false,null,0,Storage::MAX+1); if($b===false||strlen($b)>Storage::MAX) throw new StorageError(413,'Payload too large'); respond(200,$s->append($id,number('offset'),$b)); }
    if ($op==='read'&&$method==='GET') { $r=$s->read($id,number('offset'),number('length')); header('Content-Type: application/octet-stream'); header('X-Confirmed-End: '.$r['end']); header('Content-Length: '.strlen($r['bytes'])); echo $r['bytes']; exit; }
    throw new StorageError(405,'Unsupported operation');
} catch(StorageError $e){respond($e->status,['error'=>$e->getMessage()]);} catch(Throwable $e){error_log($e::class);respond(503,['error'=>'Storage unavailable']);}
