# PHP Append-Only Storage · PAO 1.0.0
2026-11-24 · Qipu / Kobalt · mecanismo independiente de formato.

## Instalación
PHP 8.1+ de 64 bits, Linux, filesystem POSIX local con flock, fsync de archivo y directorio. Crear un directorio privado (fuera del document root, accesible solo por el usuario PHP). Servir únicamente `public/` por HTTPS. No exponer `src/`, `tests/` ni datos. No compartir el directorio con otros escritores, ni reemplazar archivos, ni usar symlinks. Para desarrollo local:

```sh
mkdir -m 700 /tmp/pao-data
export PAO_ROOT=/tmp/pao-data
TOKEN=$(php -r 'echo bin2hex(random_bytes(32));')
export PAO_TOKEN_SHA256=$(printf %s "$TOKEN" | sha256sum | cut -d' ' -f1)
php -S 127.0.0.1:8080 -t public
```
En otra terminal con el TOKEN configurado localmente, usar `Authorization: Bearer $TOKEN`. Ejemplo (sin secretos en URL):

```sh
curl -X POST -H "Authorization: Bearer $TOKEN" 'http://127.0.0.1:8080/?op=create&id=demo'
printf 'abc' | curl -X POST -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/octet-stream' --data-binary @- 'http://127.0.0.1:8080/?op=append&id=demo&offset=0'
curl -H "Authorization: Bearer $TOKEN" 'http://127.0.0.1:8080/?op=head&id=demo'
curl -H "Authorization: Bearer $TOKEN" 'http://127.0.0.1:8080/?op=read&id=demo&offset=0&length=3'
```
Configurar variables de entorno en PHP-FPM/hosting; ajustar límites HTTP y memoria (máximo 8 MiB por operación). El servidor de desarrollo no es producción. `php tests/run.php` ejecuta pruebas locales.

## Contrato
CREATE (POST), HEAD (GET), APPEND (POST binario con offset esperado), READ (GET offset y length). HEAD/READ pueden completar una intención durable ya autorizada. No hay DELETE/UPDATE. 409 conflicto; 503 estado incierto, reintentar misma posición y contenido o investigar. 416 fuera de rango. Respuesta de append: offset, length, end, replayed. Una repetición de bytes idénticos dentro del prefijo es confirmación posicional, no prueba de identidad de operación ni de frontera semántica. El cliente conserva solicitud hasta confirmación. Unidades: bytes, offsets cero-based. Los IDs son ASCII y el directorio privado constituye frontera de confianza.

## Seguridad
El token aleatorio de 256 bits (no contraseña humana) se valida con SHA-256 y hash_equals. Es una credencial reutilizable de autoridad única, no una firma HMAC por solicitud; no hay registro UID, roles ni custodia de claves de terceros en esta versión. Integrar la futura autoridad derivada como capa independiente; para HMAC de mensajes debe existir material simétrico de verificación; para no guardar secreto de firma usar Ed25519. HTTPS y rate limits externos. No incluir tokens en logs. No usar este demo como API multiusuario sin autorización por trayectoria. El núcleo conserva bytes, no valida R4/R5 ni formatos semánticos. No protege ante administrador malicioso, disco corrupto, NFS incompatible ni otros procesos que ignoren flock. chattr +a opcional en Linux, bajo administrador y pruebas; archivos auxiliares deben seguir mutables.

## Garantías y recuperación
Bloqueo exclusivo en el inode estable de data.bin, descriptor rb; escritura exclusivamente por ab; una intención durable por trayectoria. Publicación mediante tmp fsync, rename, fsync del directorio; después se verifica prefijo parcial y se anexa resto, fsync del archivo; unlink y fsync del directorio. Si fsync falla no se confirma. No truncar ni reemplazar data.bin. Se requiere directorio preexistente durable, almacenamiento que honre fsync y ninguna modificación externa. La recuperación es roll-forward, no rollback: una intención publicada puede completarse aunque el cliente no recibiera respuesta. Un fallo físico que no deje un prefijo compatible exige intervención y restauración externa. No se ofrece disponibilidad ante falta de disco. HEAD/READ adquieren bloqueo exclusivo brevemente para recuperar antes de entregar un corte; read libera bloqueo antes de leer un prefijo inmutable. No FIFO. No idempotencia de append libre. Costo normal O(k), sin escanear historia. Retención temporal O(k) y dos escrituras del payload. No transacción entre varias trayectorias.

Documentación visual: `guia.html`. Referencias: https://www.php.net/manual/es/function.flock.php · https://www.php.net/manual/es/function.fopen.php · https://www.php.net/manual/es/function.fsync.php · https://man7.org/linux/man-pages/man2/fsync.2.html
