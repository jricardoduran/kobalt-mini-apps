/* Kobalt Kernel 10.0.0 | Qipu 1.0.0 binary profile retained. */
/* Qipu K2P: natural canónico, MSB primero. Independiente de entidades. */
'use strict';
globalThis.Qipu = globalThis.Qipu || {};
Qipu.K2P = (() => {
  const need = (ok,msg='K2P inválido') => {if(!ok) throw Error(msg);};
  function encode(n,w=4){need(Number.isSafeInteger(n)&&n>=0,'Natural fuera de dominio');need(Number.isInteger(w)&&w>=1&&w<=8,'Perfil W inválido');const b=n.toString(2),k=b.length;need(k<=2**w,'Natural fuera del perfil');return (k-1).toString(2).padStart(w,'0')+b;}
  class Writer {
    constructor(){this.parts=[];}
    n(n,w=4){this.parts.push(encode(n,w));return this;}
    text(s){need(typeof s==='string','Texto requerido');const b=new TextEncoder().encode(s);need(new TextDecoder('utf-8',{fatal:true}).decode(b)===s,'Unicode no válido');this.n(b.length,6);for(const x of b)this.parts.push(x.toString(2).padStart(8,'0'));return this;}
    bytes(){let s=this.parts.join('');s=s.padEnd(Math.ceil(s.length/8)*8,'0');return Uint8Array.from(s.match(/.{8}/g)||[],x=>parseInt(x,2));}
  }
  class Reader {
    constructor(bytes){this.b=bytes;this.p=0;}
    take(k){need(this.p+k<=this.b.length*8,'Campo truncado');let n=0n;for(let j=0;j<k;j++,this.p++)n=(n<<1n)|BigInt((this.b[this.p>>3]>>(7-(this.p&7)))&1);return n;}
    n(w=4){const k=Number(this.take(w))+1;need(k<=53,'Natural fuera del dominio seguro');const n=Number(this.take(k));need(n.toString(2).length===k,'Natural no canónico');return n;}
    text(){const k=this.n(6);need(k<=Math.floor((this.b.length*8-this.p)/8),'Texto truncado');const b=new Uint8Array(k);for(let j=0;j<k;j++)b[j]=Number(this.take(8));return new TextDecoder('utf-8',{fatal:true}).decode(b);}
    finish(){const k=this.b.length*8-this.p;need(k<8&&this.take(k)===0n,'Padding no canónico');}
  }
  return {encode,Writer,Reader,need};
})();

/* K4B: W8 | L (k bytes) | B | H256. H compromete dominio + encabezado + B. */
'use strict';
Qipu.K4B = (()=>{
 const {need}=Qipu.K2P, MAX=1048576;
 const cat=(...parts)=>{const b=new Uint8Array(parts.reduce((a,p)=>a+p.length,0));let i=0;for(const p of parts){b.set(p,i);i+=p.length;}return b;};
 const domain=s=>new TextEncoder().encode(s+'\0');
 const equal=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]);
 const hash=async b=>{need(globalThis.crypto?.subtle,'Web Crypto no disponible: abra en localhost o HTTPS');return new Uint8Array(await crypto.subtle.digest('SHA-256',b));};
 function lengthBytes(n){need(Number.isInteger(n)&&n>=0&&n<=MAX,'Longitud fuera de límite');let k=n<=255?1:n<=65535?2:3;const a=new Uint8Array(k+1);a[0]=k-1;for(let j=k;j>0;j--){a[j]=n&255;n=Math.floor(n/256);}return a;}
 async function seal(body,prefix=new Uint8Array(),d='QIPU-K4B-1'){need(body instanceof Uint8Array,'Cuerpo binario requerido');const p=cat(prefix,lengthBytes(body.length),body);return cat(p,await hash(cat(domain(d),p)));}
 async function read(bytes,offset=0,prefixSize=0,d='QIPU-K4B-1'){
  need(Number.isSafeInteger(offset)&&offset>=0&&offset<=bytes.length,'Offset inválido');const start=offset;let p=offset+prefixSize;need(p<bytes.length,'Encabezado truncado');const k=bytes[p++]+1;need(k<=4&&p+k<=bytes.length,'Ancho inválido o truncado');let n=0;for(let j=0;j<k;j++)n=n*256+bytes[p++];need(n<=MAX&&lengthBytes(n)[0]===k-1,'Longitud no canónica');const end=p+n,stop=end+32;need(stop<=bytes.length,'Registro truncado');const h=await hash(cat(domain(d),bytes.subarray(start,end)));need(equal(h,bytes.subarray(end,stop)),'Hash no coincide');return {prefix:bytes.slice(start,start+prefixSize),body:bytes.slice(p,end),end:stop,hash:h};
 }
 return {seal,read,cat,equal,MAX};
})();

/* K5B: composición de reconocimiento T16 con K4B; dominio separado. */
'use strict';
Qipu.K5B=(()=>{const {need}=Qipu.K2P;return {
 async seal(t,b){need(Number.isInteger(t)&&t>=0&&t<=65535,'Tratamiento inválido');return Qipu.K4B.seal(b,Uint8Array.of(t>>8,t&255),'QIPU-K5B-1');},
 async read(b,p=0){const r=await Qipu.K4B.read(b,p,2,'QIPU-K5B-1');return {...r,t:r.prefix[0]*256+r.prefix[1]};}
};})();

/* Contratos de ejemplo, NO parte del mecanismo binario. Posiciones K2P-4;
 cantidades, precios, longitudes de texto K2P-6 (enteros JS seguros). */
'use strict';
Qipu.Contratos=(()=>{
 const {Writer,Reader,need}=Qipu.K2P;
 const names={1:'CONSTITUIR_TABLA',2:'CONSTITUIR_VECTOR',3:'CONSTITUIR_ENTIDAD',4:'SET_TEXTO',5:'STOCK_SET',6:'STOCK_ADD',7:'VENTA',8:'SET_NATURAL',9:'SET_NULO',10:'QUITAR_VALOR',11:'SET_BOOLEANO',12:'STOCK_SUB'};
 const kinds=['texto','natural','stock','booleano'];
 function fields(t,a){const w=new Writer(),p=n=>w.n(n),v=n=>w.n(n,6),s=x=>w.text(x);switch(t){case 1:s(a[0]);break;case 2:p(a[0]);s(a[1]);p(a[2]);break;case 3:p(a[0]);s(a[1]);break;case 4:p(a[0]);p(a[1]);p(a[2]);s(a[3]);break;case 5:case 6:case 8:case 12:p(a[0]);p(a[1]);p(a[2]);v(a[3]);break;case 7:p(a[0]);p(a[1]);p(a[2].length);for(const [i,q,price] of a[2]){p(i);v(q);v(price);}break;case 9:case 10:p(a[0]);p(a[1]);p(a[2]);break;case 11:p(a[0]);p(a[1]);p(a[2]);need(typeof a[3]==='boolean','Booleano requerido');p(+a[3]);break;default:throw Error('Contrato desconocido');}return w.bytes();}
 async function encode(t,...a){return Qipu.K5B.seal(t,fields(t,a));}
 function decode(t,b){const r=new Reader(b),p=()=>r.n(),v=()=>r.n(6),s=()=>r.text();let a;switch(t){case 1:a=[s()];break;case 2:a=[p(),s(),p()];break;case 3:a=[p(),s()];break;case 4:a=[p(),p(),p(),s()];break;case 5:case 6:case 8:case 12:a=[p(),p(),p(),v()];break;case 7:{const table=p(),vec=p(),n=p();need(n>0,'Venta vacía');const lines=[];for(let j=0;j<n;j++)lines.push([p(),v(),v()]);a=[table,vec,lines];break;}case 9:case 10:a=[p(),p(),p()];break;case 11:{a=[p(),p(),p()];let x=p();need(x<=1,'Booleano inválido');a.push(!!x);break;}default:throw Error('Contrato desconocido');}r.finish();return {t,a};}
 return {names,kinds,encode,decode};
})();

/* IndexedDB: log autoritativo + materializaciones desechables. Sin service worker.
 Un append confirmado y sus efectos/cursor se publican en UNA transacción. */
'use strict';
Qipu.Storage=(()=>{
 const stores=['log','tables','vectors','entities','cells','sales','meta'];
 const derived=['tables','vectors','entities','cells','sales'];
 const req=r=>new Promise((res,rej)=>{r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});
 function open(name='qipu-continuidad-1.0.0'){return new Promise((res,rej)=>{const r=indexedDB.open(name,1);r.onupgradeneeded=()=>{const d=r.result;for(const s of stores){const o=d.createObjectStore(s);if(s==='entities')o.createIndex('identity',['table','identity'],{unique:true});if(s==='vectors')o.createIndex('name',['table','name'],{unique:true});if(s==='tables')o.createIndex('name','name',{unique:true});}};r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);r.onblocked=()=>rej(Error('Base bloqueada'));});}
 async function tx(db,ss,mode,fn){const t=db.transaction(ss,mode);const done=new Promise((res,rej)=>{t.oncomplete=res;t.onabort=()=>rej(t.error||Error('Transacción abortada'));t.onerror=()=>{};});done.catch(()=>{});const api={get:(s,k)=>req(t.objectStore(s).get(k)),all:(s,range)=>req(t.objectStore(s).getAll(range)),keys:(s)=>req(t.objectStore(s).getAllKeys()),put:(s,k,v)=>req(t.objectStore(s).put(v,k)),del:(s,k)=>req(t.objectStore(s).delete(k)),clear:s=>req(t.objectStore(s).clear()),index:(s,i,k)=>req(t.objectStore(s).index(i).get(k))};try{const x=await fn(api);await done;return x;}catch(e){try{t.abort();}catch{}await done.catch(()=>{});throw e;}}
 const range=(...prefix)=>IDBKeyRange.bound(prefix,[...prefix,Infinity]);
 function remove(name){return new Promise((res,rej)=>{const r=indexedDB.deleteDatabase(name);r.onsuccess=res;r.onerror=()=>rej(r.error);r.onblocked=()=>rej(Error('Base bloqueada'));});}
 return {stores,derived,open,tx,range,remove};
})();

/* Adaptador de memoria para ejemplos y verificación sin IndexedDB.
   La misma función constitutiva opera en ambos entornos. */
(function(){const real=Qipu.Storage,{stores,derived}=real,dbs=new Map(),clone=x=>structuredClone(x),key=k=>JSON.stringify(k),prefixMatch=(k,p)=>Array.isArray(k)&&p.every((v,i)=>v===k[i]);
const order=(a,b)=>Array.isArray(a)?a.reduce((out,v,i)=>out||v-b[i],0):a-b;
function memOpen(name){if(!dbs.has(name))dbs.set(name,{data:new Map(stores.map(s=>[s,new Map()])),queue:Promise.resolve()});return {_memory:dbs.get(name),close(){}}}
function memTx(handle,ss,mode,fn){const db=handle._memory;const run=async()=>{const data=clone(db.data);const m=s=>data.get(s),entries=(s,p)=>[...m(s).values()].filter(e=>!p||prefixMatch(e.k,p)).sort((a,b)=>order(a.k,b.k));const api={get:async(s,k)=>clone(m(s).get(key(k))?.v),all:async(s,p)=>entries(s,p).map(e=>clone(e.v)),keys:async s=>entries(s).map(e=>clone(e.k)),put:async(s,k,v)=>m(s).set(key(k),{k:clone(k),v:clone(v)}),del:async(s,k)=>m(s).delete(key(k)),clear:async s=>m(s).clear(),index:async(s,i,k)=>entries(s).map(e=>e.v).find(v=>key(s==='tables'?v.name:[v.table,i==='identity'?v.identity:v.name])===key(k))};const result=await fn(api);if(mode==='readwrite')db.data=data;return result};const promise=db.queue.then(run);db.queue=promise.catch(()=>{});return promise}
Qipu.Storage={stores,derived,range:(...p)=>p,open:(name)=>typeof indexedDB==='undefined'?Promise.resolve(memOpen(name)):real.open(name),openMemory:async(name)=>memOpen(name),removeMemory:async name=>dbs.delete(name),remove:async name=>typeof indexedDB==='undefined'?dbs.delete(name):real.remove(name),tx:(db,ss,mode,fn)=>db._memory?memTx(db,ss,mode,fn):real.tx(db,ss,mode,x=>fn({...x,all:(s,p)=>x.all(s,p?real.range(...p):undefined)}))};})();

/* El único intérprete constitutivo. UI no modifica derivados directamente. */
'use strict';
Qipu.Continuidad=(()=>{
 const {need}=Qipu.K2P,{stores,derived,tx,range}=Qipu.Storage;
 const zero=()=>({seq:0,offset:0,tables:0});
 const sum=(a,b)=>{let n=a+b;need(Number.isSafeInteger(n)&&n>=0,'Desbordamiento o stock negativo');return n;};
 const product=(a,b)=>{let n=a*b;need(Number.isSafeInteger(n)&&n>=0,'Total fuera de dominio');return n;};
 async function apply(x,e,m){const {t,a}=e;let [table,v,i,value]=a;
  if(t===1){need(a[0].length>0,'Nombre vacío');need(!await x.index('tables','name',a[0]),'Tabla duplicada');need(m.tables<65536,'Límite tablas');await x.put('tables',m.tables,{id:m.tables,name:a[0],entities:0,vectors:0});m.tables++;return;}
  const tab=await x.get('tables',table);need(tab,'Tabla no constituida');
  if(t===2){need(a[1].length>0&&Qipu.Contratos.kinds[a[2]],'Vector inválido');need(!await x.index('vectors','name',[table,a[1]]),'Vector duplicado');need(tab.vectors<65536,'Límite vectores');await x.put('vectors',[table,tab.vectors],{table,id:tab.vectors,name:a[1],kind:a[2]});tab.vectors++;await x.put('tables',table,tab);return;}
  if(t===3){need(a[1].length>0,'Identidad vacía');need(!await x.index('entities','identity',[table,a[1]]),'Identidad duplicada');need(tab.entities<65536,'Límite entidades');await x.put('entities',[table,tab.entities],{table,id:tab.entities,identity:a[1]});tab.entities++;await x.put('tables',table,tab);return;}
  const vec=await x.get('vectors',[table,v]);need(vec,'Vector no constituido');
  const key=i=>[table,v,i],valid=i=>need(Number.isInteger(i)&&i>=0&&i<tab.entities,'Posición no constituida');
  if(t===7){need(vec.kind===2,'Venta exige vector stock');const totals=new Map();let total=0;for(const [idx,q,price] of a[2]){valid(idx);need(q>0,'Cantidad debe ser positiva');totals.set(idx,sum(totals.get(idx)||0,q));total=sum(total,product(q,price));}const updates=[];for(const [idx,q] of totals){const old=await x.get('cells',key(idx));need(Number.isSafeInteger(old)&&old>=q,'Stock insuficiente o no asignado');updates.push([idx,old-q]);}for(const [idx,n] of updates)await x.put('cells',key(idx),n);await x.put('sales',m.seq,{seq:m.seq,table,vector:v,lines:a[2],total});return;}
  valid(i);const k=key(i);
  if(t===4){need(vec.kind===0,'Tipo texto requerido');await x.put('cells',k,value);}
  else if(t===8){need(vec.kind===1,'Tipo natural requerido');await x.put('cells',k,value);}
  else if(t===11){need(vec.kind===3,'Tipo booleano requerido');await x.put('cells',k,value);}
  else if(t===9){need(vec.kind!==2,'Stock no admite null');await x.put('cells',k,null);}
  else if(t===10){need(vec.kind!==2,'Stock no admite quitar valor');await x.del('cells',k);}
  else if([5,6,12].includes(t)){need(vec.kind===2,'Vector stock requerido');let n=value;if(t!==5){const old=await x.get('cells',k);need(Number.isSafeInteger(old)&&value>0,'Stock no asignado o diferencial inválido');n=sum(old,t===6?value:-value);}await x.put('cells',k,n);}
  else throw Error('Contrato desconocido');
 }
 async function parse(raw){const b=raw instanceof Uint8Array?raw:new Uint8Array(raw);const r=await Qipu.K5B.read(b);need(r.end===b.length,'Bytes adicionales en registro');return {raw:b,event:Qipu.Contratos.decode(r.t,r.body)};}
 async function scan(bytes){let p=0;const records=[];while(p<bytes.length){try{const r=await Qipu.K5B.read(bytes,p);const event=Qipu.Contratos.decode(r.t,r.body);records.push({raw:bytes.slice(p,r.end),event});p=r.end;}catch(e){return {records,offset:p,error:e.message};}}return {records,offset:p,error:null};}
 async function applyRecord(x,r,m,writeLog){await apply(x,r.event,m);if(writeLog)await x.put('log',m.seq,r.raw);m.seq++;m.offset+=r.raw.length;}
 async function append(db,raw){const r=await parse(raw);return tx(db,stores,'readwrite',async x=>{const m=await x.get('meta','cursor')||zero();await applyRecord(x,r,m,true);await x.put('meta','cursor',m);return m;});}
 async function replace(db,bytes){const parsed=await scan(bytes);need(!parsed.error,`Importación rechazada en byte ${parsed.offset}: ${parsed.error}`);return tx(db,stores,'readwrite',async x=>{for(const s of stores)await x.clear(s);const m=zero();for(const r of parsed.records)await applyRecord(x,r,m,true);await x.put('meta','cursor',m);return m;});}
 async function exportBytes(db){return tx(db,['log'],'readonly',async x=>Qipu.K4B.cat(...await x.all('log')));}
 async function rebuild(db){/* Snapshot consistente del log; detectar modificaciones concurrentes con igualdad de bytes. */
  const bytes=await exportBytes(db),parsed=await scan(bytes);need(!parsed.error,'Log inválido: '+parsed.error);
  return tx(db,stores,'readwrite',async x=>{const actual=Qipu.K4B.cat(...await x.all('log'));need(Qipu.K4B.equal(bytes,actual),'Log cambió durante reconstrucción; reintente');for(const s of derived)await x.clear(s);const m=zero();for(const r of parsed.records)await applyRecord(x,r,m,false);await x.put('meta','cursor',m);return m;});
 }
 const getMeta=db=>tx(db,['meta'],'readonly',async x=>await x.get('meta','cursor')||zero());
 const tables=db=>tx(db,['tables'],'readonly',x=>x.all('tables'));
 const vectors=(db,t)=>tx(db,['vectors'],'readonly',x=>x.all('vectors',range(t)));
 const identities=(db,t)=>tx(db,['entities'],'readonly',x=>x.all('entities',range(t)));
 const resolve=(db,t,identity)=>tx(db,['entities'],'readonly',async x=>(await x.index('entities','identity',[t,identity]))?.id);
 async function readVector(db,t,v){return tx(db,['tables','vectors','cells'],'readonly',async x=>{const tab=await x.get('tables',t),vec=await x.get('vectors',[t,v]);need(tab&&vec,'Vector inexistente');const vals=[];for(let i=0;i<tab.entities;i++)vals.push(await x.get('cells',[t,v,i]));return {vec,values:vals};});}
 async function project(db,t,i){return tx(db,['entities','vectors','cells'],'readonly',async x=>{const entity=await x.get('entities',[t,i]);need(entity,'Entidad inexistente');const params=Object.create(null);for(const v of await x.all('vectors',range(t))){const val=await x.get('cells',[t,v.id,i]);if(val!==undefined)params[v.name]=val;}return {identity:entity.identity,parameters:params};});}
 const sales=db=>tx(db,['sales'],'readonly',x=>x.all('sales'));
 const log=db=>tx(db,['log'],'readonly',x=>x.all('log'));
 return {append,replace,scan,exportBytes,rebuild,getMeta,tables,vectors,identities,resolve,readVector,project,sales,log};
})();

'use strict';
Qipu.Ejemplos=(()=>{
 const base=[[1,'Productos'],[2,0,'nombre',0],[2,0,'precio',1],[2,0,'stock',2]];
 for(const [i,id,n,p,q] of [[0,'A','Camisa',35000,20],[1,'B','Pantalón',65000,15],[2,'C','Zapato',80000,8]])base.push([3,0,id],[4,0,0,i,n],[8,0,1,i,p],[5,0,2,i,q]);
 const ops=[[5,0,2,1,12],[6,0,2,1,5],[7,0,2,[[1,2,65000]]],[7,0,2,[[0,3,35000],[1,4,65000],[2,1,80000]]]];
 const extended=[[2,0,'color',0],[4,0,3,1,'Negro'],[2,0,'activo',3],[11,0,4,0,true],[11,0,4,1,false],[9,0,3,0],[1,'Categorías'],[2,1,'nombre',0],[3,1,'CAT-A'],[4,1,0,0,'Ropa'],[6,0,2,2,3],[12,0,2,2,1],[7,0,2,[[1,1,65000],[1,2,65000]]],[3,0,'D'],[4,0,0,3,'Abrigo'],[8,0,1,3,120000],[5,0,2,3,6]];
 const events=[...base,...ops,...extended];
 async function frames(list=events){return Promise.all(list.map(([t,...a])=>Qipu.Contratos.encode(t,...a)));}
 async function binary(list=events){return Qipu.K4B.cat(...await frames(list));}
 return {base,ops,extended,events,frames,binary};
})();

/* Pruebas reales en IndexedDB del navegador, siempre en una base aislada. */
'use strict';
Qipu.Pruebas=(()=>{
 const C=Qipu.Continuidad,S=Qipu.Storage,E=Qipu.Ejemplos,K=Qipu.K2P,B=Qipu.K4B;
 const assert=(ok,msg)=>{if(!ok)throw Error(msg||'Aserción fallida');};
 const eq=(a,b)=>assert(JSON.stringify(a)===JSON.stringify(b),`No coincide: ${JSON.stringify(a)} / ${JSON.stringify(b)}`);
 async function rejects(f){let bad=false;try{await f();}catch{bad=true;}assert(bad,'Debió rechazar');}
 async function run(onResult=()=>{}){
 const name='qipu-test-'+Date.now()+'-'+Math.random().toString(36).slice(2),results=[];let db=await S.open(name);
 const record=async(label,f)=>{const start=performance.now();try{const detail=await f();results.push({prueba:label,estado:'OK',detalle:detail,ms:Math.round(performance.now()-start)});}catch(e){results.push({prueba:label,estado:'ERROR',detalle:e.message,ms:Math.round(performance.now()-start)});}onResult(results.at(-1));};
 const append=(...a)=>Qipu.Contratos.encode(...a).then(b=>C.append(db,b));const stock=async()=> (await C.readVector(db,0,2)).values;
 try{
  const frames=await E.frames(), bytes=B.cat(...frames), baseline=await E.binary([...E.base,...E.ops]);
  await record('K2P-4 exhaustivo y K2P-6 extendido',()=>{for(let n=0;n<65536;n++){const w=new K.Writer();w.n(n);const r=new K.Reader(w.bytes());assert(r.n()===n);r.finish();}for(const n of [0,65536,120000,2**32,Number.MAX_SAFE_INTEGER]){const w=new K.Writer().n(n,6),r=new K.Reader(w.bytes());eq(r.n(6),n);r.finish();}return '65.536 naturales + 5 límites extendidos';});
  await record('K4B autónomo y K5B con tratamiento',async()=>{for(const n of [0,1,255,256,65535,65536]){const a=new Uint8Array(n).fill(71),f=await B.seal(a);const p=await B.read(f);assert(B.equal(a,p.body)&&p.end===f.length);}const f=frames[0].slice();f[0]^=1;await rejects(()=>Qipu.K5B.read(f));return '6 tamaños de frontera; T comprometido';});
  await record('Truncamientos de todos los registros',async()=>{let count=0;for(const f of frames){for(let i=0;i<f.length;i++){await rejects(()=>Qipu.K5B.read(f.slice(0,i)));count++;}}return `${count} prefijos incompletos rechazados`;});
  await record('Mutaciones de un bit en venta múltiple',async()=>{const f=frames[19];for(let i=0;i<f.length*8;i++){const g=f.slice();g[i>>3]^=1<<(i&7);await rejects(()=>Qipu.K5B.read(g));}return `${f.length*8} bits alterados, todos rechazados`;});
  await record('Reconstrucción base en IndexedDB',async()=>{await C.replace(db,baseline);eq(await stock(),[17,11,7]);eq((await C.sales(db)).map(s=>s.total),[130000,445000]);eq(await C.resolve(db,0,'B'),1);eq((await C.project(db,0,1)).parameters.stock,11);return '20 registros; stock 17/11/7; ventas $130.000 y $445.000';});
  await record('Rechazos comerciales sin cambios',async()=>{const before=await C.exportBytes(db),m=await C.getMeta(db);for(const e of [[5,0,2,3,1],[7,0,2,[[1,6,1],[1,6,1]]],[7,0,2,[[0,1,1],[2,99,1]]],[7,0,2,[[1,0,1]]],[4,0,2,1,'mal'],[3,0,'B'],[2,0,'stock',2],[6,0,2,1,0],[12,0,2,1,99]])await rejects(()=>append(...e));eq(await stock(),[17,11,7]);eq(await C.getMeta(db),m);assert(B.equal(await C.exportBytes(db),before));return '9 rechazos; log, cursor y stock intactos';});
  await record('Importación inválida revierte toda la transacción',async()=>{const before=await C.exportBytes(db);await rejects(()=>C.replace(db,B.cat(baseline,awaitableInvalid())));function awaitableInvalid(){return Uint8Array.of(0,1,2);}const invalid=await Qipu.Contratos.encode(5,0,2,99,1);await rejects(()=>C.replace(db,B.cat(baseline,invalid)));assert(B.equal(await C.exportBytes(db),before));eq(await stock(),[17,11,7]);return 'Truncamiento y referencia futura; base previa preservada';});
  await record('Recorrido extendido y posición compartida',async()=>{for(const f of frames.slice(20))await C.append(db,f);eq(await stock(),[17,8,9,6]);eq((await C.readVector(db,0,3)).values,[null,'Negro',undefined,undefined]);eq((await C.readVector(db,0,4)).values,[true,false,undefined,undefined]);eq((await C.project(db,1,0)).parameters.nombre,'Ropa');eq(await C.resolve(db,0,'D'),3);eq((await C.sales(db)).map(s=>s.total),[130000,445000,195000]);return '2 tablas, 5 vectores de productos, nulo/ausente, cuarta entidad y líneas repetidas';});
  await record('Replay completo = incremental',async()=>{const before=await C.project(db,0,1);assert(B.equal(await C.exportBytes(db),bytes));await C.replace(db,bytes);eq(await C.project(db,0,1),before);eq(await stock(),[17,8,9,6]);return `${frames.length} registros; mismo estado`});
  await record('Eliminar materializaciones y reconstruir desde log',async()=>{await S.tx(db,[...S.derived,'meta'],'readwrite',async x=>{for(const s of S.derived)await x.clear(s);await x.clear('meta');});eq(await C.tables(db),[]);assert(B.equal(await C.exportBytes(db),bytes));await C.rebuild(db);eq(await stock(),[17,8,9,6]);eq((await C.sales(db)).length,3);eq(await C.resolve(db,0,'B'),1);return 'Tablas, vectores, celdas, índices, ventas y cursor reconstruidos';});
  await record('Persistencia al cerrar y reabrir IndexedDB',async()=>{db.close();db=await S.open(name);eq(await stock(),[17,8,9,6]);eq((await C.getMeta(db)).seq,frames.length);return 'Estado y cursor conservados al reabrir conexión';});
  await record('Dos ventas concurrentes del último stock',async()=>{await append(5,0,2,1,1);const f=await Qipu.Contratos.encode(7,0,2,[[1,1,65000]]);const out=await Promise.allSettled([C.append(db,f),C.append(db,f)]);eq(out.filter(x=>x.status==='fulfilled').length,1);eq((await stock())[1],0);return 'Una aceptada, una rechazada; stock 0';});
  await record('Ventas iguales legítimas no se deduplican por hash',async()=>{await append(5,0,2,1,2);const f=await Qipu.Contratos.encode(7,0,2,[[1,1,65000]]);const n=(await C.sales(db)).length;await C.append(db,f);await C.append(db,f);eq((await stock())[1],0);eq((await C.sales(db)).length,n+2);return 'Dos hechos iguales en posiciones distintas';});
  return {version:'1.0.0',registros:frames.length,bytes:bytes.length,pruebas:results,ok:results.every(x=>x.estado==='OK')};
 }finally{db.close();await S.remove(name);}
 }
 return {run};
})();

/* Kobalt Kernel 10.0.0 — perfil experimental KOB10/1.
   API nueva; no afirma compatibilidad de sobres históricos KOB2 9.0.1.
   Web Crypto nativo. Sin transporte, autoridad, UI ni dependencias. */
(function(root){'use strict';
const Qipu=root.Qipu; const {K2P,K4B,K5B}=Qipu;
const need=(x,m)=>{if(!x)throw Error(m)}, bytes=b=>{need(b instanceof Uint8Array,'Se requieren bytes');return b}, copy=b=>bytes(b).slice(), cat=K4B.cat, equal=K4B.equal, utf8=s=>new TextEncoder().encode(s), text=b=>new TextDecoder('utf-8',{fatal:true}).decode(b), hex=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const unhex=s=>{need(typeof s==='string'&&s.length%2===0&&/^[0-9a-f]*$/i.test(s),'Hex inválido');return Uint8Array.from(s.match(/../g)||[],x=>parseInt(x,16))};
const u32=n=>{need(Number.isSafeInteger(n)&&n>=0&&n<=0xffffffff,'uint32 inválido');let b=new Uint8Array(4);new DataView(b.buffer).setUint32(0,n);return b};
const u64=n=>{need(Number.isSafeInteger(n)&&n>=0,'uint64 inválido');let b=new Uint8Array(8);new DataView(b.buffer).setBigUint64(0,BigInt(n));return b};
const read32=(b,p=0)=>new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(p);
const frame=(...a)=>cat(u32(a.length),...a.flatMap(b=>[u64(bytes(b).length),b]));
function unframe(b){bytes(b);need(b.length>=4,'Frame truncado');let p=4,n=read32(b),out=[];need(n<=Math.floor((b.length-4)/8),'Contador inválido');for(let i=0;i<n;i++){need(p+8<=b.length,'Frame truncado');let k=new DataView(b.buffer,b.byteOffset+p,8).getBigUint64(0);p+=8;need(k<=BigInt(b.length-p),'Átomo truncado');let len=Number(k);out.push(b.slice(p,p+len));p+=len}need(p===b.length,'Bytes sobrantes');return out}
const sha=async b=>new Uint8Array(await crypto.subtle.digest('SHA-256',b));
const id=b=>{need(bytes(b).length===32,'Identificador debe tener 32 bytes');return b};
const clear=()=>({kind:'Clear'}), keyed=k=>({kind:'Keyed',key:copy(id(k))});
function view(v){need(v&&['Clear','Keyed'].includes(v.kind),'View inválida');if(v.kind==='Keyed')id(v.key);return v}
async function derive(v,tag,...atoms){view(v);const b=frame(utf8('KOB10/1'),utf8(v.kind),utf8(tag),...atoms);if(v.kind==='Clear')return sha(b);const k=await crypto.subtle.importKey('raw',v.key,{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',k,b))}
const identity=(v,...a)=>derive(v,'identity',...a), contentId=(v,b)=>derive(v,'content',bytes(b));
const Ops=Object.freeze({EMIT:0,EXPAND:1,FOLLOW:2,TRAJECTORY:3}), names=Object.keys(Ops);
function cell(op,r){need(Number.isInteger(op)&&op>=0&&op<4,'Descriptor desconocido');return {op,ref:copy(id(r))}}
function encode(c){return cat(u32(cell(c.op,c.ref).op),c.ref)}
function decode(b){need(bytes(b).length===36,'Cell debe tener 36 bytes');return cell(read32(b),b.subarray(4))}
function vector(cs){return cat(...cs.map(encode))}
function cells(b){need(bytes(b).length%36===0,'CellVector no múltiplo de 36');let out=[];for(let i=0;i<b.length;i+=36)out.push(decode(b.subarray(i,i+36)));return out}
const name=(v,c)=>derive(v,'name',encode(c)), key=c=>hex(encode(c)), exact=c=>c.op<2;
const isPrefix=(a,b)=>a.length<=b.length&&equal(a,b.subarray(0,a.length));
function commonPrefix(a,b){let i=0;while(i<Math.min(a.length,b.length)&&a[i]===b[i])i++;return a.slice(0,i)}
async function scan(b){bytes(b);let p=0,out=[];while(p<b.length){const r=await K5B.read(b,p);out.push({position:out.length,offset:p,end:r.end,t:r.t,body:r.body,hash:r.hash,raw:b.slice(p,r.end)});p=r.end}return out}
async function validate(v,c,b){bytes(b);cell(c.op,c.ref);if(exact(c))need(equal(await contentId(v,b),c.ref),'ContentId no coincide');if(c.op===1||c.op===2)cells(b);if(c.op===3)await scan(b);return b}
/* Un mismo sobre para los cuatro tratamientos. AES-GCM con nonce aleatorio.
   El compromiso Clear detecta daño, no autentica al escritor. */
const magic=utf8('KOB10'), header=v=>cat(magic,Uint8Array.of(1,v.kind==='Keyed'?1:0));
async function aes(v){return crypto.subtle.importKey('raw',await derive(v,'envelope-key'),{name:'AES-GCM'},false,['encrypt','decrypt'])}
async function seal(v,c,b){await validate(v,c,b);const h=header(v),p=cat(encode(c),b);let env;if(v.kind==='Clear')env=cat(h,p,await derive(v,'envelope-commit',h,p));else{const n=crypto.getRandomValues(new Uint8Array(12));env=cat(h,n,new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:n,additionalData:h,tagLength:128},await aes(v),p)))}return {name:hex(await name(v,c)),envelope:env}}
async function open(v,expected,env){view(v);bytes(env);const h=header(v);need(env.length>=h.length&&equal(env.subarray(0,h.length),h),'Sobre o vista incompatible');let p;if(v.kind==='Clear'){need(env.length>=h.length+36+32,'Sobre truncado');p=env.slice(h.length,-32);need(equal(env.slice(-32),await derive(v,'envelope-commit',h,p)),'Compromiso inválido')}else{need(env.length>=h.length+12+36+16,'Sobre truncado');p=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:env.slice(h.length,h.length+12),additionalData:h,tagLength:128},await aes(v),env.slice(h.length+12)))}const c=decode(p.slice(0,36));need(key(c)===key(expected),'Otra Cell');const b=p.slice(36);await validate(v,c,b);return b}
async function recognize(v,c,candidates){const accepted=[],rejected=[];for(const [i,x] of candidates.entries()){try{accepted.push({index:i,body:await open(v,c,x)})}catch(e){rejected.push({index:i,error:e.message})}}return {accepted,rejected}}
/* Solo candidatos observados y válidos; no constituye autoridad ni actualidad global. */
async function resolve(v,c,candidates){need(Array.isArray(candidates),'Se requiere lista de evidencias');if(!candidates.length)return {kind:'NO_EVIDENCE'};const evidence=await recognize(v,c,candidates);if(!evidence.accepted.length)return {kind:'UNRECOGNIZED',evidence};const a=evidence.accepted.map(x=>x.body);if(exact(c)){need(a.every(x=>equal(a[0],x)),'EXACT_DIVERGENCE');return {kind:'EXACT',body:a[0],evidence}}let max=a.reduce((x,y)=>x.length>=y.length?x:y);if(!a.every(x=>isPrefix(x,max))){let p=a.reduce(commonPrefix);if(c.op===2)p=p.slice(0,p.length-p.length%36);else{const rec=await scan(a[0]);p=p.slice(0,rec.filter(r=>r.end<=p.length).at(-1)?.end||0)}return {kind:'FORK',commonPrefix:p,candidates:a,evidence}}return {kind:max.length?'CHAIN':'EMPTY',body:max,evidence}}
function memory(){const m=new Map();return {async put(n,b){const a=m.get(n)||[];if(!a.some(x=>equal(x,b)))a.push(copy(b));m.set(n,a)},async query(n){return (m.get(n)||[]).map(copy)},size:()=>m.size}}
async function publish(s,v,c,b){const e=await seal(v,c,b);await s.put(e.name,e.envelope);return c}
async function publishExact(s,v,op,b){need(op===0||op===1,'Operador exacto requerido');return publish(s,v,cell(op,await contentId(v,b)),b)}
/* Intérprete único, paso a paso. DFS ordenado. No ejecuta bytes ni contratos.
   Límites, ciclos y hojas vacías son resultados explícitos. Cache de resolución por evaluación. */
function traversal(v,rootCell,query,{maxDepth=64,maxSteps=10000}={}){const pending=[{cell:rootCell,depth:1,ancestors:[]}],trace=[],leaves=[],cache=new Map();let stopped=false;
async function step(){if(!pending.length||stopped)return null;const t=pending.shift(),c=t.cell,k=key(c),event={...t,op:names[c.op],selected:[],cells:[]};trace.push(event);if(trace.length>maxSteps||t.depth>maxDepth){event.status='LIMIT';stopped=true;return event}if(t.ancestors.includes(k)){event.status='CYCLE';return event}try{if(!cache.has(k))cache.set(k,await resolve(v,c,await query(hex(await name(v,c)))));const r=cache.get(k);event.status=r.kind;event.body=r.body;if(!['EXACT','CHAIN','EMPTY'].includes(r.kind))return event;if(c.op===0||c.op===3){event.records=c.op===3?await scan(r.body):undefined;leaves.push(event);return event}event.cells=cells(r.body);if(c.op===2&&!event.cells.length){event.status='NO_CURRENT';return event}event.selected=c.op===2?[event.cells.length-1]:event.cells.map((_,i)=>i);pending.unshift(...event.selected.map(i=>({cell:event.cells[i],depth:t.depth+1,ancestors:[...t.ancestors,k]})));return event}catch(e){event.status='ERROR';event.error=e.message;return event}}
async function run(){while(pending.length&&!stopped)await step();return {trace,leaves,complete:!pending.length&&!stopped&&trace.every(x=>['EXACT','CHAIN','EMPTY'].includes(x.status)),pending}}
return {pending,trace,leaves,step,run,get stopped(){return stopped}}}
/* Prefijo exacto publicado como EMIT: material canónico, no reemplazo de identidad. */
async function cut(v,c,b,n){need(c.op===3,'Se requiere TRAJECTORY');const records=await scan(b);need(Number.isInteger(n)&&n>=0&&n<=records.length,'Corte fuera de rango');const body=b.slice(0,n?records[n-1].end:0);return {body,count:n,commitment:await derive(v,'trajectory-cut',encode(c),u64(n),body),cell:cell(0,await contentId(v,body))}}
/* Combinatoria de rutas: profundidad cuenta operadores. F y X pueden repetirse. */
function paths(d,p=''){need(Number.isInteger(d)&&d>=1&&d<=12,'Profundidad 1..12');return [p+'E',p+'T',...(d>1?[...paths(d-1,p+'F'),...paths(d-1,p+'X')]:[])]}
const letters={E:0,X:1,F:2,T:3};
async function fixture(route){need(/^[FX]*[ET]$/.test(route),'Ruta inválida');const s=memory(),v=clear(),labels=new Map();async function leaf(o,label){const c=o==='E'?await publishExact(s,v,0,utf8(label)):await publish(s,v,cell(3,await identity(v,utf8(label))),cat(await K5B.seal(10,new K2P.Writer().n(0).bytes()),await K5B.seal(11,new K2P.Writer().n(1).bytes())));labels.set(key(c),label);return c}let c=await leaf(route.at(-1),'Hoja elegida '+route);for(let i=route.length-2;i>=0;i--){let label=route.slice(0,i+1)+' · '+route;const a=await leaf('E','Material lateral '+label),b=await leaf('T','Trayectoria lateral '+label);if(route[i]==='X')c=await publishExact(s,v,1,vector([a,c,b]));else c=await publish(s,v,cell(2,await identity(v,utf8(label))),vector([a,b,c]));labels.set(key(c),label)}return {source:s,view:v,root:c,labels}}
root.Kobalt=Object.freeze({version:'10.0.0',profile:'KOB10/1 experimental',Ops,names,Bytes:{utf8,text,hex,unhex,cat,equal,u32,u64},Frame:{frame,unframe},View:{clear,keyed,derive},Derivation:{identity,contentId,name},Cell:{make:cell,encode,decode,key,exact},Sequence:{isPrefix,commonPrefix},CellVector:{encode:vector,decode:cells},ReferenceIndex:{encode:vector,decode:cells},ReferenceHistory:{encode:vector,decode:cells},Trajectory:{scan,cut},Envelope:{seal,open},Recognition:{recognize},Resolution:{resolve},MemorySource:memory,Publication:{publish,publishExact},Explore:traversal,Combinatorics:{paths,fixture},K2P,K4B,K5B,Qipu});
})(globalThis);
/* Ejemplos verificables sobre el kernel real, no una segunda implementación. */
(function(K){'use strict';const {Bytes:B,Cell:C,View:V,Derivation:D,Publication:P,CellVector:CV,Trajectory:T,Envelope:E,Resolution:R,Combinatorics:M,Ops:O,Qipu:Q}=K;
const assert=(a,m='Aserción fallida')=>{if(!a)throw Error(m)}, eq=(a,b)=>assert(JSON.stringify(a)===JSON.stringify(b),JSON.stringify(a)+' ≠ '+JSON.stringify(b));async function rejects(f){let ok=false;try{await f()}catch{ok=true}assert(ok,'Se esperaba rechazo')}
async function tests(onResult=()=>{}){const results=[];async function test(name,fn){let r={name};try{r.detail=await fn();r.ok=true}catch(e){r.ok=false;r.detail=e.message}results.push(r);onResult(r)}
const v=V.clear(),s=K.MemorySource();const pub=(op,b)=>P.publishExact(s,v,op,b),long=async(op,label,b)=>P.publish(s,v,C.make(op,await D.identity(v,B.utf8(label))),b),query=async c=>s.query(B.hex(await D.name(v,c)));
await test('Frame: fronteras y roundtrip',async()=>{let a=B.utf8('ab'),b=B.utf8('c');assert(!B.equal(K.Frame.frame(a,b),K.Frame.frame(B.utf8('a'),B.utf8('bc'))));eq(K.Frame.unframe(K.Frame.frame(a,b)).map(B.text),['ab','c']);await rejects(()=>K.Frame.unframe(Uint8Array.of(0)));return 'Átomos distintos conservan fronteras'});
await test('Cell y derivación: 4 tratamientos, 36 bytes',async()=>{let i=await D.identity(v,B.utf8('x'));let ns=[];for(let op=0;op<4;op++){let c=C.make(op,i);eq(C.encode(c).length,36);assert(C.key(c)===C.key(C.decode(C.encode(c))));ns.push(B.hex(await D.name(v,c)))}eq(new Set(ns).size,4);await rejects(()=>C.decode(B.cat(B.u32(4),i)));return '4 nombres distintos, 32 bytes cada uno'});
await test('EMIT: exactitud, daño y ausencia',async()=>{let c=await pub(0,B.utf8('foto'));let a=await query(c);eq((await R.resolve(v,c,a)).kind,'EXACT');eq((await R.resolve(v,c,[])).kind,'NO_EVIDENCE');let g=a[0].slice();g[40]^=1;eq((await R.resolve(v,c,[g])).kind,'UNRECOGNIZED');await rejects(()=>E.seal(v,c,B.utf8('otra')));return 'Corrupción y contenido ajeno rechazados'});
await test('Clear y Keyed: protección y nombres separados',async()=>{let k=V.keyed(new Uint8Array(32).fill(7)),bad=V.keyed(new Uint8Array(32).fill(8));let b=B.utf8('privado'),c=C.make(0,await D.contentId(k,b));let e=await E.seal(k,c,b);assert(B.equal(await E.open(k,c,e.envelope),b));await rejects(()=>E.open(bad,c,e.envelope));await rejects(()=>E.open(v,c,e.envelope));assert(!B.equal(await D.name(k,c),await D.name(v,c)));let g=e.envelope.slice();g[g.length-1]^=1;await rejects(()=>E.open(k,c,g));return 'AES-GCM real; clave incorrecta y daño rechazados'});
await test('Combinatoria exhaustiva de rutas de profundidad 1–4',async()=>{let total=0;for(let d=1;d<=4;d++){let paths=M.paths(d);eq(paths.length,2*(2**d-1));eq(new Set(paths).size,paths.length);for(let p of paths){let f=await M.fixture(p),r=await K.Explore(f.view,f.root,f.source.query,{maxDepth:d}).run();assert(r.complete,p);assert(r.leaves.every(x=>x.cell.op===0||x.cell.op===3));assert(r.leaves.some(x=>f.labels.get(C.key(x.cell))==='Hoja elegida '+p));eq(r.leaves.length,1+2*[...p].filter(x=>x==='X').length);eq(Math.max(...r.trace.map(x=>x.depth)),p.length);total++}}return `${total} ejecuciones (2 + 6 + 14 + 30); 30 rutas distintas con d=4`});
await test('FOLLOW: admite las cuatro celdas, solo sigue la última',async()=>{let old=await pub(0,B.utf8('antigua')),x=await pub(1,CV.encode([old])),t=await long(3,'t',await Q.K5B.seal(99,B.utf8('r'))),f=await long(2,'f',CV.encode([old,x,t]));let f2=await long(2,'f2',CV.encode([old,f]));let r=await K.Explore(v,f2,s.query).run();eq(r.trace.map(x=>x.op),['FOLLOW','FOLLOW','TRAJECTORY']);eq(r.trace[1].selected,[2]);return 'Históricas no recorridas; FOLLOW → FOLLOW → TRAJECTORY'});
await test('EXPAND: cuatro hijos, orden y multiplicidad',async()=>{let a=await pub(0,B.utf8('A')),t=await long(3,'tx',new Uint8Array()),f=await long(2,'fx',CV.encode([a])),x=await pub(1,CV.encode([a])),root=await pub(1,CV.encode([a,x,f,t,a]));let r=await K.Explore(v,root,s.query).run();assert(r.complete);eq(r.leaves.map(x=>x.op),['EMIT','EMIT','EMIT','TRAJECTORY','EMIT']);eq(r.trace[0].selected,[0,1,2,3,4]);return 'Recorre las cuatro posibilidades; conserva referencias repetidas'});
await test('FOLLOW y TRAJECTORY: EMPTY, CHAIN, FORK',async()=>{let a=await pub(0,B.utf8('A')),b=await pub(0,B.utf8('B')),f=await long(2,'fork',new Uint8Array());eq((await R.resolve(v,f,await query(f))).kind,'EMPTY');await P.publish(s,v,f,CV.encode([a]));await P.publish(s,v,f,CV.encode([a,b]));eq((await R.resolve(v,f,await query(f))).kind,'CHAIN');await P.publish(s,v,f,CV.encode([b,b,b]));eq((await R.resolve(v,f,await query(f))).kind,'FORK');let r=await Q.K5B.seal(1,B.utf8('r')),y=await Q.K5B.seal(2,B.utf8('y')),z=await Q.K5B.seal(2,B.utf8('z')),t=await long(3,'forkT',r);await P.publish(s,v,t,B.cat(r,y));eq((await R.resolve(v,t,await query(t))).kind,'CHAIN');await P.publish(s,v,t,B.cat(r,z,y));let result=await R.resolve(v,t,await query(t));eq(result.kind,'FORK');assert(B.equal(result.commonPrefix,r));return 'Prefijo común en frontera de registro; no elige por longitud'});
await test('Ciclos, límites y trayectoria vacía',async()=>{let f=C.make(2,await D.identity(v,B.utf8('cycle')));await P.publish(s,v,f,CV.encode([f]));let r=await K.Explore(v,f,s.query).run();eq(r.trace.at(-1).status,'CYCLE');assert(!r.complete);let t=await long(3,'empty',new Uint8Array());r=await K.Explore(v,t,s.query).run();assert(r.complete);eq(r.leaves[0].records.length,0);let h=await long(2,'emptyF',new Uint8Array());r=await K.Explore(v,h,s.query).run();eq(r.trace[0].status,'NO_CURRENT');let z=await M.fixture('FFXE');r=await K.Explore(z.view,z.root,z.source.query,{maxDepth:2}).run();assert(!r.complete);eq(r.trace.at(-1).status,'LIMIT');return 'No confunde vacío, ciclo ni límite con éxito'});
await test('Cortes exactos, extensión y posición K5B',async()=>{let b=await Q.Ejemplos.binary(),t=await long(3,'commerce',b),rec=await T.scan(b);eq(rec.length,37);eq(rec[36].position,36);let c=await T.cut(v,t,b,20);await P.publish(s,v,c.cell,c.body);eq((await T.scan((await R.resolve(v,c.cell,await query(c.cell))).body)).length,20);assert(K.Sequence.isPrefix(c.body,b));await rejects(()=>T.scan(b.slice(0,-1)));return `${rec.length} registros, ${b.length} bytes; corte de 20 verificable`});
await test('Corte TRAJECTORY privado por vista',async()=>{let k=V.keyed(new Uint8Array(32).fill(5)),t=C.make(3,await D.identity(k,B.utf8('secreto'))),b=await Q.K5B.seal(99,B.utf8('dato'));let e=await E.seal(k,t,b);assert(B.equal(await E.open(k,t,e.envelope),b));await rejects(()=>E.open(V.keyed(new Uint8Array(32)),t,e.envelope));return 'Protección independiente del tipo de registro'});
await test('Qipu: constitución real desde hoja TRAJECTORY',async()=>{let b=await Q.Ejemplos.binary(),t=await long(3,'qipu-real',b),r=await K.Explore(v,t,s.query).run();assert(r.complete);let name='k10-demo-'+Date.now()+Math.random(),db=await Q.Storage.openMemory(name);try{await Q.Continuidad.replace(db,r.leaves[0].body);eq((await Q.Continuidad.readVector(db,0,2)).values,[17,8,9,6]);eq(await Q.Continuidad.resolve(db,0,'B'),1);let old=await Q.Continuidad.exportBytes(db);await rejects(async()=>Q.Continuidad.append(db,await Q.Contratos.encode(7,0,2,[[1,100,1]])));assert(B.equal(old,await Q.Continuidad.exportBytes(db)));return 'Tabla, vectores, ventas; rechazo atómico simulado, stock 17/8/9/6'}finally{db.close();await Q.Storage.removeMemory(name)}});
return results}
/* Mantener las pruebas junto con su utilidad. */
globalThis.KobaltLab=Object.freeze({tests});})(Kobalt);
