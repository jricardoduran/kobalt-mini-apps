<?php
// Kobalt Apps simple v0.3.5 — one file. PHP 8.1+, zlib, cURL or allow_url_fopen.
declare(strict_types=1);
const PREFIX = "<?php http_response_code(404); exit; __halt_compiler(); ?>\n";
function cfg(string $key): mixed {
    return ['max_entries'=>50000, 'max_object_bytes'=>8*1024*1024,
        'max_zip_bytes'=>32*1024*1024, 'max_pack_expanded'=>48*1024*1024, 'max_http_bytes'=>24*1024*1024,
        'http_timeout'=>25, 'github_tokens'=>['private'=>getenv('KOBALT_GITHUB_TOKEN') ?: '']][$key] ?? null;
}
function fail(string $message): never { throw new RuntimeException($message); }
function readLocal(string $name): ?string {
    $path=__DIR__.'/kobalt-'.$name.'.php';
    if(!is_file($path)) return null;
    $s=file_get_contents($path);
    if($s===false || !str_starts_with($s,PREFIX)) fail('Dato local inválido.');
    return substr($s,strlen(PREFIX));
}
function writeLocal(string $name,string $bytes): void {
    $path=__DIR__.'/kobalt-'.$name.'.php';
    $tmp=__DIR__.'/kobalt-temp-'.bin2hex(random_bytes(12)).'.php';
    try {
        $data=PREFIX.$bytes;
        if(file_put_contents($tmp,$data,LOCK_EX)!==strlen($data)) fail('No se pudo escribir en esta carpeta.');
        @chmod($tmp,0600);
        if(!rename($tmp,$path)) fail('No se pudo guardar el estado.');
    } finally { if(is_file($tmp)) @unlink($tmp); }
}
function state(): array { return json_decode(readLocal('state') ?? '{"auth":null,"repos":[]}',true,512,JSON_THROW_ON_ERROR); }
function saveState(array $s): void { writeLocal('state',json_encode($s,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)); }
function lock(callable $fn): mixed {
    $f=fopen(__DIR__.'/kobalt-lock.php','c+');
    if(!$f || !flock($f,LOCK_EX)) fail('No se pudo bloquear el estado.');
    try { if(fstat($f)['size']===0) fwrite($f,PREFIX); return $fn(); }
    finally { flock($f,LOCK_UN); fclose($f); }
}
function h(string $s): string { return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function oid(string $s): bool { return (bool)preg_match('/\A[0-9a-f]{40}\z/D',$s); }
function gitOid(string $type,string $bytes): string { return sha1($type.' '.strlen($bytes)."\0".$bytes); }
function safePath(string $p): bool { return $p!=='' && strlen($p)<=4096 && preg_match('//u',$p)===1 && !preg_match('/[\x00-\x1f\x7f\\\\]/',$p) && !array_intersect(explode('/',$p),['','.','..']); }
function htmlPath(string $p): bool { return safePath($p) && (bool)preg_match('/\.html?$/iD',$p); }
function zipPath(string $p): bool { return safePath($p) && (bool)preg_match('/\.zip$/iD',$p); }
function catalogPath(string $p): bool { return htmlPath($p)||zipPath($p); }
function fileLimit(string $p): int { return cfg(zipPath($p)?'max_zip_bytes':'max_object_bytes'); }
function pathUrl(string $p): string { return implode('/',array_map('rawurlencode',explode('/',$p))); }
function sourceUrl(string $url): string { $url=trim($url); if (!preg_match('~\Ahttps://github\.com/([A-Za-z0-9][A-Za-z0-9-]{0,38})/([A-Za-z0-9_.-]{1,100})/?\z~iD',$url,$m)) fail('Usa https://github.com/propietario/repositorio.'); $repo=preg_replace('/\.git$/i','',$m[2]); if ($repo==='' || $repo==='.' || $repo==='..') fail('Repositorio inválido.'); return 'https://github.com/'.$m[1].'/'.$repo; }
function validBranch(string $b): bool { return $b==='' || (strlen($b)<=200 && preg_match('~\A[A-Za-z0-9_./-]+\z~D',$b) && !str_contains($b,'..') && !str_contains($b,'//') && !str_starts_with($b,'/') && !str_ends_with($b,'/') && !str_ends_with($b,'.') && !preg_match('~(?:^|/)\.|\.lock(?:/|$)~',$b)); }
function httpRequest(string $url,array $headers=[],?string $body=null,?int $max=null): string {
    $max ??= cfg('max_http_bytes'); $u=parse_url($url);
    if (($u['scheme']??'')!=='https' || !in_array($u['host']??'', ['github.com','api.github.com','raw.githubusercontent.com'],true) || isset($u['user'])||isset($u['port'])) fail('Destino HTTP no permitido.');
    $headers=array_merge(['User-Agent: KobaltApps/0.1','Accept-Encoding: identity'],$headers);
    if(function_exists('curl_init')) {
        $c=curl_init($url); $out=''; $overflow=false;
        curl_setopt_array($c,[CURLOPT_HTTPHEADER=>$headers,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>cfg('http_timeout'),CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_WRITEFUNCTION=>function($c,$chunk)use(&$out,&$overflow,$max){if(strlen($out)+strlen($chunk)>$max){$overflow=true;return 0;} $out.=$chunk;return strlen($chunk);}]);
        if($body!==null){curl_setopt($c,CURLOPT_POST,true);curl_setopt($c,CURLOPT_POSTFIELDS,$body);} $ok=curl_exec($c);$status=curl_getinfo($c,CURLINFO_RESPONSE_CODE);curl_close($c);
        if($overflow) fail('Respuesta remota supera el límite configurado.'); if($ok===false) fail('No se pudo conectar con GitHub.');
    } else {
        $ctx=stream_context_create(['http'=>['method'=>$body===null?'GET':'POST','header'=>implode("\r\n",$headers),'content'=>$body??'','timeout'=>cfg('http_timeout'),'ignore_errors'=>true,'follow_location'=>0,'protocol_version'=>1.1], 'ssl'=>['verify_peer'=>true,'verify_peer_name'=>true]]);
        $f=@fopen($url,'rb',false,$ctx); if(!$f) fail('No se pudo conectar con GitHub.'); try { $meta=stream_get_meta_data($f);$status=0;foreach($meta['wrapper_data']??[] as $line)if(preg_match('~^HTTP/\S+ (\d+)~',$line,$m))$status=(int)$m[1];$out='';$start=microtime(true);while(!feof($f)){ $chunk=fread($f,8192);if($chunk===false||stream_get_meta_data($f)['timed_out']||microtime(true)-$start>cfg('http_timeout'))fail('Tiempo de espera remoto agotado.');$out.=$chunk;if(strlen($out)>$max)fail('Respuesta remota supera el límite configurado.');}}finally{fclose($f);}
    }
    if($status!==200) fail('GitHub respondió HTTP '.$status.'. Comprueba URL, permisos o límites.'); return $out;
}

// Git Smart HTTP: pkt-line, pack, deltas, árboles y objetos.
function pkt(string $s): string { return sprintf('%04x',strlen($s)+4).$s; }
function packets(string $s): Generator { $p=0;$n=strlen($s);while($p<$n){if($p+4>$n||!ctype_xdigit(substr($s,$p,4)))fail('Respuesta pkt-line inválida.');$l=hexdec(substr($s,$p,4));$p+=4;if($l<=2){yield $l;continue;}if($l<4||$p+$l-4>$n)fail('Paquete Git incompleto.');yield substr($s,$p,$l-4);$p+=$l-4;} }
function byteAt(string $s,int &$p): int { if($p>=strlen($s))fail('Objeto Git incompleto.');return ord($s[$p++]); }
function deltaInt(string $s,int &$p): int { $v=0;$shift=0;do{$b=byteAt($s,$p);$v|=($b&127)<<$shift;$shift+=7;if($shift>35)fail('Tamaño delta inválido.');}while($b&128);return $v; }
function applyDelta(string $base,string $d): string { $p=0;$src=deltaInt($d,$p);$dest=deltaInt($d,$p);if($src!==strlen($base)||$dest>cfg('max_object_bytes'))fail('Tamaño delta no válido.');$out='';while($p<strlen($d)){ $op=byteAt($d,$p);if($op&128){$off=0;$len=0;for($i=0;$i<4;$i++)if($op&(1<<$i))$off|=byteAt($d,$p)<<(8*$i);for($i=0;$i<3;$i++)if($op&(1<<($i+4)))$len|=byteAt($d,$p)<<(8*$i);if(!$len)$len=65536;if($off+$len>strlen($base)||strlen($out)+$len>$dest)fail('Copia delta fuera de límites.');$out.=substr($base,$off,$len);}else{if(!$op||$p+$op>strlen($d)||strlen($out)+$op>$dest)fail('Literal delta inválido.');$out.=substr($d,$p,$op);$p+=$op;}}if(strlen($out)!==$dest)fail('Delta incompleto.');return $out; }
function unpackGit(string $pack): array {
    $end=strlen($pack)-20;if($end<12||substr($pack,0,4)!=='PACK'||!hash_equals(substr($pack,$end),sha1(substr($pack,0,$end),true)))fail('Checksum del paquete Git inválido.');
    $head=unpack('Nversion/Ncount',substr($pack,4,8));if(!in_array($head['version'],[2,3],true)||$head['count']>cfg('max_entries'))fail('Formato o cantidad de objetos Git no admitidos.');
    $p=12;$byOid=[];$offsets=[];$pending=[];$total=0;$types=[1=>'commit',2=>'tree',3=>'blob',4=>'tag'];
    $register=function($off,$type,$bytes)use(&$byOid,&$offsets,&$total){$total+=strlen($bytes);if($total>cfg('max_pack_expanded'))fail('Paquete expandido supera el límite.');$id=gitOid($type,$bytes);$byOid[$id]=[$type,$bytes];$offsets[$off]=$id;};
    for($i=0;$i<$head['count'];$i++){
        $off=$p;$b=byteAt($pack,$p);$type=($b>>4)&7;$size=$b&15;$shift=4;while($b&128){$b=byteAt($pack,$p);$size|=($b&127)<<$shift;$shift+=7;if($shift>35)fail('Objeto Git demasiado grande.');}if($size>cfg('max_object_bytes'))fail('Objeto Git supera el límite.');
        $ref=null;if($type===6){$b=byteAt($pack,$p);$dist=$b&127;$n=0;while($b&128){$b=byteAt($pack,$p);$dist=(($dist+1)<<7)|($b&127);if(++$n>6)fail('Offset delta inválido.');}$ref=$off-$dist;if($ref<12||$ref>=$off)fail('Base delta inválida.');}elseif($type===7){if($p+20>$end)fail('Delta truncado.');$ref=bin2hex(substr($pack,$p,20));$p+=20;}elseif(!isset($types[$type]))fail('Tipo de objeto Git no admitido.');
        $z=inflate_init(ZLIB_ENCODING_DEFLATE);$out='';while(true){if($p>=$end)fail('Flujo zlib truncado.');$chunk=substr($pack,$p,min(4096,$end-$p));$before=inflate_get_read_len($z);$decoded=@inflate_add($z,$chunk,ZLIB_SYNC_FLUSH);if($decoded===false)fail('Flujo zlib inválido.');$used=inflate_get_read_len($z)-$before;if($used<=0)fail('Flujo zlib sin progreso.');$p+=$used;$out.=$decoded;if(strlen($out)>$size)fail('Objeto expandido excede el tamaño anunciado.');if(inflate_get_status($z)===ZLIB_STREAM_END)break;}if(strlen($out)!==$size)fail('Tamaño de objeto Git inválido.');
        if(isset($types[$type]))$register($off,$types[$type],$out);else{$base=$type===6?($offsets[$ref]??null):$ref;if($base!==null&&isset($byOid[$base])){$v=$byOid[$base];$register($off,$v[0],applyDelta($v[1],$out));}else{$pending[]=[$off,$type,$ref,$out];$total+=strlen($out);if($total>cfg('max_pack_expanded'))fail('Deltas pendientes exceden el límite.');}}
    }if($p!==$end)fail('Longitud de paquete Git inválida.');
    while($pending){$next=[];foreach($pending as [$off,$type,$ref,$d]){$base=$type===6?($offsets[$ref]??null):$ref;if($base===null||!isset($byOid[$base])){$next[]=[$off,$type,$ref,$d];continue;}$v=$byOid[$base];$total-=strlen($d);$register($off,$v[0],applyDelta($v[1],$d));}if(count($next)===count($pending))fail('Faltan bases delta; paquete delgado no admitido.');$pending=$next;}
    return $byOid;
}
function packFromResponse(string $s): string { $pack='';$in=false;foreach(packets($s) as $p){if(is_int($p))continue;if(str_starts_with($p,'ERR '))fail('Git rechazó la consulta.');if(!$in){if(trim($p)==='packfile')$in=true;continue;}if($p==='')fail('Sideband vacío.');$ch=ord($p[0]);if($ch===1)$pack.=substr($p,1);elseif($ch===3)fail('Git informó un error durante fetch.');elseif($ch!==2)fail('Canal Git inesperado.');}if(!$in||$pack==='')fail('Git no devolvió un paquete.');return $pack; }
function treeIndex(array $objects,string $commit,string $prefix=''): array {
    $c=$objects[$commit]??null;if(!$c||$c[0]!=='commit'||!preg_match('/\Atree ([a-f0-9]{40})\n/',$c[1],$m))fail('No se recibió el commit esperado.');$root=$m[1];$files=[];$trees=[];$seen=0;
    $walk=function(string $hash,string $dir,int $depth)use(&$walk,&$files,&$trees,&$seen,$objects,$prefix){if($depth>128)fail('Árbol demasiado profundo.');$obj=$objects[$hash]??null;if(!$obj||$obj[0]!=='tree')fail('Falta un árbol requerido.');$trees[$dir]=$hash;$s=$obj[1];$p=0;while($p<strlen($s)){if(++$seen>cfg('max_entries'))fail('Demasiadas entradas en el árbol.');$space=strpos($s,' ',$p);$nul=$space===false?false:strpos($s,"\0",$space+1);if($space===false||$nul===false||$nul+21>strlen($s))fail('Árbol Git inválido.');$mode=substr($s,$p,$space-$p);$name=substr($s,$space+1,$nul-$space-1);$id=bin2hex(substr($s,$nul+1,20));$p=$nul+21;$path=$dir===''?$name:$dir.'/'.$name;if(str_contains($name,'/')||!safePath($path))continue;if($mode==='40000'||$mode==='040000'){if($prefix===''||$path===$prefix||str_starts_with($path,$prefix.'/')||str_starts_with($prefix,$path.'/'))$walk($id,$path,$depth+1);}elseif(in_array($mode,['100644','100755'],true)&&catalogPath($path)&&($prefix===''||str_starts_with($path,$prefix.'/')))$files[$path]=$id;}};
    $walk($root,'',0);if($prefix!==''&&!isset($trees[$prefix]))fail('La carpeta configurada no existe en el commit.');return ['root'=>$root,'trees'=>$trees,'files'=>$files];
}
class GitHttp {
    private array $caps=[];
    public function __construct(private array $r){}
    private function call(string $cmd,array $args): string { $body=pkt('command='.$cmd."\n");if(isset($this->caps['object-format']))$body.=pkt("object-format=sha1\n");$body.='0001';foreach($args as $a)$body.=pkt($a."\n");$body.='0000';return httpRequest($this->r['url'].'.git/git-upload-pack',['Git-Protocol: version=2','Content-Type: application/x-git-upload-pack-request','Accept: application/x-git-upload-pack-result'],$body); }
    public function state(): array { $s=httpRequest($this->r['url'].'.git/info/refs?service=git-upload-pack',['Git-Protocol: version=2','Accept: application/x-git-upload-pack-advertisement']);$v=false;foreach(packets($s) as $p){if(!is_string($p))continue;$p=trim($p);if($p==='version 2'){$v=true;continue;}if(!$v)continue;$kv=explode('=',$p,2);$this->caps[$kv[0]]=$kv[1]??'';}if(!$v||!isset($this->caps['ls-refs'],$this->caps['fetch'])||($this->caps['object-format']??'sha1')!=='sha1')fail('El servidor no ofrece Git HTTP v2 SHA-1.');$branch=$this->r['branch'];$ref=$branch===''?'HEAD':'refs/heads/'.$branch;$res=$this->call('ls-refs',['symrefs','ref-prefix '.$ref]);foreach(packets($res) as $p){if(!is_string($p))continue;$parts=explode(' ',trim($p));if(($parts[1]??'')!==$ref||!oid($parts[0]))continue;if($branch===''){foreach($parts as $part)if(str_starts_with($part,'symref-target:refs/heads/'))$branch=substr($part,strlen('symref-target:refs/heads/'));}return ['commit'=>$parts[0],'branch'=>$branch?:'HEAD'];}fail('Rama no encontrada o repositorio vacío.'); }
    public function index(string $commit): array { $features=explode(' ',$this->caps['fetch']??'');if(!in_array('filter',$features,true)||!in_array('shallow',$features,true))fail('Git no anuncia soporte de filtro y fetch superficial. No se descargará el repositorio completo.');$s=$this->call('fetch',['no-progress','ofs-delta','want '.$commit,'deepen 1','filter blob:none','done']);return treeIndex(unpackGit(packFromResponse($s)),$commit,$this->r['path']); }
    public function bytes(string $commit,string $path,string $hash): string { $slug=substr($this->r['url'],strlen('https://github.com/'));return httpRequest('https://raw.githubusercontent.com/'.$slug.'/'.$commit.'/'.pathUrl($path),[],null,fileLimit($path)); }
}
class GitApi {
    public function __construct(private array $r){}
    private function get(string $path,?int $max=null): array { $slug=substr($this->r['url'],strlen('https://github.com/'));$token=cfg('github_tokens')[$this->r['credential']]??'';if(!is_string($token)||$token===''||preg_match('/[\r\n]/',$token))fail('Credencial GitHub no configurada.');$s=httpRequest('https://api.github.com/repos/'.$slug.$path,['Authorization: Bearer '.$token,'Accept: application/vnd.github+json','X-GitHub-Api-Version: 2022-11-28'],null,$max);return json_decode($s,true,512,JSON_THROW_ON_ERROR); }
    public function state(): array { $branch=$this->r['branch'];if($branch==='')$branch=$this->get('')['default_branch']??'';if($branch==='')fail('Rama no disponible.');$j=$this->get('/commits/'.rawurlencode($branch));$id=$j['sha']??'';if(!oid($id))fail('Commit API inválido.');return ['commit'=>$id,'branch'=>$branch]; }
    public function index(string $commit): array { $root=$this->get('/git/commits/'.$commit)['tree']['sha']??'';if(!oid($root))fail('Árbol raíz inválido.');$files=[];$trees=[''=>$root];$j=$this->get('/git/trees/'.$root.'?recursive=1');$count=0;$prefix=$this->r['path'];$consume=function(array $e,string $p)use(&$files,&$trees,&$count,$prefix){if(++$count>cfg('max_entries'))fail('Demasiadas entradas.');$hash=$e['sha']??'';if(!safePath($p)||!oid($hash))return;if(($e['type']??'')==='tree')$trees[$p]=$hash;elseif(($e['type']??'')==='blob'&&in_array($e['mode']??'',['100644','100755'],true)&&catalogPath($p)&&($prefix===''||str_starts_with($p,$prefix.'/')))$files[$p]=$hash;};if(!empty($j['truncated'])){$walk=function($id,$dir,$depth)use(&$walk,$consume,$prefix){if($depth>128)fail('Árbol demasiado profundo.');$a=$this->get('/git/trees/'.$id);if(!empty($a['truncated'])||!isset($a['tree']))fail('Árbol API incompleto.');foreach($a['tree'] as $e){$p=($dir===''?'':$dir.'/').$e['path'];$consume($e,$p);if(($e['type']??'')==='tree'&&oid($e['sha'])&&safePath($p)&&($prefix===''||$p===$prefix||str_starts_with($p,$prefix.'/')||str_starts_with($prefix,$p.'/')))$walk($e['sha'],$p,$depth+1);}};$walk($root,'',0);}else{if(!isset($j['tree']))fail('Árbol API incompleto.');foreach($j['tree'] as $e)$consume($e,$e['path']);}if($prefix!==''&&!isset($trees[$prefix]))fail('Carpeta no encontrada.');return compact('root','trees','files'); }
    public function bytes(string $commit,string $path,string $hash): string { $limit=fileLimit($path);$j=$this->get('/git/blobs/'.$hash,(int)ceil($limit*1.4)+65536);if(($j['encoding']??'')!=='base64'||($j['size']??PHP_INT_MAX)>$limit)fail('Blob API no admitido.');$b=base64_decode($j['content']??'',true);if($b===false)fail('Blob API inválido.');return $b; }
}
function adapter(array $r): GitHttp|GitApi { return $r['adapter']==='github_api'?new GitApi($r):new GitHttp($r); }

// Modelo: una posición por fuente; paths[i] y hashes[i] describen una aplicación.
function derive(string $body,string $key): string { return hash_hmac('sha256',$body,$key); }
function repoAt(array $s,int $id,bool $admin): array {
    $r=$s['repos'][$id]??null;
    if(!$r || (!$r['public'] && !$admin)) fail('Repositorio no disponible.');
    return $r;
}
function refresh(int $id,bool $admin,bool $force): array {
    return lock(function()use($id,$admin,$force){
        $s=state(); $r=repoAt($s,$id,$admin); $c=$r['cache']??[];
        if(time()-($r['attempt']??0)<($force?10:60)) return $r;
        $r['attempt']=time();
        try {
            $a=adapter($r); $remote=$a->state();
            if(($c['commit']??null)!==$remote['commit']||!isset($c['folders'])||($c['format']??0)!==2) {
                $fresh=$a->index($remote['commit']);
                $paths=$c['paths']??[]; $map=array_flip($paths); $hashes=[];
                foreach($paths as $p) $hashes[]=$fresh['files'][$p]??null;
                foreach($fresh['files'] as $p=>$v) if(!isset($map[$p])) { $paths[]=$p; $hashes[]=$v; }
                $prefix=$r['path']; $folders=[];
                foreach(array_keys($fresh['trees']) as $dir) {
                    $dir=(string)$dir;
                    if($prefix===''||$dir===$prefix||str_starts_with($dir,$prefix.'/'))$folders[]=$dir;
                }
                $r['cache']=['format'=>2,'commit'=>$remote['commit'],'root'=>$fresh['root'],'paths'=>$paths,'hashes'=>$hashes,'folders'=>$folders];
            }
            $r['checked']=time(); $r['error']=null;
        } catch(Throwable $e) { $r['error']=$e->getMessage(); }
        $s['repos'][$id]=$r; saveState($s); return $r;
    });
}
// Los blobs son archivos originales, sin cabecera ni envoltura PHP.
// Públicos: junto a index.php. Privados: fuera del directorio web.
// El modo de solo consulta permite migrar cachés v0.3.2 sin crear carpetas.
function blobDir(bool $create=true): ?string {
    $root=(!empty($_SERVER['DOCUMENT_ROOT'])?@realpath($_SERVER['DOCUMENT_ROOT']):false) ?: __DIR__;
    $root=rtrim($root,DIRECTORY_SEPARATOR) ?: DIRECTORY_SEPARATOR;
    $name='kobalt-blobs-'.substr(hash('sha256',__DIR__),0,20);
    $override=getenv('KOBALT_BLOB_DIR');
    $candidates=$override?[$override]:[dirname($root).'/'.$name,sys_get_temp_dir().'/'.$name];
    foreach($candidates as $dir) {
        if(!@is_dir($dir)&&(!$create||(!@mkdir($dir,0700,true)&&!@is_dir($dir))))continue;
        $real=@realpath($dir);
        if($real===false||$root===DIRECTORY_SEPARATOR||$real===$root||str_starts_with($real,$root.DIRECTORY_SEPARATOR)||!@is_writable($real))continue;
        $mode=@fileperms($real);
        if($mode===false||(($mode&0077)!==0&&!@chmod($real,0700)))continue;
        return $real;
    }
    if(!$create)return null;
    fail('No hay una carpeta privada para los blobs. Configura KOBALT_BLOB_DIR fuera del directorio web y con permisos de escritura.');
}
function writeBlob(string $path,string $bytes,bool $public): void {
    $tmp=tempnam(dirname($path),'.tmp-');
    if($tmp===false)fail('No se pudo preparar el blob local.');
    try {
        if(file_put_contents($tmp,$bytes)!==strlen($bytes)||!chmod($tmp,$public?0644:0600)||!rename($tmp,$path))fail('No se pudo guardar el blob original.');
    } finally { if(is_file($tmp))@unlink($tmp); }
}
function getFile(int $id,int $pos,bool $admin,?string &$filename=null,?string &$publicFile=null,bool $download=false): string {
    $r=repoAt(state(),$id,$admin); $c=$r['cache']??[];
    $p=$c['paths'][$pos]??null; $v=$c['hashes'][$pos]??null;
    if(!is_string($p)||!is_string($v)||!catalogPath($p)||!oid($v)) fail('Archivo no disponible.');
    if(!$download&&zipPath($p))fail('Los ZIP solo se pueden descargar.');
    $filename=basename($p); $public=(bool)$r['public'];
    $name='blob-'.($public?'public-':'private-').$v;
    $ext=pathinfo($filename,PATHINFO_EXTENSION);
    $dir=$public?__DIR__:blobDir();
    $localName=($public?'kobalt-':'').$name.'.'.$ext;
    $path=$dir.'/'.$localName; $publicFile=$public?$localName:null;
    $b=is_file($path)&&filesize($path)<=fileLimit($p)?file_get_contents($path):false;
    if($b!==false&&hash_equals($v,gitOid('blob',$b)))return $b;
    // Compatibilidad v0.3.1: recuperar los bytes de la envoltura PHP.
    $old=__DIR__.'/kobalt-'.$name.'.php'; $b=null;
    if(is_file($old)) {
        try { $candidate=readLocal($name); if($candidate!==null&&hash_equals($v,gitOid('blob',$candidate)))$b=$candidate; } catch(Throwable $e) { }
    }
    // Reutilizar otro sufijo HTML o migrar la caché externa v0.3.2.
    if($b===null) {
        $patterns=[$dir.'/'.($public?'kobalt-':'').$name.'.*'];
        if($public&&($legacy=blobDir(false))!==null)$patterns[]=$legacy.'/'.$name.'.*';
        foreach($patterns as $pattern) {
            foreach(glob($pattern)?:[] as $other) {
                if($other===$path||!preg_match('/\.(?:html?|zip)$/iD',$other))continue;
                $candidate=file_get_contents($other);
                if($candidate!==false&&hash_equals($v,gitOid('blob',$candidate))){$b=$candidate;break 2;}
            }
        }
    }
    if($b===null)$b=adapter($r)->bytes($c['commit'],$p,$v);
    if(strlen($b)>fileLimit($p))fail('El archivo supera el límite de descarga configurado.');
    if(!hash_equals($v,gitOid('blob',$b))) fail('El contenido no coincide con el hash Git.');
    writeBlob($path,$b,$public);
    if(is_file($old))@unlink($old);
    return $b;
}
function mono(string $p): string {
    $w=preg_split('/[^\p{L}\p{N}]+/u',preg_replace('/\.html?$/iD','',basename($p)),-1,PREG_SPLIT_NO_EMPTY)?:['?'];
    preg_match('/^(.)(.?)/u',$w[0],$a); $b=isset($w[1])&&preg_match('/^./u',$w[1],$m)?$m[0]:$a[2];
    return strtoupper($a[1].$b);
}
function showEmptyFolders(array $s): bool { return ($s['ui']['show_empty_folders']??false)===true; }
function cards(array $r,int $id,bool $showEmpty=false): string {
    $c=$r['cache']??[]; $count=0; $zipCount=0; $prefix=$r['path']??'';
    // Una sección por carpeta real; antes de actualizar una caché antigua,
    // las carpetas se deducen inmediatamente de sus rutas activas.
    $groups=[$prefix=>'']; $counts=[$prefix=>[0,0]];
    foreach($c['folders']??[] as $dir) {
        if(is_string($dir)&&($dir===''||safePath($dir))) { $groups[$dir]=''; $counts[$dir]=[0,0]; }
    }
    foreach($c['paths']??[] as $i=>$p) {
        $v=$c['hashes'][$i]??null; if(!is_string($v)||!oid($v)||!catalogPath($p)) continue;
        $zip=zipPath($p); if($zip)$zipCount++;
        $dir=dirname($p); if($dir==='.')$dir='';
        if(!isset($groups[$dir])){$groups[$dir]='';$counts[$dir]=[0,0];}
        $counts[$dir][$zip?1:0]++;
        $open='?open='.$id.'&amp;pos='.$i; $download='?download='.$id.'&amp;pos='.$i;
        $hue=intdiv(hexdec(substr($v,0,3))*360,4096);
        $link=$zip?'href="'.$download.'" download':'target="_blank" rel="noopener" href="'.$open.'"';
        $icon=$zip?'<i class="bi bi-file-earmark-zip-fill"></i>':h(mono($p));
        $actions=$zip?'<a class="btn sm pri act" href="'.$download.'" download title="Descargar ZIP original"><i class="bi bi-download" aria-hidden="true"></i> Descargar</a>':'<a class="btn sm pri act" target="_blank" rel="noopener" href="'.$open.'" title="Ver aplicación"><i class="bi bi-play-fill" aria-hidden="true"></i> Abrir</a><a class="btn sm act" href="'.$download.'" download title="Descargar HTML original" aria-label="Descargar"><i class="bi bi-download" aria-hidden="true"></i></a>';
        $groups[$dir].='<article class="app" data-type="'.($zip?'zip':'html').'" style="--h:'.$hue.';--i:'.min($count++,14).'" data-search="'.h($p.' '.$v.' '.$r['url']).'">'
            .'<div class="app-top"><span class="ico" aria-hidden="true">'.$icon.'</span><div class="grow"><a class="app-name" '.$link.'>'.h(basename($p)).'</a><small class="app-path" title="'.h($p).'">'.h($p).'</small></div></div>'
            .'<div class="app-foot"><code class="hash" title="'.h($v).'">'.h(substr($v,0,7)).'</code>'.$actions.'</div></article>';
    }
    // Raíz primero, luego rutas ordenadas de manera natural.
    uksort($groups,fn($a,$b)=>$a===$b?0:((string)$a===$prefix?-1:((string)$b===$prefix?1:(strnatcasecmp((string)$a,(string)$b)?:strcmp((string)$a,(string)$b)))));
    $out='';
    foreach($groups as $dir=>$html) {
        $dir=(string)$dir; [$n,$z]=$counts[$dir];
        if(!$showEmpty && $n+$z===0) continue;
        $label=$dir===$prefix?($prefix===''?'Raíz del repositorio':$prefix.' · Raíz de la fuente'):$dir;
        $out.='<section class="folder" data-folder><div class="folder-head"><span class="folder-icon"><i class="bi bi-folder2-open" aria-hidden="true"></i></span><h3>'.h($label).'</h3><span class="folder-count">'.$n.' HTML · '.$z.' ZIP</span></div>'
            .($html!==''?'<div class="grid">'.$html.'</div>':'<div class="folder-empty">Sin HTML ni ZIP directos.</div>').'</section>';
    }
    $info='<b class="repo-count">'.($count-$zipCount).'</b> HTML · '.$zipCount.' ZIP · '.(isset($c['commit'])?'commit <code>'.h(substr($c['commit'],0,10)).'</code>':'sin descubrir');
    $err=!empty($r['error'])?'<div class="note warn" role="status"><i class="bi bi-exclamation-triangle"></i><span>No se pudo actualizar: '.h($r['error']).'. Se conserva el último listado disponible.</span></div>':'';
    return '<div class="meta">'.$info.'</div>'.$err.$out.($count===0?'<div class="empty-inline">Todavía no hay archivos HTML ni ZIP disponibles.</div>':'').'<div class="filter-empty d-none">No hay coincidencias en esta fuente.</div>';
}
// Controlador: el mismo archivo es catálogo, login, administrador y endpoint.
if(defined('KOBALT_TEST')) return;
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);
session_start(); $admin=($_SESSION['admin']??false)===true;
$_SESSION['csrf']??=bin2hex(random_bytes(16)); $csrf=$_SESSION['csrf'];
$action=(string)($_POST['action']??''); $error='';
try {
    if(isset($_GET['open']) || isset($_GET['download'])) {
        session_write_close();
        $download=isset($_GET['download']); $filename=null; $publicFile=null;
        $b=getFile((int)$_GET[$download?'download':'open'],(int)($_GET['pos']??-1),$admin,$filename,$publicFile,$download);
        // El PHP materializa el objeto una vez; el servidor entrega el HTML público.
        if(!$download&&$publicFile!==null){
            header('Cache-Control: no-store');
            header('Location: ./'.rawurlencode($publicFile),true,302); exit;
        }
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: sandbox allow-scripts allow-forms allow-modals allow-downloads; object-src 'none'; base-uri 'none'");
        if($download){
            $fallback=preg_replace('/[^A-Za-z0-9._-]/','_', $filename) ?: 'archivo';
            header('Content-Type: '.(zipPath($filename)?'application/zip':'application/octet-stream'));
            header('Content-Disposition: attachment; filename="'.$fallback.'"; filename*=UTF-8' . "''" . rawurlencode($filename));
        } else header('Content-Type: text/html; charset=utf-8');
        echo $b; exit;
    }
    if($action==='refresh') {
        session_write_close();
        header('Content-Type: text/html; charset=utf-8');
        $id=(int)($_POST['id']??-1); $r=refresh($id,$admin,($_POST['force']??'')==='1'); echo cards($r,$id,showEmptyFolders(state())); exit;
    }
    if($action!=='') {
        if(!hash_equals($csrf,(string)($_POST['csrf']??''))) fail('Recarga la página.');
        if($action==='login') {
            $body=(string)($_POST['body']??''); $key=(string)($_POST['key']??'');
            if($body===''||$key==='') fail('Introduce cuerpo y clave.');
            $v=derive($body,$key);
            lock(function()use($v){$s=state(); if($s['auth']===null){$s['auth']=$v;saveState($s);}elseif(!hash_equals($s['auth'],$v))fail('Credenciales incorrectas.');});
            session_regenerate_id(true); $_SESSION['admin']=true;
        } elseif($action==='logout') { unset($_SESSION['admin']); }
        else {
            if(!$admin) fail('Acceso administrativo requerido.');
            lock(function()use($action){
                $s=state();
                if($action==='add') {
                    $url=sourceUrl((string)($_POST['url']??'')); $branch=trim((string)($_POST['branch']??'')); $path=trim((string)($_POST['path']??''),'/ ');
                    if(!validBranch($branch)||($path!==''&&!safePath($path))) fail('Rama o carpeta inválida.');
                    $mode=($_POST['adapter']??'')==='github_api'?'github_api':'git_http';
                    if($mode==='github_api'&&!cfg('github_tokens')['private']) fail('Configura KOBALT_GITHUB_TOKEN en el entorno PHP.');
                    foreach($s['repos'] as $r) if($r && strcasecmp($r['url'],$url)===0 && $r['branch']===$branch && $r['path']===$path && $r['adapter']===$mode) fail('Repositorio ya registrado.');
                    $s['repos'][]=['url'=>$url,'branch'=>$branch,'path'=>$path,'adapter'=>$mode,'credential'=>'private','public'=>$mode==='git_http'&&isset($_POST['public'])];
                } elseif($action==='appearance') {
                    $s['ui']['show_empty_folders']=isset($_POST['show_empty_folders']);
                } elseif($action==='remove') {
                    $id=(int)($_POST['id']??-1); repoAt($s,$id,true); $s['repos'][$id]=null;
                } else fail('Acción desconocida.');
                saveState($s);
            });
        }
        header('Location: '.($action==='logout'?'?catalog':($action==='appearance'?'?admin=ui&saved=1':'?admin')),true,303); exit;
    }
} catch(Throwable $e) {
    $error=$e->getMessage();
    if(isset($_GET['open'])||isset($_GET['download'])||$action==='refresh'){http_response_code(400);header('Content-Type: text/plain; charset=utf-8');echo $error;exit;}
}
$s=state(); $panel=isset($_GET['admin']); $showAdmin=$panel&&$admin; $uiPanel=$showAdmin&&($_GET['admin']??'')==='ui'; $showEmpty=showEmptyFolders($s);
session_write_close();
header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff');
?><!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#2350f5"><title>Kobalt Apps</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
:root{--bg:#f3f5fb;--card:#fff;--ink:#0e1830;--mut:#647089;--line:#e3e8f2;--k:#2350f5;--k2:#13b5ff;--soft:#ebf0ff;--sh:0 1px 2px #0e18300d,0 8px 24px -12px #0e183026;color-scheme:light dark}
@media(prefers-color-scheme:dark){:root{--bg:#090e1b;--card:#111a2d;--ink:#e7ecf7;--mut:#8f9bb5;--line:#1f2a43;--soft:#18244a;--sh:0 10px 30px -14px #000c}.warn{background:#2c2208!important;color:#f5c869!important;border-color:#4a3810!important}.bad{background:#2d1013!important;color:#ff9aa0!important;border-color:#4d1a1f!important}}
*{box-sizing:border-box}a{color:inherit}.d-none{display:none!important}.grow{flex:1;min-width:0}
body{margin:0;min-height:100vh;font:15px/1.5 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--ink);background:radial-gradient(900px 420px at 0 -120px,#2350f52e,transparent 70%) no-repeat,radial-gradient(700px 360px at 100% -160px,#13b5ff24,transparent 70%) no-repeat,var(--bg);-webkit-font-smoothing:antialiased}
.wrap{max-width:1080px;margin:auto;padding:0 20px}
.top{position:sticky;top:0;z-index:10;background:color-mix(in srgb,var(--bg) 72%,transparent);backdrop-filter:saturate(1.6) blur(14px);-webkit-backdrop-filter:saturate(1.6) blur(14px);border-bottom:1px solid var(--line)}
.bar{display:flex;align-items:center;gap:16px;height:64px}
.brand{display:flex;align-items:center;gap:10px;text-decoration:none;font-size:17px;letter-spacing:-.01em}
.mark{display:grid;place-items:center;flex:none;width:36px;height:36px;border-radius:11px;color:#fff;font-size:17px;background:linear-gradient(135deg,var(--k2),var(--k) 60%,#5b2bff);box-shadow:0 6px 16px -6px var(--k),inset 0 1px 0 #fff6}
.tabs{display:flex;gap:4px;padding:4px;margin-left:auto;background:var(--card);border:1px solid var(--line);border-radius:14px}
.tab{display:flex;align-items:center;gap:7px;padding:7px 14px;border-radius:10px;text-decoration:none;color:var(--mut);font-weight:600;font-size:14px;transition:.2s}
.tab:hover{color:var(--ink)}.tab[aria-current]{color:#fff;background:var(--k);box-shadow:0 4px 12px -4px var(--k)}
.subtabs{display:flex;gap:6px;width:fit-content;max-width:100%;margin-bottom:20px;padding:4px;border:1px solid var(--line);border-radius:14px;background:var(--card)}
.preference{display:flex;align-items:center;gap:14px;padding:16px 0;margin:12px 0;border-bottom:1px solid var(--line);cursor:pointer}.preference small{display:block;color:var(--mut);margin-top:4px;font-weight:400}.preference input{flex:none;width:20px;height:20px}.saved{margin:0 0 16px;color:var(--mut);font-size:13px}
.ver,kbd{font:600 11px ui-monospace,monospace;color:var(--mut);padding:4px 8px;border:1px solid var(--line);border-radius:99px}kbd{border-radius:7px}
.hero{display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:20px;padding:40px 0 26px}
.eyebrow{margin:0 0 8px;font:700 11px/1 ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase;color:var(--k)}
h1{margin:0;font-size:clamp(28px,4.4vw,40px);line-height:1.08;letter-spacing:-.03em;font-weight:800}h2{margin:0;font-size:17px;letter-spacing:-.01em}
.grad{background:linear-gradient(90deg,var(--k),var(--k2));-webkit-background-clip:text;background-clip:text;color:transparent}
.sub{margin:10px 0 0;color:var(--mut);max-width:520px}
.stats{display:flex;gap:10px}.stat{min-width:118px;padding:12px 18px}.stat b{display:block;font-size:26px;line-height:1.1;letter-spacing:-.02em;font-variant-numeric:tabular-nums}.stat small{color:var(--mut);font-size:12px}
.stat,.panel,.repo{background:var(--card);border:1px solid var(--line);border-radius:18px;box-shadow:var(--sh)}
.panel{padding:24px;margin-bottom:22px}
.form{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px}.full{grid-column:1/-1}
.field{display:grid;gap:6px;font-size:13px;font-weight:600}
input:not([type=checkbox]),select{width:100%;font:inherit;color:var(--ink);background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:10px 13px;outline:0;transition:.15s}
input:focus,select:focus,.search:focus-within{border-color:var(--k);box-shadow:0 0 0 4px #2350f526}
.check{display:flex;gap:8px;align-items:center;align-self:end;padding-bottom:10px;font-size:14px}input[type=checkbox]{accent-color:var(--k);width:17px;height:17px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:10px 16px;border-radius:12px;border:1px solid var(--line);background:var(--card);color:var(--ink);font:inherit;font-weight:600;font-size:14px;line-height:1;white-space:nowrap;text-decoration:none;cursor:pointer;transition:.18s}
.btn:hover{border-color:var(--k);color:var(--k)}.btn:active{transform:scale(.96)}.btn:disabled{opacity:.6;cursor:progress}
.pri{background:var(--k);border-color:var(--k);color:#fff;box-shadow:0 6px 16px -8px var(--k)}.pri:hover{color:#fff;filter:brightness(1.12)}
.danger:hover{border-color:#e5484d;color:#e5484d}.sm{padding:7px 11px;font-size:13px;border-radius:10px}
.spin i{animation:rot .8s linear infinite}@keyframes rot{to{transform:rotate(1turn)}}
.tools{display:flex;gap:10px;margin-bottom:10px}
.search{flex:1;display:flex;align-items:center;gap:10px;height:48px;padding:0 10px 0 16px;border-radius:16px;background:var(--card);border:1px solid var(--line);box-shadow:var(--sh);color:var(--mut);transition:.15s}
.search input{border:0;background:none;padding:0;height:100%;box-shadow:none!important}
.tools .btn{height:48px;border-radius:16px;padding:0 18px}
.meta-row{display:flex;justify-content:space-between;gap:10px;margin:0 4px 16px;font-size:13px;color:var(--mut)}
.repo{position:relative;margin-bottom:18px;overflow:hidden}
.repo.loading::before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,transparent,var(--k),var(--k2),transparent) no-repeat;background-size:50% 100%;animation:slide 1.1s ease-in-out infinite}
@keyframes slide{from{background-position:-100% 0}to{background-position:200% 0}}
.repo-head{display:flex;align-items:center;gap:14px;padding:16px 18px;border-bottom:1px solid var(--line)}.repo-head h2{font-size:15px;overflow-wrap:anywhere}
.gh{display:grid;place-items:center;flex:none;width:40px;height:40px;border-radius:12px;background:var(--soft);color:var(--k);font-size:19px}
.chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:5px}
.chip{display:inline-flex;align-items:center;gap:5px;padding:2px 9px;border-radius:99px;background:var(--bg);border:1px solid var(--line);font-size:12px;color:var(--mut);text-decoration:none}a.chip:hover{color:var(--k);border-color:var(--k)}
.repo-body{padding:14px 18px 18px}.meta{margin-bottom:12px;font-size:12px;color:var(--mut)}
.meta code,.hash{font:500 11.5px ui-monospace,SFMono-Regular,monospace}
.folder+.folder{margin-top:18px;padding-top:14px;border-top:1px solid var(--line)}
.folder-head{display:flex;align-items:center;gap:9px;margin:0 0 10px;min-width:0}
.folder-icon{display:grid;place-items:center;flex:none;width:30px;height:30px;border-radius:9px;background:var(--soft);color:var(--k);font-size:16px}
.folder-head h3{margin:0;flex:1;min-width:0;font-size:13px;font-weight:700;overflow-wrap:anywhere}.folder-count{flex:none;font-size:11px;color:var(--mut);border:1px solid var(--line);border-radius:99px;padding:3px 8px}.folder-empty{color:var(--mut);font-size:12px;padding:0 0 2px 39px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px}
.app{position:relative;display:flex;flex-direction:column;gap:12px;padding:14px;border-radius:16px;background:var(--bg);border:1px solid var(--line);transition:transform .2s,box-shadow .2s,border-color .2s;animation:up .45s calc(var(--i)*35ms) backwards}
.app:hover,.app:focus-within{transform:translateY(-3px);border-color:hsl(var(--h) 75% 58%/.7);box-shadow:0 16px 30px -18px hsl(var(--h) 80% 45%)}
@keyframes up{from{opacity:0;transform:translateY(10px)}}
.app-top{display:flex;align-items:center;gap:12px}
.ico{display:grid;place-items:center;flex:none;width:46px;height:46px;border-radius:14px;color:#fff;font-weight:800;font-size:16px;letter-spacing:-.02em;text-shadow:0 1px 2px #0003;background:linear-gradient(140deg,hsl(var(--h) 90% 62%),hsl(calc(var(--h) + 45) 80% 46%));box-shadow:inset 0 1px 0 #fff6,0 6px 14px -8px hsl(var(--h) 80% 40%);transition:transform .25s}
.app:hover .ico{transform:rotate(-6deg) scale(1.06)}
.app-name,.app-path{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.app-name{font-weight:700;text-decoration:none}.app-path{font-size:12px;color:var(--mut)}
.app-name::after{content:"";position:absolute;inset:0;border-radius:inherit}
.app-foot{display:flex;align-items:center;gap:6px;margin-top:auto}.hash{margin-right:auto;color:var(--mut)}.act{position:relative;z-index:1}
.note{display:flex;gap:10px;align-items:flex-start;margin:14px 0;padding:12px 14px;border-radius:14px;font-size:14px;border:1px solid}
.warn{background:#fff5e0;color:#8a5a00;border-color:#f5d999}.bad{background:#ffecec;color:#a4282d;border-color:#f6c4c6}
.empty{padding:48px 20px;text-align:center;color:var(--mut)}.empty i{font-size:38px;color:var(--k)}.empty h2{margin:12px 0 4px;color:var(--ink)}
.empty-inline,.filter-empty{padding:18px 4px;color:var(--mut);font-size:14px}
summary{display:flex;align-items:center;gap:6px;list-style:none;cursor:pointer;color:var(--k);font-weight:600;font-size:14px}summary::-webkit-details-marker{display:none}
summary::before{content:"\F285";font-family:bootstrap-icons;transition:.2s}details[open] summary::before{transform:rotate(90deg)}details[open] summary{margin-bottom:14px}
.status{display:block;margin-top:10px;font-size:12px;color:var(--mut)}.status:empty{display:none}
.login{max-width:420px;margin:0 auto 30px;display:grid;gap:14px}.login .mark{width:50px;height:50px;border-radius:16px;font-size:22px}.login p{margin:0;font-size:14px;color:var(--mut)}
footer{display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-top:30px;padding:20px 4px 40px;border-top:1px solid var(--line);font-size:12px;color:var(--mut)}
@media(max-width:640px){.top{backdrop-filter:none;-webkit-backdrop-filter:none;background:color-mix(in srgb,var(--bg) 94%,transparent)}.wrap{padding:0 14px}.bar{height:56px}body{padding-bottom:84px}
.tabs{position:fixed;left:12px;right:12px;bottom:calc(10px + env(safe-area-inset-bottom));margin:0;border-radius:20px;padding:6px;background:color-mix(in srgb,var(--card) 82%,transparent);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);box-shadow:0 12px 30px -10px #0e183066}
.tab{flex:1;flex-direction:column;justify-content:center;gap:2px;padding:7px;font-size:11px}.tab i{font-size:19px}.ver{margin-left:auto}
.hero{padding:26px 0 18px}.stats{width:100%}.stat{flex:1;min-width:0}.form{grid-template-columns:1fr}
.meta-row{flex-direction:column;gap:2px}.tools .btn span,kbd{display:none}.tools .btn{width:48px;padding:0}.grid{grid-template-columns:1fr}.repo-head{padding:14px}.repo-body{padding:12px 14px 14px}}
@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style></head>
<body><header class="top"><div class="wrap bar"><a class="brand" href="?catalog"><span class="mark"><i class="bi bi-grid-1x2-fill" aria-hidden="true"></i></span><span><b>Kobalt</b> Apps</span></a>
<nav class="tabs" aria-label="Navegación principal"><a class="tab" <?=$panel?'':'aria-current="page"'?> href="?catalog"><i class="bi bi-grid<?=$panel?'':'-fill'?>" aria-hidden="true"></i><span>Catálogo</span></a><a class="tab" <?=$panel?'aria-current="page"':''?> href="?admin"><i class="bi bi-gear<?=$panel?'-fill':''?>" aria-hidden="true"></i><span>Administración</span></a></nav><span class="ver">v0.3.5</span></div></header>
<main class="wrap">
<?php if($error): ?><div class="note bad" role="alert"><i class="bi bi-exclamation-octagon"></i><span><?=h($error)?></span></div><?php endif; ?>
<?php if($panel&&!$admin): ?>
<div class="hero"><div><p class="eyebrow">Área privada</p><h1>Administración</h1><p class="sub">Gestiona las fuentes del catálogo.</p></div></div>
<form method="post" class="panel login"><span class="mark"><i class="bi bi-shield-lock-fill"></i></span><h2><?= $s['auth']===null?'Registrar autoridad':'Iniciar sesión' ?></h2>
<?php if($s['auth']===null): ?><p>Primera visita: define el cuerpo y la clave antes de compartir la URL.</p><?php endif; ?>
<input type="hidden" name="action" value="login"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><label class="field">Cuerpo<input name="body" type="password" required autofocus></label><label class="field">Clave<input name="key" type="password" required></label><button class="btn pri">Continuar <i class="bi bi-arrow-right"></i></button></form>
<?php else: ?>
<div class="hero"><div><p class="eyebrow"><?=$showAdmin?'Área privada':'Biblioteca pública'?></p><h1><?=$showAdmin?($uiPanel?'Apariencia del <span class="grad">catálogo</span>':'Administración de <span class="grad">fuentes</span>'):'Explora las <span class="grad">aplicaciones</span>'?></h1><p class="sub"><?=$showAdmin?($uiPanel?'Configura cómo se presentan los archivos y las carpetas.':'Registra y administra los repositorios que alimentan el catálogo.'):'Abre aplicaciones HTML o descarga archivos HTML y ZIP de nuestros repositorios.'?></p></div>
<?php if($showAdmin): ?><form method="post"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><button class="btn sm"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</button></form><?php else: ?><div class="stats"><div class="stat"><b id="total-repos">0</b><small>Repositorios</small></div><div class="stat"><b id="total-apps">0</b><small>Archivos</small></div></div><?php endif; ?></div>
<?php if($showAdmin): ?>
<nav class="subtabs" aria-label="Administración"><a class="tab" <?=$uiPanel?'':'aria-current="page"'?> href="?admin"><i class="bi bi-github"></i> Fuentes</a><a class="tab" <?=$uiPanel?'aria-current="page"':''?> href="?admin=ui"><i class="bi bi-sliders"></i> Apariencia</a></nav>
<?php endif; ?>
<?php if($uiPanel): ?>
<section class="panel"><h2><i class="bi bi-sliders grad"></i> Carpetas del catálogo</h2>
<?php if(isset($_GET['saved'])): ?><p class="saved" role="status"><i class="bi bi-check-circle"></i> Preferencias guardadas.</p><?php endif; ?>
<form method="post"><input type="hidden" name="action" value="appearance"><input type="hidden" name="csrf" value="<?=h($csrf)?>">
<label class="preference"><input type="checkbox" name="show_empty_folders" <?=$showEmpty?'checked':''?>><span><b>Mostrar carpetas vacías</b><small>Incluye las secciones sin HTML ni ZIP directos. Las subcarpetas con archivos aparecen en su propia sección.</small></span></label>
<button class="btn pri"><i class="bi bi-check2"></i> Guardar cambios</button></form></section>
<?php else: ?>
<?php if($showAdmin): ?>
<section class="panel"><h2><i class="bi bi-plus-circle-fill grad"></i> Registrar repositorio</h2><form method="post" class="form"><input type="hidden" name="action" value="add"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><label class="field full">URL de GitHub<input type="url" name="url" placeholder="https://github.com/usuario/repo" required></label><label class="field">Rama<input name="branch" placeholder="Predeterminada si se deja vacío"></label><label class="field">Carpeta<input name="path" placeholder="Todo el repositorio si se deja vacío"></label><label class="field">Adaptador<select name="adapter"><option value="git_http">Git HTTP sin API</option><option value="github_api">API privada (token de entorno)</option></select></label><label class="check"><input type="checkbox" name="public" checked> Mostrar en el catálogo público (solo Git HTTP)</label><div class="full"><button class="btn pri"><i class="bi bi-plus-lg"></i> Registrar</button></div></form></section>
<?php endif; ?>
<div class="tools"><label class="search"><i class="bi bi-search"></i><input id="search" aria-label="Buscar archivos" placeholder="Buscar archivos…" autocomplete="off"><kbd>/</kbd></label><button id="refresh" class="btn" type="button" title="Actualizar"><i class="bi bi-arrow-clockwise"></i><span>Actualizar</span></button></div>
<div class="meta-row"><span id="summary" aria-live="polite"></span><span id="refresh-status" aria-live="polite"></span></div>
<?php $visible=0; foreach($s['repos'] as $id=>$r): if(!$r||(!$r['public']&&!$showAdmin))continue; $visible++; ?>
<section class="repo" data-repo="<?=$id?>"><div class="repo-head"><span class="gh"><i class="bi bi-github"></i></span><div class="grow"><h2><?=h(substr($r['url'],strlen('https://github.com/')).($r['path']?'/'.$r['path']:''))?></h2><div class="chips"><a class="chip" href="<?=h($r['url'])?>" target="_blank" rel="noopener"><i class="bi bi-git"></i><?=h($r['branch']?:'Rama predeterminada')?> <i class="bi bi-arrow-up-right"></i></a><?php if($showAdmin): ?><span class="chip"><i class="bi bi-<?=$r['public']?'globe2':'lock-fill'?>"></i><?=$r['public']?'Público':'Privado'?></span><?php endif; ?></div></div><?php if($showAdmin): ?><form method="post" onsubmit="return confirm('¿Retirar esta fuente?')"><input type="hidden" name="action" value="remove"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="id" value="<?=$id?>"><button class="btn sm danger"><i class="bi bi-trash3"></i> Quitar</button></form><?php endif; ?></div>
<div class="repo-body"><?php if($showAdmin): ?><details><summary>Ver archivos de esta fuente</summary><?php endif; ?><div class="results"><?=cards($r,$id,$showEmpty)?></div><?php if($showAdmin): ?></details><?php endif; ?><small class="status" aria-live="polite"></small></div></section>
<?php endforeach; if(!$visible): ?><div class="panel empty"><i class="bi bi-folder2-open"></i><h2>Todavía no hay fuentes registradas</h2><p>Agrega repositorios desde Administración.</p></div><?php endif; ?>
<script>
const sections=[...document.querySelectorAll('[data-repo]')],search=document.querySelector('#search'),button=document.querySelector('#refresh'),summary=document.querySelector('#summary'),refreshStatus=document.querySelector('#refresh-status');
function filter(){const q=search.value.trim().toLowerCase();let total=0,visible=0,html=0,zip=0;for(const s of sections){let n=0;const rows=[...s.querySelectorAll('.app')];for(const a of rows){if(a.dataset.type==='zip')zip++;else html++;const match=a.dataset.search.toLowerCase().includes(q);a.classList.toggle('d-none',!match);if(match)n++;}for(const f of s.querySelectorAll('[data-folder]'))f.classList.toggle('d-none',!!q&&!f.querySelector('.app:not(.d-none)'));total+=rows.length;visible+=n;s.querySelector('.filter-empty')?.classList.toggle('d-none',!q||n>0||rows.length===0);if(q&&n)s.querySelector('details')?.setAttribute('open','');}summary.textContent=q?`${visible} de ${total} archivos`:`${html} HTML · ${zip} ZIP · ${sections.length} repositorios`;const a=document.querySelector('#total-apps'),r=document.querySelector('#total-repos');if(a)a.textContent=total;if(r)r.textContent=sections.length;}
search.addEventListener('input',filter);
addEventListener('keydown',e=>{if(e.key==='/'&&!/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement.tagName)){e.preventDefault();search.focus();}else if(e.key==='Escape'&&document.activeElement===search){search.value='';filter();search.blur();}});
async function update(force=false){button.disabled=true;button.classList.add('spin');button.querySelector('span').textContent='Actualizando…';refreshStatus.textContent='Comprobando fuentes…';let errors=0;try{for(const s of sections){const status=s.querySelector('.status');s.classList.add('loading');status.textContent='Comprobando…';try{const r=await fetch(location.pathname,{method:'POST',body:new URLSearchParams({action:'refresh',id:s.dataset.repo,force:force?'1':'0'})});if(!r.ok)throw Error(await r.text());s.querySelector('.results').innerHTML=await r.text();status.textContent='';if(s.querySelector('.results .warn'))errors++;filter();}catch(e){errors++;status.textContent='No se pudo comprobar: '+e.message;}finally{s.classList.remove('loading');}}}finally{button.disabled=false;button.classList.remove('spin');button.querySelector('span').textContent='Actualizar';refreshStatus.textContent=errors?'Algunas fuentes no se pudieron actualizar':(sections.length?'Comprobación finalizada':'');}}
button.addEventListener('click',()=>update(true));filter();if(sections.length)update();
</script>
<?php endif; // Apariencia o listado ?>
<?php endif; ?>
<footer><span>Kobalt Apps · PHP nativo</span><span>Git HTTP · caché local · archivos originales</span></footer></main></body></html>
