'use strict';
// Experimento: geometría general y tratamiento de venta externo.
const Vectorial=(()=>{
 const {need}=Qipu.K2P, {cat}=Qipu.K4B;
 const nat=x=>need(Number.isSafeInteger(x)&&x>=0&&x<=1e9,'Natural inválido');
 const txt=x=>need(typeof x==='string'&&new TextEncoder().encode(x).length>0&&new TextEncoder().encode(x).length<=200&&!x.startsWith('\uFEFF')&&new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(new TextEncoder().encode(x))===x,'Texto inválido');
 const val=(k,x)=>{need([0,1,2,3].includes(k),'Clase inválida');if(k===0)txt(x);else if(k===3)need(typeof x==='boolean','Booleano inválido');else nat(x);};
 const zero=()=>({tables:[],sales:[],count:0});
 const add=(xs,name,make)=>{let i=xs.findIndex(x=>x.name===name);if(i===-1){i=xs.length;need(i<65536,'Capacidad');xs.push(make(name));}return i;};
 // Reference must already exist. No side effects on failed operations.
 function apply(s,t,a,handlers={7:sale}){const d=structuredClone(s);if(t===13){let [scope,name,x,k]=a;need([0,1,2].includes(scope),'Perfil: identidad y parámetro independientes');txt(name);if(scope!==0)txt(x);if(scope===1)need([0,1,2,3].includes(k),'Clase inválida');let ti=add(d.tables,name,name=>({name,entities:[],vectors:[]})),tab=d.tables[ti];if(scope===2)add(tab.entities,x,name=>({name}));if(scope===1){let v=add(tab.vectors,x,name=>({name,kind:k,values:{}}));need(tab.vectors[v].kind===k,'Clase incompatible');}}
 else {let [ti,vi,i,x]=a,tab=d.tables[ti],v=tab?.vectors[vi];need(tab&&v,'Referencia inexistente');if(handlers[t])handlers[t](d,tab,v,a);else {need(tab.entities[i],'Entidad inexistente');if(t===9||t===10){need(v.kind!==2,'Stock no admite ausencia explícita');if(t===9)v.values[i]=null;else delete v.values[i];}else{let k=({4:0,5:2,6:2,8:1,11:3,12:2})[t];need(k===v.kind,'Tipo incompatible');val(k,x);if(t===6||t===12){need(Object.hasOwn(v.values,i)&&Number.isSafeInteger(v.values[i]),'Stock ausente');x=v.values[i]+(t===6?x:-x);nat(x);}v.values[i]=x;}}}d.count++;return d;}
 function sale(d,tab,v,a){need(v.kind===2,'Vector de stock requerido');let total=0,qty=new Map();need(a[2].length>0,'Venta vacía');for(let [i,q,p] of a[2]){need(tab.entities[i],'Entidad inexistente');nat(q);nat(p);need(q>0,'Cantidad positiva');qty.set(i,(qty.get(i)||0)+q);total+=q*p;need(Number.isSafeInteger(total),'Total fuera de rango');}for(let [i,q] of qty)need(Object.hasOwn(v.values,i)&&Number.isSafeInteger(v.values[i])&&v.values[i]>=q,'Stock insuficiente');for(let [i,q] of qty)v.values[i]-=q;d.sales.push({table:a[0],vector:a[1],lines:a[2],total});}
 async function extend(s,bytes){let offset=0,d=s;while(offset<bytes.length){let f=await Qipu.K5B.read(bytes,offset),a=Qipu.Contratos.decode(f.t,f.body);d=apply(d,a.t,a.a);offset=f.end;}return d;}
 const encode=(t,a)=>Qipu.Contratos.encode(t,...a);
 function project(s,t,i,fields){const tab=s.tables[t];need(tab?.entities[i],'Entidad inexistente');let o=Object.create(null);o.sku=tab.entities[i].name;for(let v of tab.vectors)if((!fields||fields.includes(v.name))&&Object.hasOwn(v.values,i))o[v.name]=v.values[i];return o;}
 function exportView(s){return s.tables.map((t,i)=>({name:t.name,entities:t.entities.map(e=>e.name),vectors:t.vectors,sales:s.sales.filter(x=>x.table===i).map(({lines,total})=>({lines,total}))}));}
 const example=[[13,[2,'Producto','SKU-A']],[13,[2,'Producto','SKU-B']],[13,[1,'Producto','Nombre',0]],[4,[0,0,0,'Camisa']],[4,[0,0,1,'Zapato']],[13,[1,'Producto','Precio',1]],[8,[0,1,0,35000]],[8,[0,1,1,80000]],[13,[1,'Producto','Stock',2]],[5,[0,2,0,20]],[5,[0,2,1,15]],[7,[0,2,[[0,3,35000],[1,4,80000]]]],[13,[1,'Producto','Color',0]],[4,[0,3,1,'Negro']],[5,[0,2,0,12]],[6,[0,2,1,2]],[13,[2,'Producto','SKU-A']],[7,[0,2,[[0,2,35000],[0,1,35000]]]]];
 return {zero,apply,extend,encode,project,exportView,example,cat};
})();
