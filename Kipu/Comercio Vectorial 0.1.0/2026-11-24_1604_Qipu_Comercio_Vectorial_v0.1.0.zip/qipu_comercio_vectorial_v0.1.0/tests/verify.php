<?php
declare(strict_types=1);
require __DIR__.'/../src/Qipu.php';
$raw=file_get_contents($argv[1]);$dir=sys_get_temp_dir().'/qipu-vectorial-'.bin2hex(random_bytes(6));mkdir($dir,0700);$p=new Storage($dir);$p->create('C');$d=[];$ix=QipuDemo::indexes($d);$cuts=[];$off=0;
try {foreach(QipuDemo::scan($raw) as $f){[$t,$a]=QipuDemo::decodeOp($f['raw']);QipuDemo::ok(QipuDemo::op($t,$a)===$f['raw'],'Roundtrip PHP');QipuDemo::apply($d,$t,$a,$ix);$p->append('C',$off,$f['raw']);$off+=strlen($f['raw']);$cuts[]=QipuDemo::view($d);}QipuDemo::ok($p->read('C',0,$off)['bytes']===$raw,'PAO bytes differ');echo json_encode(['cuts'=>$cuts,'bytes'=>$off,'sha256'=>hash('sha256',$raw)],JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);}
finally {foreach(glob($dir.'/*') as $f)unlink($f);rmdir($dir);}
