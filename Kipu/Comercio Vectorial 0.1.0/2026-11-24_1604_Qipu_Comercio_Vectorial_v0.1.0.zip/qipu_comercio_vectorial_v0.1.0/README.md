# Qipu Comercio Vectorial v0.1.0 · experimento independiente

No sustituye Comercio 1.0.0. Usa K2P/K4B/K5B originales, T13 ámbito identidad/parámetro y operaciones posicionales existentes. Ejecutar `node tests/run.cjs` con PHP 8.1+ de 64 bits y Node.js 22. El script genera ejemplo.qipu, ejecuta el intérprete PHP original y escribe/lee los bytes vía PAO en un directorio temporal. Los resultados de esta ejecución están en tests/resultados.txt.

Abrir laboratorio.html en un navegador compatible con Web Crypto (HTTPS o localhost). No necesita CDN ni Python/Node para la interfaz. El laboratorio HTML no ha sido probado en un navegador en esta ejecución. No hay integración distribuida, IndexedDB ni T111 de procedencia en este experimento; se evalúa exclusivamente la capa de recorrido y proyección. PHP usa el intérprete original como oráculo; el nuevo manejador de ventas separado está solo en JS.

Conservar posiciones en el espacio y corte correcto. Las asignaciones y ventas sobre una identidad conocida referencian (t,v,i); las identidades locales provisionales no son coordenadas canónicas. Los índices del ensayo son lineales, no se ha medido rendimiento.
