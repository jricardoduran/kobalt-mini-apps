<?php
declare(strict_types=1);
// Perfil comercial. Usa los contratos binarios existentes; no escribe archivos.
final class Comercio {
 static function request(array $q):array {
  switch($q['op']??null){
   case 'product': QipuDemo::keys($q,['op','sku','name','price']); QipuDemo::sku($q['sku']); QipuDemo::txt($q['name']); QipuDemo::num($q['price']); break;
   case 'stock': QipuDemo::keys($q,['op','sku','value']); QipuDemo::sku($q['sku']); QipuDemo::num($q['value']); break;
   case 'sale': QipuDemo::keys($q,['op','lines']); QipuDemo::ok(is_array($q['lines'])&&array_is_list($q['lines'])&&count($q['lines'])>=1&&count($q['lines'])<=1000,'Invalid sale lines'); $sum=0; foreach($q['lines'] as $l){QipuDemo::ok(is_array($l),'Invalid sale line');QipuDemo::keys($l,['sku','qty','price']);QipuDemo::sku($l['sku']);QipuDemo::ok(QipuDemo::num($l['qty'])>0,'Positive quantity required');QipuDemo::num($l['price']);$sum+=$l['qty']*$l['price'];QipuDemo::ok(is_int($sum)&&$sum<=9007199254740991,'Sale total overflow');}break;
   default: QipuDemo::ok(false,'Unknown commerce request');
  } return $q;
 }
 static function genesis():array{return [[13,[1,'Producto','Stock',2]]];}
 static function resolve(array $d,array $q):array{
  self::request($q);
  if($q['op']==='product')return [[13,[3,'Producto',$q['sku'],'Nombre',0,$q['name']]],[13,[3,'Producto',$q['sku'],'Precio',1,$q['price']]]];
  $ix=QipuDemo::indexes($d);$t=$ix['tables'][':Producto']??null;QipuDemo::ok($t!==null,'Product type not constituted',409);$v=$ix['vectors'][$t][':Stock']??null;QipuDemo::ok($v!==null&&$d[$t]['vectors'][$v]['kind']===2,'Stock vector not constituted',409);
  $find=function($sku)use($ix,$t){$i=$ix['entities'][$t][':'.$sku]??null;QipuDemo::ok($i!==null,'Unknown SKU',409);return $i;};
  if($q['op']==='stock')return [[5,[$t,$v,$find($q['sku']),$q['value']]]];
  $lines=[];foreach($q['lines'] as $l)$lines[]=[$find($l['sku']),$l['qty'],$l['price']];return [[7,[$t,$v,$lines]]];
 }
}
