# Qipu Comercio 1.0.0 (experimental)

Perfil comercial de Qipu 2.1.0 + PAO 1.1.0. Leer `public/README.html` (autónomo). Los módulos `src/Comercio.php` y `public/js/comercio.js` definen producto, asignación absoluta de stock y venta multilínea; PAO original intacto.

## Ejecución (sin dependencias externas)

```sh
php -S 127.0.0.1:8080 -t public
```

Abrir http://127.0.0.1:8080/. PHP 8.1+ 64 bits, filesystem local con flock/fsync, navegador moderno. Datos en `data-comercio-v1` (o `QIPU_ROOT`), fuera de `public`. IndexedDB `qipu-comercio-v1`. No reutilizar datos de Qipu 2.1.0. No OAuth ni autenticación: exclusivamente laboratorio aislado. No despliegue público.

## Pruebas

`bash tests/run.sh` (Node), `php tests/recovery.php`, `python tests/browser.py` (Playwright/Chromium). Las herramientas adicionales solo están en la distribución completa. Resultados de comercio: 34/34 PHP integrado y 34/34 Apache + mod_php, 6/6 recuperación CLI. 400/400 comprobaciones de regresión de Qipu 2.1.0 original reejecutadas aparte. Chromium bloqueó HTTP y file; la UI/IndexedDB no se considera validada. `tests/base.txt`, `advanced.txt`, `browser-base.txt` son registros de la versión original; `tests/comercio-*.txt` corresponden al nuevo perfil. No pruebas masivas.
