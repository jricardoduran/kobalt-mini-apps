'use strict';
// Contratos específicos: no conocen HTTP, IndexedDB, PAO ni la autoridad.
const Comercio=(()=>{
 const need=Qipu.K2P.need, natural=x=>Number.isSafeInteger(x)&&x>=0&&x<=1e9;
 const keys=(x,k)=>need(x&&typeof x==='object'&&!Array.isArray(x)&&Object.keys(x).length===k.length&&k.every(a=>Object.hasOwn(x,a)),'Campos inválidos');
 const sku=x=>need(typeof x==='string'&&/^[A-Z0-9_-]{1,40}$/.test(x)&&!/[\r\n]/.test(x),'SKU inválido');
 const text=x=>need(typeof x==='string'&&new TextEncoder().encode(x).length>0&&new TextEncoder().encode(x).length<=200&&!x.startsWith('\uFEFF')&&new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(new TextEncoder().encode(x))===x,'Texto inválido');
 function request(q){need(q&&typeof q==='object'&&!Array.isArray(q),'Solicitud inválida');switch(q.op){case 'product':keys(q,['op','sku','name','price']);sku(q.sku);text(q.name);need(natural(q.price),'Precio inválido');break;case 'stock':keys(q,['op','sku','value']);sku(q.sku);need(natural(q.value),'Stock inválido');break;case 'sale':keys(q,['op','lines']);need(Array.isArray(q.lines)&&q.lines.length>=1&&q.lines.length<=1000,'Líneas inválidas');let sum=0;for(let l of q.lines){keys(l,['sku','qty','price']);sku(l.sku);need(natural(l.qty)&&l.qty>0&&natural(l.price),'Cantidad o precio inválido');sum+=l.qty*l.price;need(Number.isSafeInteger(sum),'Total fuera de rango');}break;default:throw Error('Solicitud comercial desconocida');}return q;}
 const genesis=()=>[[13,[1,'Producto','Stock',2]]];
 function resolve(d,q,indexes){request(q);if(q.op==='product')return [[13,[3,'Producto',q.sku,'Nombre',0,q.name]],[13,[3,'Producto',q.sku,'Precio',1,q.price]]];let z=indexes(d),t=z.tables.get('Producto');need(t!==undefined,'Tipo Producto no constituido');let v=z.vectors[t].get('Stock');need(v!==undefined&&d[t].vectors[v].kind===2,'Vector Stock no constituido');const find=sku=>{let i=z.entities[t].get(sku);need(i!==undefined,'SKU inexistente');return i;};if(q.op==='stock')return [[5,[t,v,find(q.sku),q.value]]];return [[7,[t,v,q.lines.map(l=>[find(l.sku),l.qty,l.price])]]];}
 return {request,genesis,resolve};
})();
