"""Prueba real UI/IndexedDB. No fake-indexeddb. Salida 77 si política bloquea."""
import os,sys,pathlib,tempfile,subprocess,socket,time,urllib.request,json,signal
from playwright.sync_api import sync_playwright
root=pathlib.Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='comercio-browser-') as tmp:
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 base=f'http://127.0.0.1:{port}'; log=open(pathlib.Path(tmp)/'server.log','w'); server=subprocess.Popen(['php','-S',f'127.0.0.1:{port}','-t',str(root/'public')],env={**os.environ,'QIPU_ROOT':tmp},stdout=log,stderr=log,start_new_session=True)
 checks=0
 def check(x,label):
  global checks
  assert x,label; checks+=1;print('PASS',label,flush=True)
 try:
  for _ in range(100):
   try:
    with urllib.request.urlopen(base+'/api.php?op=nodes',timeout=1) as h:assert json.load(h)['nodes']==[]
    break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('PHP no inicia')
  with sync_playwright() as p:
   b=p.chromium.launch(executable_path=os.getenv('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox']);ctx=b.new_context();pg=ctx.new_page()
   try:pg.goto(base+'/',timeout=7000)
   except Exception as e:
    if 'ERR_BLOCKED_BY_ADMINISTRATOR' not in str(e):raise
    print('BLOQUEADO HTTP: '+str(e).splitlines()[0]);b.close();sys.exit(77)
   pg.wait_for_function("document.querySelector('#message')?.textContent.includes('Listo')")
   def click(page,id):page.locator('#'+id).click();page.wait_for_function('!busy');assert 'bad' not in (page.locator('#message').get_attribute('class') or '')
   def store(page):return page.evaluate('async()=>{let r=await load(node);return Object.fromEntries(Object.entries(r).map(([k,v])=>[k,Array.from(v)]))}')
   def pick(page,n):page.fill('#node',n);click(page,'openNode')
   def decide(page,n):click(page,'pending');page.locator('#queue .record').filter(has_text='Nodo '+n+':').get_by_role('button',name='Aceptar').click();page.wait_for_function('!busy')
   check(pg.evaluate('isSecureContext && !!indexedDB && !!crypto.subtle'),'Contexto seguro con IndexedDB nativo')
   pick(pg,'Tienda');click(pg,'readC');pg.uncheck('#online');click(pg,'product');click(pg,'stockSet');pg.fill('#saleLines','[{"sku":"SKU-A","qty":5,"price":35000}]');click(pg,'sale');before=store(pg);check(pg.evaluate('local.q.length===3 && working.state[0].vectors[0].values[0]===15'),'Producto, stock y venta offline')
   pg.reload();pg.wait_for_function("document.querySelector('#message')?.textContent.includes('Listo')");pick(pg,'Tienda');check(store(pg)==before,'Recarga conserva bytes y derivados');click(pg,'publish');forbidden=store(pg);check(forbidden==before,'Publicación no altera historial');
   for _ in range(3):decide(pg,'Tienda')
   click(pg,'readR');check(pg.evaluate('streams.R.length===3 && working.state[0].vectors[0].values[0]===15'),'R primero: efecto provisional');click(pg,'readC');check(pg.evaluate('canonical.state[0].vectors[0].values[0]===15 && working.state[0].vectors[0].values[0]===15'),'C no duplica venta');
   other=b.new_context();q=other.new_page();q.goto(base+'/');q.wait_for_function("document.querySelector('#message')?.textContent.includes('Listo')");pick(q,'Otra');click(q,'readC');check(q.evaluate('JSON.stringify(canonical.state)')==pg.evaluate('JSON.stringify(canonical.state)'),'Otro contexto converge');
   tab=ctx.new_page();tab.goto(base+'/');tab.wait_for_function("document.querySelector('#message')?.textContent.includes('Listo')");pick(tab,'Tienda');pg.uncheck('#online');tab.uncheck('#online');click(pg,'note');tab.locator('#note').click();tab.wait_for_function('!busy');check('Otro escritor' in tab.locator('#message').inner_text(),'Pestaña con prefijo obsoleto rechazada');click(tab,'rebuild');click(tab,'note');check(tab.evaluate('local.history.length===5'),'Reconstruir y extender sin perder registros');b.close()
  print(f'TOTAL {checks}/{checks}')
 finally:os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=10);log.close()
