#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=$(mktemp -d)
QIPU_ROOT="$D" PHP_CLI_SERVER_WORKERS=4 php -S 127.0.0.1:18942 -t public >"$D/server.log" 2>&1 &
PID=$!
trap 'pkill -P "$PID" 2>/dev/null || true; kill "$PID" 2>/dev/null || true; rm -rf "$D"' EXIT
sleep .5
QIPU_URL=http://127.0.0.1:18942/api.php node tests/comercio.cjs
