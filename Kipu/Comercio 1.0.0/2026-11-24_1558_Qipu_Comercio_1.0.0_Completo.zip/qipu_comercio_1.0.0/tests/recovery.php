<?php
declare(strict_types=1);
require __DIR__.'/../src/Qipu.php';
$root=sys_get_temp_dir().'/qipu-comercio-'.bin2hex(random_bytes(6));mkdir($root,0700);$q=new QipuDemo($root);$s=new Storage($root);$n=0;
function check($ok,$msg){global $n;if(!$ok)throw new RuntimeException($msg);$n++;echo "PASS $msg\n";}
function submit($q,$i,$x){$raw=QipuDemo::frame(QipuDemo::REQUEST,QipuDemo::json($x));$q->locked(fn()=>$q->submit('Bodega',$i,$q->cut('QBodega')['end'],$raw));}
function state($q){return $q->locked(fn()=>$q->pending());}
try{$q->locked(fn()=>$q->register('Bodega'));submit($q,0,['op'=>'product','sku'=>'A','name'=>'Camisa','price'=>35000]);$q->locked(fn()=>$q->decide('Bodega',0,1));submit($q,1,['op'=>'stock','sku'=>'A','value'=>20]);$q->locked(fn()=>$q->decide('Bodega',1,1));submit($q,2,['op'=>'sale','lines'=>[['sku'=>'A','qty'=>5,'price'=>35000]]]);
try{$q->locked(fn()=>$q->decide('Bodega',2,1,true));throw new LogicException('Expected interruption');}catch(RuntimeException $e){if($e->getMessage()!=='Simulated interruption after C')throw $e;}
$c=$s->read('C',0,Storage::MAX)['bytes'];check($s->head('RBodega')['end']===2,'Interrupción después de C y antes de R');$q=new QipuDemo($root);$z=state($q);check($z['nodes']['Bodega']['responses']===3&&ord($s->read('RBodega',2,1)['bytes'])===130,'Recuperación de respuesta posicional');check($z['canonical'][0]['vectors'][0]['values']->{0}===15&&count($z['canonical'][0]['sales'])===1,'Stock 15; una única venta');$q->locked(fn()=>$q->decide('Bodega',2,1));check($s->read('C',0,Storage::MAX)['bytes']===$c,'Repetición no altera C');
submit($q,3,['op'=>'stock','sku'=>'A','value'=>9]);try{$q->locked(fn()=>$q->decide('Bodega',3,1,true));throw new LogicException('Expected interruption');}catch(RuntimeException $e){if($e->getMessage()!=='Simulated interruption after C')throw $e;}$c=$s->read('C',0,Storage::MAX)['bytes'];$q=new QipuDemo($root);$z=state($q);check($z['nodes']['Bodega']['responses']===4&&$z['canonical'][0]['vectors'][0]['values']->{0}===9,'Ajuste absoluto recuperado sin repetir');check($s->read('C',0,Storage::MAX)['bytes']===$c,'Recuperación preserva bytes de C');echo "TOTAL $n/$n\n";
}finally{foreach(glob($root.'/*') as $f)unlink($f);rmdir($root);}
